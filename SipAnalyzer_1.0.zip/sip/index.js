import exampleRoute from './server/routes/example';

var path = require('path');
module.exports = function (kibana) {

  var mainFile = 'plugins/sip/app';

  /* Below Lines are included to avoid the autoload Issue while loading kibana */
  var ownDescriptor = Object.getOwnPropertyDescriptor(kibana, 'autoload');
  var protoDescriptor = Object.getOwnPropertyDescriptor(kibana.constructor.prototype, 'autoload');
  var descriptor = ownDescriptor || protoDescriptor || {};



  // the autoload list has been replaced with a getter that complains about
  // improper access, bypass that getter by seeing if it is defined
  if (descriptor.get) {
    mainFile = 'plugins/sip/app_with_autoload';
  }
  return new kibana.Plugin({
    require: ['kibana','elasticsearch'],

    uiExports: {
      app: {
        title: 'SIP Analyzer',
        description: 'An awesome Kibana plugin',
        main: mainFile,
        icon: 'plugins/sip/resource/logo-scaled.png',
        injectVars: function (server, options) {
          var config = server.config();
          return {
            kbnIndex: config.get('kibana.index'),
            esShardTimeout: config.get('elasticsearch.shardTimeout'),
            esApiVersion: config.get('elasticsearch.apiVersion')
          };
        }
      }
    },



    init(server, options) {
      // Add server routes and initalize the plugin here
      exampleRoute(server);
    }

  });
};
