const spawn = require('child_process').spawn;
export default function (server) {

  let elasticClient = server.plugins.elasticsearch.callWithRequest;
  server.route({
    path: '/api/sip/example',
    method: 'GET',
    handler(req, reply) {
      reply('success');
    }
  });

  server.route({
    path: '/api/sip/callJar',
    method: 'GET',
    handler(req, reply) {
      console.log('Launching APP');
      var subchild = spawn('bash', ['/home/elastic/execute.sh', req.query.UserId, req.query.UserPass, req.query.UserServer]);

      subchild.on('error', (err) => {
        console.log('Failed to start child process.');
      });
      //console.log(child);
      subchild.on('close', (code) => {
        console.log(`child process exited with code ${code}`);
      });

      subchild.stdout.on('data', function (data) {
        console.log('stdout: ' + data); // This will print string returned by Main class.
      });
      reply('success');
    }
  });


  server.route({
    path: '/api/sip/corrid3',
    method: 'GET',
    handler(req, reply) {
      var corridLength;
      var idHolder = [];
      if (req.query.corrid instanceof Array) {
        //console.log('Array Object');
        corridLength = req.query.corrid.length;
        idHolder = req.query.corrid;
      } else {
        //console.log('Not an Array Object');
        idHolder.push(req.query.corrid);
        corridLength = 1;
      }
      //var corridLength = req.query.corrid.length;
      var queryBody = [];
      if (corridLength < 1) {
        console.log('Cant check empty corridLength');
        return;
      }
      else {
        for (var x = 0; x < corridLength; x++) {
          queryBody.push('{"index": "bwlog*"}');
          var query = { size:1 ,query: {
            filtered:{
              query:{
                term:{
                  correlationid:idHolder[x]
                }
              }
            }},
      sort:[
        {
          logtimestamp:{
            order:'asc'
          }
        }
      ],
            filter:{
              bool:{
                must:[
                  {
                    range:{
                      logtimestamp:{
                        gte:req.query.fromtime,
                        lte:req.query.totime,
                        format:'epoch_millis'
                      }
                    }
                  } ,{'term':{'sipmethod':req.query.method}}
                ]
              }
            }};
          queryBody.push(query);
          //console.log(query);
        }// End of Else statement
        //console.log(req.query.fromtime);
        //console.log(req.query.totime);
        //console.log(JSON.stringify(queryBody[1]));
        elasticClient(req,'msearch', {
          'requestTimeout' : 60000,
          body : queryBody
        }).then(function (response) {
          reply(response.responses);
        });
      }
    }});



  /**
   * [multiSearch Perform multisearch for list of correlationid generated]
   * @param  {[object]} keyPair  [Contains the correlationId and count]
   * @param  {[type]} fromTime [Contains Start Time]
   * @param  {[type]} toTime   [Contains End Time]
   * @param  {[object]} req      [Contains Request Handler]
   * @return {[type]}          [description]
   */
  var multiSearch = function (keyPair,fromTime,toTime,req) {
    var corridLength = keyPair.length;
    var finalResult = [];
    var queryBody = [];
    var sample = {};
    if (corridLength < 1) {
      console.log('Cant check empty corridLength');
      return;
    }
    else {
      for (var x = 0; x < corridLength; x++) {
        queryBody.push('{"index": "bwlog*"}');
        var query = { size:1 ,query: {
          filtered:{
            query:{
              term:{
                correlationid: keyPair[x].key
              }
            }
          }},
    sort:[
      {
        logtimestamp:{
          order:'asc'
        }
      }
    ],
          filter:{
            bool:{
              must:[
                {
                  range:{
                    logtimestamp:{
                      gte:fromTime,
                      lte:toTime,
                      format:'epoch_millis'
                    }
                  }
                }
              ]
            }
          }};
        queryBody.push(query);
      }// End of Else statement
      // Multisearch query
      return elasticClient(req,'msearch', {
        'requestTimeout' : 60000,
        body : queryBody
      }).then(function (response) {
        //console.log(response.responses);
        var myArr = response.responses;
        return myArr;
      });
    }


  };

  //Function Block to retrieve the correlationid along with Timestamp
  // Improvment: Move the query building section outside this function block
  server.route({
    path: '/api/sip/corrid2',
    method: 'GET',
    handler(req, reply) {
      var arr = [];
      //return;
      elasticClient(req,'search', {
        index: 'bwlog*',
        'size': 1,
        body:req.query.advanceQuery
      }).then(function (response) {
        // Returns the list of correlationId along with document count
        // To the browser for processing
        var keyPair = {};
        keyPair = response.aggregations.corrid_agg.buckets;
        //console.log('test');
        //Call the query builder function and pass the array
        //console.log(keyPair);
        if (keyPair.length > 1) {
          reply(multiSearch(keyPair,req.query.startDate, req.query.endDate, req).then(function (res) {
            //console.log(keyPair);
            return res;
          }));
        }
        else {
          //At Times, results are empty while fetching correlationId
          reply(response);
        }
      });
    }
  });

  //Function Block to retrieve the correlationid along with Timestamp
  // Improvment: Move the query building section outside this function block
  server.route({
    path: '/api/sip/corrid1',
    method: 'GET',
    handler(req, reply) {
      var arr = [];
      //return;
      elasticClient(req,'search', {
        index: 'bwlog*',
        'size': 0,
        body:req.query.advanceQuery
      }).then(function (response) {
        // Returns the list of correlationId along with document count
        // To the browser for processing
        var keyPair = {};
        keyPair = response.aggregations.corrid_agg.buckets;
        //Call the query builder function and pass the array
        // HIK Sep-05-2016
        // Change the length greater than zero from One
        if (keyPair.length > 0) {
          reply(keyPair);
        }
        else {
          //At Times, results are empty while fetching correlationId
          reply(response);
        }
      });
    }
  });



//getuserinfo
  server.route({
    path: '/api/sip/userinfo',
    method: 'GET',
    handler(req, reply) {
      //console.log(req.query.advanceQuery);
      elasticClient(req,'search', {
        index: 'bwlog*',
        body: req.query.advanceQuery
      }).then(function (response) {
        reply(response);
      });
    }
  });


// Function block to retrieve logs
// Based on the correlationid
  server.route({
    path: '/api/sip/logmessage',
    method: 'GET',
    handler(req, reply) {
      elasticClient(req, 'search',{
        index: 'bwlog*',
        'size': 1000,
        body:{
          'sort': [
            {
              'logtimestamp': {
                'order': 'asc'
              }
            }
          ],
          'query': {
            'filtered': {
              'query': {
                'term': {
                  'correlationid': req.query.correlationId
                }
              }
            }
          }
        }
      }).then(function (response) {
        var myArr = response.hits.hits;
        reply(response);
      });
    }
  });
};// - End of Default function block
