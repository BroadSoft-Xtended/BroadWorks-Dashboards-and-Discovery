var $ = require('jquery');
var angular = require('angular');
require('bootstrap');
import moment from 'moment';
import chrome from 'ui/chrome';
import uiModules from 'ui/modules';
import uiRoutes from 'ui/routes';

import './dependency.js';
// HTML Template
import template from './templates/mainPage.html';
import corridpage from './templates/corridsearch.html';
import configpage from './templates/configuration.html';
import logAggreation from './templates/logCollection.html';
import dashboard from './templates/visualize.html';
import uiChrome from 'ui/chrome';



chrome
  .setNavBackground('#222222')
  .setTabs([]);

uiRoutes.enable();
uiRoutes
.when('/', {
  template,
  resolve: {
    currentTime($http) {
      return $http.get('../api/sip/example').then(function (resp) {
        return resp.data;
      });
    }
  }
})
.when('/test', {
  template: corridpage,
  resolve: {
    currentTime($http) {
      return $http.get('../api/sip/example').then(function (resp) {
        return resp.data;
      });
    }
  }
})
.when('/logCollector', {
  template: logAggreation,
  resolve: {
    currentTime($http) {
      return $http.get('../api/sip/example').then(function (resp) {
        return resp.data;
      });
    }
  }
})
;

uiModules
.get('app/sip', ['720kb.tooltips','ngDialog','angularUtils.directives.dirPagination','ngCookies'])
.controller('SipController', function ($scope, $route, $interval, $http, $sce,  $filter, $window, ngDialog, $cookies) {
  $scope.title = 'SIP';

  //Application Name
  $scope.AppName = 'SIP Call Correlation ID Utility';

  // Calling Calendar Methods Via Jquery
  $(function () {$('#datetimepicker1').datetimepicker(); $('#datetimepicker2').datetimepicker();});

  /**
   * [rangeSelector Allows to select only complete log message panel]
   * @param  {[string]} containerid [name of the container]
   * @return {[void]}             [void]
   */
  function rangeSelector(containerid) {
    var range = '';
    var node = document.getElementById(containerid);

    if (document.selection) {
      range = document.body.createTextRange();
      range.moveToElementText(node);
      range.select();
    } else if (window.getSelection) {
      range = document.createRange();
      range.selectNodeContents(node);
      window.getSelection().removeAllRanges();
      window.getSelection().addRange(range);
    }
  };

  /**
   * [keyCode Self Invoking function]
   * @type {[keyword event]}
   */
  $(document).keydown(function (e) {
    if (e.keyCode === 65 && e.ctrlKey) {
      rangeSelector('completeLog');
      e.preventDefault();
    }
  });

  /**
  * @desc Comman Non Modal Box for alert.
  * @param message- contains message to be displayed to user
  * @return void
  */
  $scope.openModalBox = function (message) {
    ngDialog.open({ template: '<p>' + message + '</p>', plain: true });
  };

  /**
  * @desc Converts the current time into epoch_millis format
  * @param no params
  * @return void
  */
  var getCurrentTime = function () {
    var CurrentTime = $filter('date')(new Date(), 'MM/dd/yyyy hh:mm a');
    return (new Date(CurrentTime)).getTime();
  };

  /**
  * @desc Get the relative time based on the option selected 'Relative time'
  * @desc Calculation for relative time = Mins * 60 * 1000
  * @param no params
  * @return void
  */
  var getRelativeTime = function () {
    var relativeTime;
    var currentTime = getCurrentTime();
    //console.log('To Time' + currentTime);
    if ($scope.selectedRelative === '5 Min')
    {
      relativeTime = (currentTime - (300 * 1000));
    }
    else if ($scope.selectedRelative === '10 Min') {
      relativeTime = (currentTime - (600 * 1000));
    }
    else if ($scope.selectedRelative === '15 Min') {
      relativeTime = (currentTime - (900 * 1000));
    }
    else if ($scope.selectedRelative === '1 Hour') {
      relativeTime = (currentTime - (3600 * 1000));
    }
    else if ($scope.selectedRelative === '2 Hours') {
      relativeTime = (currentTime - (7200 * 1000));
    }
    else if ($scope.selectedRelative === '5 Hours') {
      relativeTime = (currentTime - (18000 * 1000));
    }
    else if ($scope.selectedRelative === '1 Day') {
      relativeTime = (currentTime - (86400 * 1000));
    }
    else if ($scope.selectedRelative === '1 Week') {
      relativeTime = (currentTime - (604800 * 1000));
    }
    //console.log('From Time' + relativeTime);
    return relativeTime;
  };

  /**
   * [choices Holds the multiple search Conditions]
   * @type {Array}
   */
  $scope.choices = [{}];
  /**
  * @desc Intialize and Reset to the original Value for SipController
  * @param no params
  * @return void
  */
  $scope.reset = function () {
    $scope.time = {option:'Absolute'};
    $scope.DefaultTime = '07/30/2016 12:00 AM';
    $scope.PresentTime = $filter('date')(new Date(), 'MM/dd/yyyy hh:mm a');
    $scope.TimeDuration = ['5 Min', '10 Min', '15 Min', '1 Hour', '2 Hours', '5 Hours', '1 Day', '1 Week'];
    $scope.SipMethod = ['INVITE','REGISTER','NOTIFY','SUBSCRIBE', 'ACK', 'BYE',
     'CANCEL','OPTIONS','PRACK','PUBLISH', 'INFO','REFER', 'MESSAGE', 'UPDATE'];
    $scope.cssClass = 'col-md-8';
    $scope.selectedFilter = false;
    $scope.qstring = false;
    $scope.qsearch = null;
    $scope.firstRow = false;
    this.hits = null;
    $scope.logM = null;
    $scope.users = [];
    $scope.CorrId = null;
    $scope.pageSize = 20;
    $scope.currentPage = 1;
    // Recursively removes until the filter becomes one
    while ($scope.choices.length > 1)
    {
      $scope.removeCondition();
    }
  };

  //reset() is invovked by below statement
  $scope.reset();

  $scope.formReset = function () {
    $scope.resultLoad = 'skip';
    $scope.reset();
  }

  /**
   * [fetchGlobalInfo Read the value from the cookie stored]
   * @return {[void]} [description]
   */
  $scope.fetchGlobalInfo = function () {
    var globalCookie = $cookies.get('globalConfiguration');
    if (globalCookie) {
      $scope.test = globalCookie;
      var json = JSON.parse(globalCookie);
      console.log('Custom Settings Applied');
      //console.log(json);
      if (json.sort === 'Ascending') {
        $scope.sortPreference = 'asc';
      }
      else if (json.sort === 'Descending') {
        $scope.sortPreference = 'desc';
      }
      $scope.sampleSize  = json.size;
    }
    else {
      console.log('Default Settings is Applied');
      $scope.sortPreference = 'asc';
      $scope.sampleSize  = '1000';
    }
  };

  $scope.fetchGlobalInfo();

  /**
  * @desc Intialize searchBy Options
  * @param no params
  * @return void
  */
  $scope.searchBy = function () {
    $scope.searchByOptions = ['From', 'To', 'Request URI', 'P-Asserted-Identity'];
  };

  /**
  * @desc Intialize filterBy Options
  * @param no params
  * @return void
  */
  $scope.filterBy = function () {
    $scope.filterByOptions = ['Domain', 'User Part'];
  };

  /**
  * @desc getting Absolute Time - From Time
  * @param no params
  * @return void
  */
  var getAbsoluteFromTime = function () {
    var UserFromDate = angular.element($('#userfromdate')).val();
    //console.log(UserFromDate);
    return (new Date(UserFromDate)).getTime();
  };

  /**
  * @desc getting Absolute Time - End Time
  * @param no params
  * @return void
  */
  var getAbsoluteToTime = function () {
    var UserToDate = angular.element($('#usertodate')).val();
    //console.log(UserToDate);
    return (new Date(UserToDate)).getTime();
  };

  /**
  * @desc Facilate adding more search conditons
  * @param no params
  * @return nothing
  */
  $scope.addCondition = function () {
    // Prevents adding more than 5 search conditons
    if (($scope.choices.length + 1) > 5)
    {
      $scope.openModalBox('Further Filter Can Not be Applied');
      return;
    }
    var newItemNo = $scope.choices.length + 1;
    $scope.choices.push({newItemNo});
  };

  /**
  * @desc Remove the search filter which is added previously
  * @param no params
  * @return void
  */
  $scope.removeCondition = function () {
    // Must have atleast one search option
    // Prevent '-' button to remove all the fields
    if ($scope.choices.length === 1)
    {
      $scope.openModalBox('Atleast One Search Filter Needed');
      return;
    }
    var lastItem = $scope.choices.length - 1;
    $scope.choices.splice(lastItem);
  };

  /**
  * @desc Assign 'time from' and 'time to' based upon time context
  * @param no params
  * @return fromTime, toTime
  */
  var assignTime = function () {
    var fromTime; var endTime;
    // Relative Time Functionality
    if ($scope.time.option === 'Relative') {
      fromTime = getRelativeTime();
      endTime = getCurrentTime();
    }
    else { // Absolute Time Functionality
      fromTime = getAbsoluteFromTime();
      endTime = getAbsoluteToTime();
    }
    //console.log(fromTime);
    //console.log(endTime);
    $scope.timeFrame = [fromTime, endTime];
    return [fromTime, endTime];
  };

  /**
  * @desc Frames the search field based given input field, refer query matrix
  * @param searchBy, filterBy
  * @return term
  */
  var frameSearchField = function (searchBy,filterBy) {
    var condOne = searchBy;
    var term = 'sip';
    // Deciding 'from' or 'to' Predicate
    if (!condOne.indexOf('From')) {
      term = term + 'from';
    }
    else if (!condOne.indexOf('To')) {
      term = term + 'to';
    }
    else if (!(condOne.indexOf('Request'))) {
      term = term + 'ruri';
    }
    else if (!(condOne.indexOf('P-Asserted-Identity'))) {
      term = term + 'pai';
    }

    var condTwo = filterBy;
    if (!condTwo.indexOf('Domain')) {
      term = term + 'domain';
    }
    else {
      term = term + 'user';
    }
    //console.log('finalQuery' + term);
    return term;
  };

  /**
  * @desc Helps to frame the search field query object
  * @desc It is consumed by fetchCorridTime
  * @param searchField - field name to be String
  * @param queryString - search string for the given searchField
  * @return searchField object which contains the object
  */
  var frameSearchFieldBuilder = function (searchField, queryString) {
    var searchField = {
      'query' :
        { 'query_string' :
          { 'default_field' : searchField,
	           'query': queryString,
             'analyze_wildcard': true
           }
        }
    };
    return searchField;
  };

  /**
  * @desc Converts the Angular Bracket into &lt and &gt
  * @param fromTime, toTime, searchCondition, sipmethod
  * @return void
  */
  var queryBuilder = function (fromTime, toTime, searchCondition, sipmethod, sortOrder) {
    var y = {
      'sort': [
        {
          'logtimestamp':
            {
              'order': sortOrder
            }
        }
      ],
      'fields': [
        'logtimestamp',
        'body'
      ],
      'aggs': {
        corrid_agg: {
          'terms': {
            field: 'correlationid',
            size: '1000',
            collect_mode: 'breadth_first'
          }
        }
      },
      'query': {
        filtered: {
          query: {
            query_string: {
              query: '*'
            }
          },
          filter: {
            bool: {
              must: [
                {
                  range: {
                    'logtimestamp': {
                      'gte': fromTime,
                      'lte': toTime,
                      'format': 'epoch_millis'
                    }
                  }
                },
                {
                  term: {
                    'sipmethod': sipmethod
                  }
                },
                searchCondition
              ],
            }
          }
        }
      }
    };
    return y;
  };

  /**
  * @desc Fetches the result for given set of correlationid
  * @param pagenumber
  * @return void
  */
  $scope.fetchPages = function (pagenumber) {
    if ($scope.resultLoad === 'skip') {
      $scope.resultLoad === 'pass over';
      return;
    }
    console.log(pagenumber);
    var time = assignTime();
    var j;
    var Id = [];
    // HIK 17 October 2016
    // Fixed bug while moving between pages, displaying progress and deleting info
    $scope.progressId = 'true';
    this.hits = null;
    $scope.fromTime = time[0];
    $scope.endTime = time[1];
    if (pagenumber === 1)
    {
      j = 0;
    }
    else {
      j = (pagenumber * 20) - 20;
    }
    for (var i = j; i < $scope.listofCorrelationId.length && (i < pagenumber * 20); i++)
    {
      Id.push($scope.listofCorrelationId[i].key);
    }
    $http.get('../api/sip/corrid3',{
      params:{
        corrid:Id,
        fromtime: $scope.fromTime,
        totime: $scope.endTime,
        method:  $scope.choice.selectedMethod,
        sortOrder: $scope.sortPreference
      }
    }).then((response) => {
      //console.log(response.data);
      this.hits = response.data;
      $scope.progressId = 'false';
    });
  };

  /**
  * @desc Fetches the Correlation Id and TimeStamp Related to it
  * @desc Two Stage process, fetch ID and then perform mulitsearch
  * @param no params
  * @return void
  */
  $scope.fetchCorridTime = function () {

    //Starts the Radical Progress
    $scope.progressId = 'true';
    $scope.resultLoad = 'pass over';
    //Flushes out the hits to out page number
    this.hits = null;
    //Flushes the log message from output panel
    $scope.logM = null;
    $scope.users = [];
    $scope.CorrId = null;
    $scope.paramQuery = [];
    var filterQueryObject = [];
    for (var i = 0; i < $scope.choices.length; i++)
    {
      var searchTerm = frameSearchField($scope.choices[i].selectedCallOrigin, $scope.choices[i].selectedFilter);
      var searchQuery = frameSearchFieldBuilder(searchTerm, $scope.choices[i].qsearch);
      filterQueryObject.push(searchQuery);
    }
    var time = assignTime();
    $scope.fromTime = time[0];
    $scope.endTime = time[1];
    $scope.paramQuery = queryBuilder($scope.fromTime, $scope.endTime, filterQueryObject, $scope.choice.selectedMethod,
       $scope.sortPreference);
    //console.log($scope.paramQuery);
    $http.get('../api/sip/corrid1',{
      params:{
        advanceQuery:$scope.paramQuery
      }
    }).then((response) => {
      $scope.listofCorrelationId = response.data;
      //console.log(response.data);
      var myArr = response.data;
      //console.log(response.data);
      try {
        if (myArr.hits.hits.length < 1)
        {
          // Used to stop Radical Progress when no correlation Id returned
          $scope.progressId = 'false';
          //console.log('No Results Found for given Search Conditions');
          $scope.openModalBox('No Results Found');
          return;
        }
      } catch (e) {
        // Page size is used in pagination control stucture
        $scope.PageSize = response.data.length;
        $scope.fetchPages(1);
      }
    });
  };

  /**
  * @desc Converts the Angular Bracket into &lt and &gt
  * @param no params
  * @return void
  */
  function htmlEntities(str) {

    return String(str).replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  /**
   * [autoLink renders the logmessage for given correlationId]
   * @param  {[object]} myArr      [json object from server]
   * @param  {[string]} uniquetime [log file timestamp]
   * @return {[object]}            [holds logmessage, logfile]
   */
  function autoLink(myArr, uniquetime) {
    var logMessage = '';
    var logFile = '';
    //logFile model variable is used hold log message for  file being downloaded
    $scope.logFile = myArr;
    $scope.logFileName = uniquetime;
    var xsiEventApp = '/app/xsi_event#/';
    // Below code snippet is used to decorate the Log Message First Line
    for (var i = 0; i < myArr.length; i++)
    {
      var xx = htmlEntities(myArr[i]._source.source);
      logFile = logFile.concat(myArr[i]._source.source);
      /**
       * [firstLinePatternRE used to hold the regex for the first line]
       * Used to capture the first Line in log message, refer CallCorrelationIdentifierFD-R200
       * @type {[string]}
       */
      var firstLinePatternRE = /^(\d{4}\.\d{2}\.\d{2}\s+.*)\n/g;
      var y = xx.match(firstLinePatternRE);
      xx = xx.replace(firstLinePatternRE, '<div id="decorate">' + y[0] + '</div>');
      /**
       * [chanIdPatternRE Regular Expression to Capture ChannelId]
       * @type {[string]}
       */
      var chanIdPatternRE = /(&lt;xsi:channelId&gt;.*&lt;\/xsi:channelId&gt;)/g;
      var chanId = xx.match(chanIdPatternRE);
      if (chanId) {
        //console.log(chanId);
        //console.log($scope.timeFrame[0] / 1000.0);
        // Time is normalized to epooch due to xsi event bug
        var chanQueryString = 'channel/' + chanId[0].slice(21,57)  + '/' +
        $scope.timeFrame[0] + '/' + $scope.timeFrame[1];
        xx = xx.replace(chanIdPatternRE, '<a ng-click="channelId()" href="' + xsiEventApp + chanQueryString + ' ">' + chanId +
         '#chanId' + '</a>');
      }
      /**
       * [subIdPatternRE Regular Expression to Capture subscriptionId]
       * @type {[string]}
       */
      var subIdPatternRE = /(&lt;xsi:subscriptionId&gt;.*&lt;\/xsi:subscriptionId&gt;)/g;
      var subId = xx.match(subIdPatternRE);
      //console.log(subId);
      if (subId) {
        //console.log(subId);
        var QueryString = 'subscription/' + subId[0].slice(26,62) + '/' +
         $scope.timeFrame[0] + '/' + $scope.timeFrame[1];
        xx = xx.replace(subIdPatternRE,'<a  href="' + xsiEventApp + QueryString + ' ">' +
         subId + '#subId' + '</a>');
      }
      /**
       * [eventIdPatternRE Regular Expression to Capture EventId]
       * @type {[string]}
       */
      var eventIdPatternRE = /(&lt;xsi:eventID&gt;.*&lt;\/xsi:eventID&gt;)/g;
      var eventId = xx.match(eventIdPatternRE);
      if (eventId) {
        var eventQueryString = 'event/' + eventId[0].slice(19,55) + '/' +
         $scope.timeFrame[0] + '/' + $scope.timeFrame[1];
        //console.log(eventId);
        xx = xx.replace(eventIdPatternRE ,'<a  href="' + xsiEventApp  + eventQueryString  + ' ">'  +
        eventId + '#Event' + '</a>');
      }
      logMessage = logMessage.concat(xx);
    }
    return [logMessage, logFile];
  }

  /**
  * @desc retrieve the complete call log message based on the correlationid
  * @param correlationid, uniquetime
  * @return void
  */
  $scope.fetchLogMessage = function (correlationid, uniquetime) {

    $scope.CorrId = correlationid;
    //console.log($scope.CorrId);
    $scope.progress = 'true';
    $scope.logM = null;
    $http.get('../api/sip/logmessage',{
      params:{
        correlationId: correlationid
      }
    }).then((response) => {
      var myArr = response.data.hits.hits;
      if (myArr.length < 1)
      {
        $scope.openModalBox('No Logs Found');
      }

      /**
       * [result description holds logMessage, logFile]
       * [result [0]logMessage formatted output displayed to user]
       * [resut [1]logFile original text file]
       * @type {[object]}
       */
      var result = autoLink(myArr, uniquetime);
      //AngularJs does not support rendering the HTML components
      //so We need to trustAsHtml before sending to ng-model
      //$scope.logM = $sce.trustAsHtml(logMessage);
      $scope.logM = $sce.trustAsHtml(result[0]);
      //console.log(logMessage);
      //$scope.logFileMessage = logFile;
      $scope.logFileMessage = result[1];
      $scope.progress = 'false';
    });
  };

  /**
  * @desc It helps to download the log file with timestamp as filename
  * @param no params
  * @return void
  */
  $scope.downloadFile = function ()
  {
    var fileName = $scope.logFileName;
    var logFileName = fileName.replace(/ /g, '_');
    //console.log(logFileName);
    var element = document.createElement('a');
    /**
     * Added to fix the download file feature in IE browser
     * There is limitation of character that can be passed in url
     */
    if (navigator.msSaveBlob) { // IE 10+
      navigator.msSaveBlob(new Blob([$scope.logFileMessage], { type : 'text/plan;charset=utf-8;'
		}), 'siplog_' + logFileName + '.txt');
    }
    else { // Chrome && FireFox
      element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent($scope.logFileMessage));
      element.setAttribute('download', 'siplog_' + $scope.CorrId + '.txt');
      element.style.display = 'none';
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    }

  };

  /**
  * @desc Make fullScreen of Complete Log Panel
  * @param no params
  * @return void
  */
  $scope.fullScreen = function ()
  {
    if ($scope.fullScreenMode === true) {
      $scope.cssClass = 'col-md-8';
      //console.log($scope.cssClass);
      $scope.fullScreenMode = false;
    }
    else {
      $scope.fullScreenMode = true;
      $scope.cssClass = 'col-md-12';

      //During Full screen mode, move the focus to top
      $window.scrollTo(0, angular.element(document.getElementById('unitetheme')).offsetTop);
      //console.log($scope.cssClass);
    }
  };


  /**
  List of unused function for the SipController
  */
  /**
  * @desc set Flag when move exit event
  * @param no params
  * @return void
  * This method is not being currently used
  */
  $scope.setFlag = function () {
    $scope.hovering = false;
    // console.log($scope.hovering);
  };

  /**
  * @desc fetchusernamequery details from server
  * @param fromTime, toTime, sipmethod, correlationid
  * @return y object which contains the query object
  * This method is not being currently used
  */
  var fetchusernamequery = function (fromTime, toTime, sipmethod, correlationid) {
    var y = {
      'size': 1,
      'sort': [
        {
          'logtimestamp':
            {
              'order': 'asc'
            }
        }
      ],

      'query': {
        filtered: {
          query: {
            query_string: {
              query: '*'
            }
          },
          filter: {
            bool: {
              must: [
                {
                  range: {
                    'logtimestamp': {
                      'gte': fromTime,
                      'lte': toTime,
                      'format': 'epoch_millis'
                    }
                  }
                },
                {
                  term: {
                    'sipmethod': sipmethod
                  }
                },
                [
                  {
                    'query': {'query_string': {'default_field': 'correlationid',
                                    'query': correlationid,
                                        'analyze_wildcard': true
                    }
                  }}
                ]
              ],
            }
          }
        }
      }
    };
    return y;
  };

  /**
  * @desc fetchusername details from server
  * @param correlationId, index
  * @return void
  * This method is not being currently used
  */
  $scope.fetchusersname = function (correlationId, index) {
    $scope.hovering = true;
    $scope.users = [];
    var time = assignTime();
    $scope.fromTime = time[0];
    $scope.endTime = time[1];
    var id = correlationId.replace(/:/g, '\\:');
    //console.log(id);
    var fetchUserNamesQuery = fetchusernamequery(time[0], time[1], $scope.choice.selectedMethod, id);
    console.log(fetchUserNamesQuery);
    $http.get('../api/sip/userinfo',{
      params:{
        advanceQuery:fetchUserNamesQuery
      }
    }).then((response) => {
      var myArr = response.data;
      $scope.users[index] = myArr.hits.hits[0]._source;
      //console.log($scope.users[index]);
    });

  };

})
.controller('correlationidController', function ($scope, $route, $interval, $http, $sce,  $filter, $cookies) {
  $scope.AppName = 'Search - CorrelationId Log Dump';

  // Calling Calendar Methods Via Jquery
  $(function () {$('#datetimepicker1').datetimepicker(); $('#datetimepicker2').datetimepicker();});

  /**
   * [getCurrentTime Converts the CurrentTime into epoch_millis ]
   * @return {[number]} [returns number in millisecond]
   */
  var getCurrentTime = function () {
    var CurrentTime = $filter('date')(new Date(), 'MM/dd/yyyy hh:mm a');
    return (new Date(CurrentTime)).getTime();
  };

  /**
   * [getRelativeTime Get the relative time based on the option selected 'Relative time'
   * Calculation for relative time = Mins * 60 * 1000]
   * @return {[type]} [description]
   */
  var getRelativeTime = function () {
    var relativeTime;
    var currentTime = getCurrentTime();
    //console.log('To Time' + currentTime);
    if ($scope.selectedRelative === '5 Min')
    {
      relativeTime = (currentTime - (300 * 1000));
    }
    else if ($scope.selectedRelative === '10 Min') {
      relativeTime = (currentTime - (600 * 1000));
    }
    else if ($scope.selectedRelative === '15 Min') {
      relativeTime = (currentTime - (900 * 1000));
    }
    else if ($scope.selectedRelative === '1 Hour') {
      relativeTime = (currentTime - (3600 * 1000));
    }
    else if ($scope.selectedRelative === '2 Hours') {
      relativeTime = (currentTime - (7200 * 1000));
    }
    else if ($scope.selectedRelative === '5 Hours') {
      relativeTime = (currentTime - (18000 * 1000));
    }
    else if ($scope.selectedRelative === '1 Week') {
      relativeTime = (currentTime - (604800 * 1000));
    }
    //console.log('From Time' + relativeTime);
    return relativeTime;
  };

  //Function: getAbsoluteFromTime
  //@description : Fetch the 'from time'
  var getAbsoluteFromTime = function () {
    var UserFromDate = angular.element($('#userfromdate')).val();
    //onsole.log(UserFromDate);
    return (new Date(UserFromDate)).getTime();
  };

  /**
   * [getAbsoluteToTime Get Absolute 'to time']
   * @return {[type]} [description]
   */
  var getAbsoluteToTime = function () {
    var UserToDate = angular.element($('#usertodate')).val();
    //console.log(UserToDate);
    return (new Date(UserToDate)).getTime();
  };

  /**
   * [assignTime Assing from and To date depending on the context
   * Common component for both relative and absolute]
   * @return {[type]} [description]
   */
  var assignTime = function () {
    var fromTime; var endTime;
    // Relative Time Functionality
    if ($scope.time.option === 'Relative') {
      fromTime = getRelativeTime();
      endTime = getCurrentTime();
    }
    else { // Absolute Time Functionality
      fromTime = getAbsoluteFromTime();
      endTime = getAbsoluteToTime();
    }
    //console.log(fromTime);
    //console.log(endTime);
    return [fromTime, endTime];
  };

  /**
   * [reset Intialize and Reset to the original Value]
   */
  $scope.reset = function () {
    $scope.time = {option:'Absolute'};
    $scope.DefaultTime = '07/30/2016 12:00 AM';
    $scope.PresentTime = $filter('date')(new Date(), 'MM/dd/yyyy hh:mm a');
    $scope.TimeDuration = ['5 Min', '10 Min', '15 Min', '1 Hour', '2 Hours', '5 Hours', '1 Week'];
    $scope.DefaultTimeDuration = '5Min';
    $scope.corridId = 'c287dff8-9dd8-4c8e-9d4c-d03371c11e43';
    $scope.qsearch = null;
    $scope.logM = null;

  };

  //reset() is invovked by below statement
  $scope.reset();

  /**
   * [htmlEntities Replace the HTML begining and closing Tags]
   * @param  {[string]} str [logmessage ]
   * @return {[type]}     [All the HTML tags are converted into &lt and &gt]
   */
  function htmlEntities(str) {
    return String(str).replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  /**
   * [autoLink renders the logmessage for given correlationId]
   * @param  {[object]} myArr      [json object from server]
   * @param  {[string]} uniquetime [log file timestamp]
   * @return {[object]}            [holds logmessage, logfile]
   */
  function autoLink(myArr, uniquetime) {
    var time = assignTime();
    $scope.fromTime = time[0];
    $scope.endTime = time[1];
    var logMessage = '';
    var logFile = '';
    //logFile model variable is used hold log message for  file being downloaded
    $scope.logFile = myArr;
    $scope.logFileName = uniquetime;
    var xsiEventApp = '/app/xsi_event#/';
    /**
     * [timeFrame - It hold the fromTime and endTime]
     * [desc - As we need to launch XSI event APP we need to pass epooch begining
     * and current epoch milli time]
     * @type {Array}
     */
    $scope.timeFrame = ['0000000000000',new Date().getTime()];
    // Below code snippet is used to decorate the Log Message First Line
    for (var i = 0; i < myArr.length; i++)
    {
      var xx = htmlEntities(myArr[i]._source.source);
      logFile = logFile.concat(myArr[i]._source.source);
      /**
       * [firstLinePatternRE used to hold the regex for the first line]
       * Used to capture the first Line in log message, refer CallCorrelationIdentifierFD-R200
       * @type {[string]}
       */
      var firstLinePatternRE = /^(\d{4}\.\d{2}\.\d{2}\s+.*)\n/g;
      var y = xx.match(firstLinePatternRE);
      xx = xx.replace(firstLinePatternRE, '<div id="decorate">' + y[0] + '</div>');
      /**
       * [chanIdPatternRE Regular Expression to Capture ChannelId]
       * @type {[string]}
       */
      var chanIdPatternRE = /(&lt;xsi:channelId&gt;.*&lt;\/xsi:channelId&gt;)/g;
      var chanId = xx.match(chanIdPatternRE);
      if (chanId) {
        console.log(chanId);
        //console.log($scope.timeFrame[0] / 1000.0);
        // Time is normalized to epooch due to xsi event bug
        var chanQueryString = 'channel/' + chanId[0].slice(21,57)  + '/' +
        $scope.timeFrame[0] + '/' + $scope.timeFrame[1];
        xx = xx.replace(chanIdPatternRE, '<a ng-click="channelId()" href="' + xsiEventApp + chanQueryString + ' ">' + chanId +
         '#chanId' + '</a>');
      }
      /**
       * [subIdPatternRE Regular Expression to Capture subscriptionId]
       * @type {[string]}
       */
      var subIdPatternRE = /(&lt;xsi:subscriptionId&gt;.*&lt;\/xsi:subscriptionId&gt;)/g;
      var subId = xx.match(subIdPatternRE);
      //console.log(subId);
      if (subId) {
        //console.log(subId);
        var QueryString = 'subscription/' + subId[0].slice(26,62) + '/' +
         $scope.timeFrame[0] + '/' + $scope.timeFrame[1];
        xx = xx.replace(subIdPatternRE,'<a  href="' + xsiEventApp + QueryString + ' ">' +
         subId + '#subId' + '</a>');
      }
      /**
       * [eventIdPatternRE Regular Expression to Capture EventId]
       * @type {[string]}
       */
      var eventIdPatternRE = /(&lt;xsi:eventID&gt;.*&lt;\/xsi:eventID&gt;)/g;
      var eventId = xx.match(eventIdPatternRE);
      if (eventId) {
        var eventQueryString = 'event/' + eventId[0].slice(19,55) + '/' +
         $scope.timeFrame[0] + '/' + $scope.timeFrame[1];
        //console.log(eventId);
        xx = xx.replace(eventIdPatternRE ,'<a  href="' + xsiEventApp  + eventQueryString  + ' ">'  +
        eventId + '#Event' + '</a>');
      }
      logMessage = logMessage.concat(xx);
    }
    return [logMessage, logFile];
  };

  /**
   * [fetchLogMessage It returns the revelant log based on the correlationid]
   * @param  {[number]} correlationid [Correlation ID(Unique ID) for SIP calls]
   * @param  {[uniquetime]} uniquetime    [provide timestamp as name for log file being donwloaded]
   * @return {[type]}               [description]
   */
  $scope.fetchLogMessage = function (correlationid, uniquetime) {
    var time = assignTime();
    $scope.fromTime = time[0];
    $scope.endTime = time[1];
    // console.log($scope.fromTime);
    // console.log($scope.endTime);
    $scope.progress = 'true';
    $scope.logM = null;
    $http.get('../api/sip/logmessage',{
      params:{
        correlationId: $scope.corridId
      }
    }).then((response) => {
      var myArr = response.data.hits.hits;
      if (myArr.length < 1)
      {
        alert('No Logs Found');
      }

      /**
       * [result description holds logMessage, logFile]
       * [result [0]logMessage formatted output displayed to user]
       * [resut [1]logFile original text file]
       * @type {[object]}
       */
      var result = autoLink(myArr, uniquetime);
      //AngularJs does not support rendering the HTML components
      //so We need to trustAsHtml before sending to ng-model
      //$scope.logM = $sce.trustAsHtml(logMessage);
      $scope.logM = $sce.trustAsHtml(result[0]);
      //console.log(logMessage);
      //$scope.logFileMessage = logFile;
      $scope.logFileMessage = result[1];
      $scope.progress = 'false';
    });
  };

  /**
   * [downloadFile Writes the log information to filename]
   * @return {[text]} [logfile]
   */
  $scope.downloadFile = function () {
    var element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent($scope.logFileMessage));
    element.setAttribute('download', 'siplog_' + $scope.corridId + '.txt');
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  /**
   * [fullScreen Make fullScreen of Complete Log Panel]
   * @return {[void]}
   */
  $scope.fullScreen = function () {

    if ($scope.fullScreenMode === true) {
      $scope.cssClass = 'col-md-8';
      //console.log($scope.cssClass);
      $scope.fullScreenMode = false;
    }
    else {
      $scope.fullScreenMode = true;
      $scope.cssClass = 'col-md-12';
      //console.log($scope.cssClass);
    }
  };

})
.controller('configuration', function ($scope, $route, $cookies) {

  $scope.resultOrder = ['Ascending', 'Descending'];
  $scope.displayMode = ['Enabled', 'Disabled'];
  $scope.globalSeting = function () {
    console.log($scope.Data);
    $cookies.put('globalConfiguration', JSON.stringify($scope.Data));
  };
})
.controller('logCollectionInv', function ($scope, $route, $http, ngDialog) {

  console.log('this is test page by hari');
  function validateIPaddress(inputText)  {

    var RegE = /^\d{1,3}.\d{1,3}.\d{1,3}.\d{1,3}$/;
    if (inputText.match(RegE)) {
      //$scope.openModalBox('Em');
    }
    else {
      $scope.openModalBox('You have entered an invalid IP address!');
      return 0;
    }
  };

  /**
  * @desc Comman Non Modal Box for alert.
  * @param message- contains message to be displayed to user
  * @return void
  */
  $scope.openModalBox = function (message) {
    ngDialog.open({ template: '<p>' + message + '</p>', plain: true });
  };

  $scope.collectDetails = function () {
    console.log('this is test page by harinath');
    var status = validateIPaddress($scope.Server);
    if (status === 0) {
      return;
    }
    $http.get('../api/sip/callJar',{
      params:{
        UserId: $scope.user,
        UserPass: $scope.UserPass,
        UserServer: $scope.Server
      }
    }).then((response) => {

    });
  };



});
