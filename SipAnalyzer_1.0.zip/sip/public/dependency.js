
// Time Picker
import './css/bootstrap-datetimepicker.min.css';
import './js/bootstrap-datetimepicker.min.js';
// Sticky Header
import './js/float-panel.js';

import './css/master.css';
// Angular Tooltip
import './css/angular-tooltips.css';
import './js/angular-tooltips.js';

// Ng model
import './css/ngDialog.css';
import './css/ngDialog-theme-plain.css';
import './css/ngDialog-theme-default.css';
import './js/ngDialog.js';

// Pagination
import './js/dirPagination.js';

//Cookies
import './js/angular-cookies.js';
