import $ from 'jquery';
import moment from 'moment';
import chrome from 'ui/chrome';
import uiModules from 'ui/modules';
import uiRoutes from 'ui/routes';
var angular = require('angular');
require('bootstrap');
import './dependency.js';
import './less/main.less';
import overviewTemplate from './templates/index.html';
import newTemplate from './templates/allMsgTemplate.html';
import settingPage from './templates/configuration.html';

uiRoutes.enable();
uiRoutes
.when('/channel/:channelID/:startDt/:endDt/', {
  template: newTemplate,
  controller: 'xsiREvent',
  controllerAs: 'ctrl'
})
.when('/subscription/:subscriptionID/:startDt/:endDt/', {
  template: newTemplate,
  controller: 'xsiREvent',
  controllerAs: 'ctrl'
})
.when('/event/:eventID/:startDt/:endDt/', {
  template: newTemplate,
  controller: 'xsiREvent',
  controllerAs: 'ctrl'
})
.when('/user/:userID/:startDt/:endDt/', {
  template: overviewTemplate,
  controller: 'xsiEvent',
  controllerAs: 'ctrl'
})
.when('/', {
  template: newTemplate,
  controller: 'xsiREvent',
  controllerAs: 'ctrl'
})
.when('/oldVersion', {
  template: overviewTemplate,
  controller: 'xsiEvent',
  controllerAs: 'ctrl'
})
.when('/Settings', {
  template: settingPage,
  controller: 'settingsController'
})
.when('', {
  template: newTemplate,
  controller: 'xsiREvent',
  controllerAs: 'ctrl'	
}).otherwise({ redirectTo: '/' })
;
