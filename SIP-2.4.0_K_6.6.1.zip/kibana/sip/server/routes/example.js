var http = require('http');

var querystring = require('querystring');
export default function(server) {

  /*
    Connection to Elasticsearch
 */
  var _server$plugins$elasticsearch$getCluster = server.plugins.elasticsearch.getCluster('data');
  console.log(_server$plugins$elasticsearch$getCluster);
  let elasticClient = _server$plugins$elasticsearch$getCluster.callWithRequest;

  /**
   * [errorMessage : Return the error message]
   * @return {[String]} [Error Code]
   */
  var errorMessage = function() {
    return 'Error';
  };

  /**
   * [checkDocumentExists Frames Elasticsearch Query for checking the document Exists in Elasticsearch]
   * @param {[String]} pattern [pattern index]
   * @return {[String]} [ES Query]
   */
  var checkDocumentExists = function(pattern) {
    var query = {
      'query': {
        'constant_score': {
          'filter': {
            'term': {
              'index_alias': pattern
            }
          }
        }
      }
    };
    return query;
  };

  /**
   * [frameIndexBody Frames Elasticsearch Query for Indexing the document in Elasticsearch]
   * @param  {[String]} document [description]
   * @param  {[String]} header   [description]
   * @return {[String]}          [ES Query]
   */
  var frameIndexBody = function(document, header) {
    var size = document.length;
    var body = [];
    for (var i = 0; i < size; i++) {
      body.push(header);
      body.push(document[i]);
    }
    return body;
  };

  /**
   * [addIndex Push the Index Pattern into Elasticsearch]
   * @param {[String]} req [request object]
   */
  var addIndex = function(req) {
    var document = req.query.document;
    var header = '{"index": {"_index": "indexpattern", "_type": "pattern"}}';
    var doc = [];
    if (document instanceof Array) {
      doc = frameIndexBody(document, header);
    } else {
      doc.push(header);
      doc.push(document);
    }
    elasticClient(req, 'bulk', {
      'requestTimeout': 60000,
      body: doc
    }).then(function(response) {
      return response;
    }, function(error) {
      return 'Unexpected Error';
    });
  };


  /**
   * [multiSearch Perform multisearch for list of correlationid generated]
   * @param  {[object]} keyPair  [Contains the correlationId and count]
   * @param  {[type]} fromTime [Contains Start Time]
   * @param  {[type]} toTime   [Contains End Time]
   * @param  {[object]} req    [Contains Request Handler]
   * @return {[type]}          [description]
   */
  var multiSearch = function(keyPair, fromTime, toTime, req) {
    var corridLength = keyPair.length;
    var queryBody = [];
    if (corridLength < 1) {
      console.log('Cant check empty corridLength');
      return;
    } else {
      for (var x = 0; x < corridLength; x++) {
        queryBody.push('{"index": "bwlog*"}');
        var query = {
          size: 1,
          query: {
            filtered: {
              query: {
                term: {
                  correlationid: keyPair[x].key
                }
              }
            }
          },
          sort: [{
            logtimestamp: {
              order: 'asc'
            }
          }],
          filter: {
            bool: {
              must: [{
                range: {
                  logtimestamp: {
                    gte: fromTime,
                    lte: toTime,
                    format: 'epoch_millis'
                  }
                }
              }]
            }
          }
        };
        queryBody.push(query);
      } // End of Else statement
      // Multisearch query
      return elasticClient(req, 'msearch', {
        'requestTimeout': 60000,
        body: queryBody
      }).then(function(response) {
        return response.responses;
      });
    }
  };


  /*
  Reading the configuration file in SIP APP folder
  Filename: tribenode.json
 */
  server.route({
    path: '/api/sip/readConfigFile',
    method: 'GET',
    handler(req, h) {
      // Home Location of the Kibana
      var config = require('../../tribenode.json');
      // Check the Javaclient key is present in the json file
      if (typeof config.javaClient === 'undefined') {
        // If the file does not contains the required key, Reply with Error Message
        return 'Error in Configuration File';
      } else {
        return config.javaClient;
      }
    }
  });

  server.route({
    path: '/api/sip/testing',
    method: 'GET',
    handler(req, h) {
      var oldBrowsers = [{
          label: 'Netscape Navigator',
          maker: 'Netscape Corporation',
          ticked: true
        },
        {
          label: 'Amaya',
          maker: 'Inria & W3C',
          ticked: true
        },
        {
          name: 'WorldWideWeb Nexus',
          maker: 'Tim Berners-Lee',
          ticked: false
        }
      ];
      //var old = [ {id: 1, label: 'David'}, {id: 2, label: 'Jhon'}, {id: 3, label: 'Danny'} ];
      return oldBrowsers;
    }
  });


  /**
   * [path Add the Index Pattern into Elasticsearch]
   * @type {String}
   * Check whether the document exits first
   * Based on that it takes decision whether to index or not
   */
  server.route({
    path: '/api/sip/addTribeIndexPattern',
    method: 'GET',
    async handler(req, h) {
      try {
        //console.log(req.query.advanceQuery);
        const response = await elasticClient(req, 'search', {
        index: 'indexpattern',
        'requestTimeout': 60000,
        body: checkDocumentExists(req.query.pattern)
      });
        // If count greater than one, document already exits
        if (response.hits.total > 0) {
          return 'Pattern Already Exists';
        } else {
          return addIndex(req);
        }
         // return addIndex(req);
      } catch (errorResponse) {
        return errorResponse;
      }
    }
  });

  /**
   * [path Select the Index Pattern Available for Tribe Node]
   * @return {response}
   */
  server.route({
    path: '/api/sip/selectTribeIndexPattern',
    method: 'GET',
    async handler(req, h) {
      try {
        //console.log(req.query.advanceQuery);
        const response = await elasticClient(req, 'search', {
          index: 'indexpattern',
          'requestTimeout': 60000,
          'size': 100
        });
        return response;
      } catch (errorResponse) {
        return errorResponse;
      }
    }
  });

  /**
   * [path Removes the specified Index Pattern from Elasticsearch]
   * @type {response}
   */
  server.route({
      path: '/api/sip/removeIndexPattern',
      method: 'GET',
      async handler(req, h) {
      try {
        //console.log(req.query.advanceQuery);
        const response = await elasticClient(req, 'delete', {
          index: 'indexpattern',
          type: 'pattern',
          id: req.query.documentID
        });
        return response;
      } catch (errorResponse) {
        return errorResponse;
      }
    }
  });

/**
 * [path Update Index Pattern]
 * Only applicable for changing the Index Alias Name
 * @type {String}
 */
server.route({
  path: '/api/sip/updateTribeIndexPattern',
  method: 'GET',
  async handler(req, h) {
    try {
      //console.log(req.query.advanceQuery);
      const response = await elasticClient(req, 'update', {
        index: 'indexpattern',
        type: 'pattern',
        id: req.query.documentID,
        body: {
          doc: {
            index_alias: req.query.updatedPattern
          }
        }
      });
      return response;
    } catch (errorResponse) {
      return errorResponse;
    }
  }
});

/**
 * [path Reads the JavaClient IP Address]
 * Read the address info along with port info from the file
 *
 */
server.route({
  path: '/api/sip/readServer',
  method: 'GET',
  handler(req, h) {
    // Home Location of the Kibana
    var config = require('../../tribenode.json');
    if (typeof config.javaClient === 'undefined') {
      return 'Error in Configuration File';
    } else {
      return config.javaClient;
    }
  }
});

var readConfigurationFile = function() {
  var config = require('../../tribenode.json');
  if (typeof config.javaClient === 'undefined') {
    return 'Error in Configuration File';
  } else {
    return config.javaClient;
  }
};

server.route({
  path: '/api/sip/sipCallFlowLogCollector',
  method: 'GET',
  async handler(req, h) {
    var serverInfo = readConfigurationFile();
    if (serverInfo === 'Error in Configuration File') {
      return 'Error';
    }
    // Check the whether IP address and port is given
    var address = serverInfo.split(':');
    var options = {
      host: address[0],
      path: req.query.queryString,
      //since we are listening on a custom port, we need to specify it by hand
      port: address[1],
      //This is what changes the request to a POST request
      method: 'GET'
    };
    //console.log(options);
    try {
      var result = '';
      var req = http.request(options, function(response) {

        response.on('data', function(partial) {
          //console.log("enter");
          result += partial;
          //console.log("result = "+result);
        });

      });
      req.on('error', function(e) {
        console.error(e);
      });
      req.end();

      await new Promise(function(resolve) {
        var res = setInterval(function() {
          if (req.finished) {
            resolve();
            clearInterval(res);
          }
        }, 1000);
      });
      return result;
    } catch (errorResponse) {
      return "Empty";
    }
  }
});

server.route({
  path: '/api/sip/ociTranscationLogCollector',
  method: 'GET',
  async handler(req, h) {
    var serverInfo = readConfigurationFile();
    if (serverInfo === 'Error in Configuration File') {
      return 'Error';
    }
    // Check the whether IP address and port is given
    var address = serverInfo.split(':');
    var options = {
      host: address[0],
      path: req.query.queryString,
      //since we are listening on a custom port, we need to specify it by hand
      port: address[1],
      //This is what changes the request to a POST request
      method: 'GET'
    };
    try {
      var result = '';
      var req = http.request(options, function(response) {

        response.on('data', function(partial) {
          //console.log("enter");
          result += partial;
          //console.log("result = "+result);
        });

      });
      req.on('error', function(e) {
        console.error(e);
      });
      req.end();

      await new Promise(function(resolve) {
        var res = setInterval(function() {
          if (req.finished) {
            resolve();
            clearInterval(res);
          }
        }, 1000);
      });
      return result;
    } catch (errorResponse) {
      return "Empty";
    }
  }
});

server.route({
  path: '/api/sip/logCollector',
  method: 'GET',
  handler(req, h) {
    var serverInfo = readConfigurationFile();
    if (serverInfo === 'Error in Configuration File') {
      return 'Error';
    }
    // Check the whether IP address and port is given
    var address = serverInfo.split(':');
    var path = '/queryGroup?an=' + req.query.username + '&pwd=' +
      req.query.password + '&sp=' + req.query.providername + '&grp=' +
      req.query.groupname + '&h=' + req.query.groupserver + '&cm=' + req.query.connectionmode;
    http.get({
      hostname: address[0],
      port: address[1],
      path: path,
      agent: false // create a new agent just for this one request
    }, (response) => {
      return response;
    });
  }
});

server.route({
  path: '/api/sip/fetchToolTipInfo',
  method: 'GET',
  async handler(req, h) {
    var corridLength;
    var idHolder = [];
    if (req.query.corrid instanceof Array) {
      corridLength = req.query.corrid.length;
      idHolder = req.query.corrid;
    } else {
      //console.log('Not an Array Object');
      idHolder.push(req.query.corrid);
      corridLength = 1;
    }
    //var corridLength = req.query.corrid.length;
    var queryBody = [];
    if (corridLength < 1) {
      console.log('Cant check empty corridLength');
      return;
    } else {
      //console.time('testing');
      var index = '{"index": ' + '"' + req.query.searchIndex + '"' + '}';
      for (var x = 0; x < corridLength; x++) {
        queryBody.push(index);
        var query = {
          _source: {
            exclude: ['application', 'siptype', 'sipdirection', 'source', 'server', 'channel', 'sourcefilename', 'sipmethod']
          },
          size: 1,
          query: {
            bool: {
              must: [{
                term: {
                  'correlationid': idHolder[x]
                }
              }],
              'filter': [{
                'term': {
                  'sipmethod': req.query.method
                }
              }]

            }
          },
          sort: [{
            logtimestamp: {
              order: 'asc'
            }
          }]
        };
        queryBody.push(query);
        //console.log(query);
      }
    } // End of Else statement
    try {
      //console.log(req.query.advanceQuery);
      const response = await elasticClient(req, 'msearch', {
        'requestTimeout': 60000,
        body: queryBody
      });
      return response.responses;
    } catch (errorResponse) {
      return errorResponse;
    }
  }

});


//Function Block to retrieve the correlationid along with Timestamp
// Improvment: Move the query building section outside this function block
server.route({
  path: '/api/sip/listCorrelationId',
  method: 'GET',
  async handler(req, h) {
    var arr = [];
    try {
      //console.log(req.query.advanceQuery);
      const response = await elasticClient(req, 'search', {
        index: req.query.searchIndex,
        'size': 0,
        body: req.query.advanceQuery
      });
      if (response.hits.hits.length === 0) {
        try {
          var keypair = {};
          keypair = response.aggregations.corrid_agg.buckets;
          if (keypair.length > 0) {
            return keypair;
          } else {
            return 'Empty';
          }
        } catch (e) {
          return 'Empty';
        }
      } else {
        //console.log(JSON.stringify(response));
        // Returns the list of correlationId along with document count
        // To the browser for processing
        var keyPair = {};
        keyPair = response.aggregations.corrid_agg.buckets;
        // Call the query builder function and pass the array
        // HIK Sep-05-2016
        // Change the length greater than zero from One
        if (keyPair.length > 0) {
          return keyPair;
        } else {
          //At Times, results are empty while fetching correlationId
          return response;
        }
      }
    } catch (error) {
      console.log('Data not Found');
      console.log(errorMessage());
      return errorMessage();
    }
  }
});


//getuserinfo
server.route({
  path: '/api/sip/logtimestamp',
  method: 'GET',
  async handler(req, h) {
    const response = await elasticClient(req, 'search', {
      index: req.query.searchIndex,
      body: req.query.searchBody
    });
    return response;
  }
});


// Function block to retrieve logs
// Based on the correlationid
server.route({
  path: '/api/sip/logmessage',
  method: 'GET',
  async handler(req, h) {
    try {
      const response = await elasticClient(req, 'search', {
        index: req.query.searchIndex,
        'size': 1500,
        body: {
          'sort': [{
            'logtimestamp': {
              'order': 'asc'
            }
          }],
          'query': {
            'term': {
              'correlationid': req.query.correlationId
            }
          }
        }
      });

      if (response.hits.hits) {
        return (response);
      } else {
        return (errorMessage());
      }
    } catch (errorResponse) {
      // Error Block
      return errorMessage();
      console.log(errorMessage());
    }

  }
});

server.route({
  path: '/api/sip/advanceSearch',
  method: 'GET',
  async handler(req, h) {
    try {
      const response = await elasticClient(req, 'search', {
        index: req.query.searchIndex,
        'size': 1000,
        body: req.query.advanceQuery
      });
      // Success Block
      if (response.hits.hits) {
        return response;
      } else {
        return errorMessage();
      }
    } catch (errorResponse) {
      // Error Block
      return errorMessage();
      console.log(errorMessage());
    }
  }
});


}; // - End of Default function block
