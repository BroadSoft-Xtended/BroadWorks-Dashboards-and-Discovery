import serverRoute from './server/routes/example';

var path = require('path');
module.exports = function (kibana) {

  var mainFile = 'plugins/sip/app/';
  return new kibana.Plugin({
    require: ['kibana','elasticsearch'],

    uiExports: {
      app: {
        title: 'SIP Analyzer',
        description: 'An Awesome Kibana SIP Plugin',
        main: mainFile,
        icon: 'plugins/sip/resource/logo-scaled.png',
      }
    },

    init(server) {
        server.injectUiAppVars('sip', () => {
        return {
          kbnIndex: server.config.kbnIndex,
          esShardTimeout: server.config.esShardTimeout,
          esApiVersion: server.config.esApiVersion,
        };
      });
      // Add server routes and initalize the plugin here
      serverRoute(server);
    }

  });
};
