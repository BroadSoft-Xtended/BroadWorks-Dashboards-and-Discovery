import {
  uiModules
} from 'ui/modules';
var angular = require('../js/angular');
uiModules
  .get('app/sip', ['ngDialog', 'ngCookies', 'pascalprecht.translate'])

  .controller('correlationIdRedirectController', function($scope, $route, $interval, $http, $sce, $routeParams, $cookies, ngDialog, $translate) {

    /**
     * [setActiveClass Add class to the idMenu ID Dom]
     */
    $scope.setActiveClass = function() {
      var navList = angular.element(document.querySelector('#idMenu'));
      navList.addClass('active');
    };

    /**
     * @desc Comman Non Modal Box for alert.
     * @param message- contains message to be displayed to user
     * @return void
     */
    $scope.openModalBox = function(message) {
      ngDialog.open({
        template: '<p>' + message + '</p>',
        plain: true
      });
    };



    /**
     * [fetchGlobalInfo Read the value from the cookie stored]
     * @return {[void]} [description]
     */
    $scope.fetchGlobalInfo = function() {
      var globalCookie = $cookies.get('globalConfiguration');
      if (globalCookie) {
        $scope.test = globalCookie;
        var json = JSON.parse(globalCookie);
        console.log('Custom Settings Applied');
        console.log(json);
        if (json.sort === 'Ascending') {
          $scope.sortPreference = 'asc';
        } else if (json.sort === 'Descending') {
          $scope.sortPreference = 'desc';
        }
        if (json.index) {
          console.log(json.index);
          $scope.searchIndex = json.index;
        }
        $scope.sampleSize = json.size;
      } else {
        console.log('Default Settings is Applied');
        $scope.searchIndex = 'bwlog*';
        $scope.sortPreference = 'asc';
        $scope.sampleSize = '1000';
      }
    };
    $scope.fetchGlobalInfo();

    /**
     * [reset Intialize and Reset to the original Value]
     * @param  {[string]} uniquetime [log file timestamp]
     */
    $scope.reset = function() {
      $scope.corridId = $routeParams.callId;;
      $scope.qsearch = null;
      $scope.logM = null;
    };

    //reset() is invovked by below statement
    $scope.reset();


    /**
     * [htmlEntities Replace the HTML begining and closing Tags]
     * @param  {[string]} str [logmessage ]
     * @return {[type]}     [All the HTML tags are converted into &lt and &gt]
     */
    function htmlEntities(str) {
      return String(str).replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    /**
     * [renderLogMessage renders the logmessage for given correlationId]
     * @param  {[object]} myArr      [json object from server]
     * @param  {[string]} uniquetime [log file timestamp]
     * @return {[object]}            [holds logmessage, logfile]
     */
    function renderLogMessage(myArr, uniquetime) {
      var logMessage = '';
      var logFile = '';
      //logFile model variable is used hold log message for  file being downloaded
      $scope.logFile = myArr;
      $scope.logFileName = uniquetime;
      var xsiEventApp = '/app/xsi_event#/';
      var sipCallFlow = '/app/sip#/Sip-Call-Flow/id/';
      /**
       * [timeFrame - It hold the fromTime and endTime]
       * [desc - As we need to launch XSI event APP we need to pass epooch begining
       * and current epoch milli time]
       * @type {Array}
       */
      $scope.timeFrame = ['0000000000000', new Date().getTime()];
      // Below code snippet is used to decorate the Log Message First Line
      for (var i = 0; i < myArr.length; i++) {
        var xx = htmlEntities(myArr[i]._source.source);
        logFile = logFile.concat(myArr[i]._source.source);
        /**
         * [firstLinePatternRE used to hold the regex for the first line]
         * Used to capture the first Line in log message, refer CallCorrelationIdentifierFD-R200
         * @type {[string]}
         */
        var firstLinePatternRE = /^(\d{4}\.\d{2}\.\d{2}\s+.*)\n/g;
        var y = xx.match(firstLinePatternRE);
        xx = xx.replace(firstLinePatternRE, '<div id="decorate">' + y[0] + '</div>');

        var correlationIdPatternRe = /\s\w{8}-\w{4}-\w{4}-\w{4}-\w{12}\s/g;
        var correlationId = xx.match(correlationIdPatternRe);
        xx = xx.replace(correlationIdPatternRe,
          '<a href="' +
          sipCallFlow + correlationId[0].trim() + '" data-context-menu="custom.html"' +
          '" target="_blank" >' + correlationId + '</a>');
        /**
         * [chanIdPatternRE Regular Expression to Capture ChannelId]
         * @type {[string]}
         */
        var chanIdPatternRE = /(&lt;xsi:channelId&gt;.*&lt;\/xsi:channelId&gt;)/g;
        var chanId = xx.match(chanIdPatternRE);
        if (chanId) {
          //console.log($scope.timeFrame[0] / 1000.0);
          // Time is normalized to epooch due to xsi event bug
          var chanQueryString = 'channel/' + chanId[0].slice(21, 57) + '/' +
            $scope.timeFrame[0] + '/' + $scope.timeFrame[1];
          xx = xx.replace(chanIdPatternRE, '<a ng-click="channelId()" href="' + xsiEventApp +
            chanQueryString + '" target="_blank ">' + chanId +
            '#chanId' + '</a>');
        }
        /**
         * [subIdPatternRE Regular Expression to Capture subscriptionId]
         * @type {[string]}
         */
        var subIdPatternRE = /(&lt;xsi:subscriptionId&gt;.*&lt;\/xsi:subscriptionId&gt;)/g;
        var subId = xx.match(subIdPatternRE);
        //console.log(subId);
        if (subId) {
          //console.log(subId);
          var QueryString = 'subscription/' + subId[0].slice(26, 62) + '/' +
            $scope.timeFrame[0] + '/' + $scope.timeFrame[1];
          xx = xx.replace(subIdPatternRE, '<a  href="' + xsiEventApp + QueryString + '" target="_blank ">' +
            subId + '#subId' + '</a>');
        }
        /**
         * [eventIdPatternRE Regular Expression to Capture EventId]
         * @type {[string]}
         */
        var eventIdPatternRE = /(&lt;xsi:eventID&gt;.*&lt;\/xsi:eventID&gt;)/g;
        var eventId = xx.match(eventIdPatternRE);
        if (eventId) {
          var eventQueryString = 'event/' + eventId[0].slice(19, 55) + '/' +
            $scope.timeFrame[0] + '/' + $scope.timeFrame[1];
          //console.log(eventId);
          xx = xx.replace(eventIdPatternRE, '<a  href="' + xsiEventApp + eventQueryString + '" target="_blank ">' +
            eventId + '#Event' + '</a>');
        }
        logMessage = logMessage.concat(xx);
      }
      return [logMessage, logFile];
    };

    /**
     * [fetchLogMessage It returns the revelant log based on the correlationid]
     * @param  {[number]} correlationid [Correlation ID(Unique ID) for SIP calls]
     * @param  {[uniquetime]} uniquetime    [provide timestamp as name for log file being donwloaded]
     * @return {[type]}               [description]
     */
    $scope.fetchLogMessage = function(correlationid, uniquetime) {

      $scope.progress = 'true';
      $scope.logM = null;
      $scope.CorrId = $scope.corridId;
      $http.get('../api/sip/logmessage', {
        params: {
          searchIndex: $scope.searchIndex,
          correlationId: $scope.corridId
        }
      }).then((response) => {
        if (response.data === 'Error') {
          $scope.openModalBox('No Logs Found');
          $scope.progress = 'false';
          return;
        }
        var myArr = response.data.hits.hits;
        if (myArr.length < 1) {
          $scope.openModalBox('No Logs Found');
        }

        /**
         * [result description holds logMessage, logFile]
         * [result [0]logMessage formatted output displayed to user]
         * [resut [1]logFile original text file]
         * @type {[object]}
         */
        var result = renderLogMessage(myArr, uniquetime);
        //AngularJs does not support rendering the HTML components
        //so We need to trustAsHtml before sending to ng-model
        //$scope.logM = $sce.trustAsHtml(logMessage);
        $scope.logM = $sce.trustAsHtml(result[0]);
        $scope.logFileMessage = result[1];
        $scope.progress = 'false';
      });
    };

    $scope.fetchLogMessage($scope.corridId);
    /**
     * [rangeSelector Allows to select only complete log message panel]
     * @param  {[string]} containerid [name of the container]
     * @return {[void]}             [void]
     */
    $scope.rangeSelector = function(containerid) {
      var range = '';
      var node = document.getElementById(containerid);

      if (document.selection) {
        range = document.body.createTextRange();
        range.moveToElementText(node);
        range.select();
      } else if (window.getSelection) {
        range = document.createRange();
        range.selectNodeContents(node);
        window.getSelection().removeAllRanges();
        window.getSelection().addRange(range);
      }
    };

    /**
     * [keyCode Self Invoking function]
     * @type {[keyword event]}
     */
    $scope.keyDown = function(e) {
      if (e.keyCode === 65 && e.ctrlKey) {
        $scope.rangeSelector('CorridCompleteLog');
        e.preventDefault();
      }
    };


    /**
     * [downloadFile Writes the log information to filename]
     * @return {[text]} [logfile]
     */
    $scope.downloadFile = function() {
      var element = document.createElement('a');
      element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent($scope.logFileMessage));
      element.setAttribute('download', 'siplog_' + $scope.corridId + '.txt');
      element.style.display = 'none';
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    };

    /**
     * [fullScreen Make fullScreen of Complete Log Panel]
     * @return {[void]}
     */
    $scope.fullScreen = function() {

      if ($scope.fullScreenMode === true) {
        $scope.fullScreenMode = false;
        document.getElementById('full-screen-container').style.marginTop = null;
      } else {
        $scope.fullScreenMode = true;
        document.getElementById('full-screen-container').style.marginTop = '100px';
      }
    };

  });
