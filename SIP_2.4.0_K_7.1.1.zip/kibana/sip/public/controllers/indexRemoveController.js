import {
  uiModules
} from 'ui/modules';
uiModules
  .get('app/sip', ['ngDialog', 'ngCookies'])
  .controller('indexRemoveController', function($scope, $route, $http, $cookies, ngDialog) {

    $scope.fetchIndexPattern = function() {
      $scope.progress = 'true';
      $http.get('../api/sip/selectTribeIndexPattern').then((response) => {
        console.log(response);
        if (response.data !== 'Error') {
          $scope.indexRemove = response.data.hits.hits;
        } else {
          $scope.openErrorAlert('ERROR :( - No Entries Present');
        }
      }, function errorCallback(response) {
        console.log('ERROR');
        $scope.progress = 'false';
        $scope.openErrorAlert('ERROR :( - Could not Access Server');
      });
    };
    $scope.fetchIndexPattern();

    $scope.removeIndexPattern = function(ID) {
      $scope.progress = 'true';
      $http.get('../api/sip/removeIndexPattern', {
        params: {
          documentID: ID._id,
        }
      }).then((response) => {
        $scope.openModalBox('Index Removed from List');
        setTimeout(function() {
          $scope.fetchIndexPattern();
        }, 2000);
      }, function errorCallback(response) {
        console.log('ERROR');
        $scope.progress = 'false';
        $scope.openErrorAlert('ERROR :( - Could not Access Server');
      });
    };

    // Could not able to index data
  });
