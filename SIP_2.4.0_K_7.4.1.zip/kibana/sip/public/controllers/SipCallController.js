import {
  uiModules
} from "ui/modules";
var angular = require("../js/angular");
var $ = require("jquery");

uiModules
  .get("app/sip", [
    "720kb.tooltips",
    "ngDialog",
    "angularUtils.directives.dirPagination",
    "ngCookies",
    "pascalprecht.translate"
  ])
  .config([
    "$translateProvider",
    function($translateProvider) {
      /*
    translate Module Left Intact with English as primary and only Language
    Can be expanded for other Language
    When you do, read from JSON file instead of having key: value in controller directly
     */
      $translateProvider.translations("english", {
        APP_NAME: "SIP Call Correlation ID Utility",
        APP_NAME_ID: "Search - Correlation ID Log Dump",
        APP_NAME_ADV: "Advance Search",
        PANEL_HEADING: "Frame Query",
        DISPLAY_PANEL_HEADING: "Complete Log",
        SEARCH_LABEL: "Search",
        DOWNLOAD_BUTTON: "Download",
        DATE_TIME: "Date/Time Selection",
        ABSOLUTE: "Absolute",
        RELATIVE: "Relative",
        START_TIME: "Start Date",
        END_TIME: "End Date",
        RESET_BUTTON: "Reset",
        REQUIRED_LABEL: "Required"
      });
      $translateProvider.useSanitizeValueStrategy("escape");
      $translateProvider.preferredLanguage("english");
    }
  ])
  .controller("sipController", function(
    $scope,
    $route,
    $http,
    $sce,
    $filter,
    $window,
    ngDialog,
    $cookies,
    $translate
  ) {
    /**
     * [setActiveClass: Sets the Active Class]
     */
    $scope.setActiveClass = function() {
      var navList = angular.element(document.querySelector("#homeMenu"));
      navList.addClass("active");
    };

    /**
     * [clearOutputPanel Clear the content in output panel]
     * @return {[void]}
     */
    var clearOutputPanel = function() {
      $scope.logM = null;
    };

    /**
     * [setCorrelationIdPanelFalse :Set CorrelationId panel to false]
     */
    $scope.setCorrelationIdPanelFalse = function() {
      $scope.progressId = "false";
    };

    /**
     * [setCorrelationIdPanelFalase :Set CorrelationId panel to true]
     */
    $scope.setCorrelationIdPanelTrue = function() {
      $scope.progressId = "true";
    };

    // Calling Calendar Methods Via Jquery
    $(function() {
      $("#datetimepicker1").datetimepicker({
        allowInputToggle: true
      });
      $("#datetimepicker2").datetimepicker({
        allowInputToggle: true
      });
    });
    /**
     * [rangeSelector Allows to select only complete log message panel]
     * @param  {[string]} containerid [name of the container]
     * @return {[void]}             [void]
     */
    $scope.rangeSelector = function(containerid) {
      var range = "";
      var node = document.getElementById(containerid);

      if (document.selection) {
        range = document.body.createTextRange();
        range.moveToElementText(node);
        range.select();
      } else if (window.getSelection) {
        range = document.createRange();
        range.selectNodeContents(node);
        window.getSelection().removeAllRanges();
        window.getSelection().addRange(range);
      }
    };

    /**
     * [keyDown Self Invoking function]
     * @type {[keyword event]}
     */
    $scope.keyDown = function(e) {
      if (e.keyCode === 65 && e.ctrlKey) {
        $scope.rangeSelector("completeLog");
        e.preventDefault();
      }
    };

    /**
     * @desc Comman Non Modal Box for alert.
     * @param message- contains message to be displayed to user
     * @return void
     */
    $scope.openModalBox = function(message) {
      ngDialog.open({
        template: "<p>" + message + "</p>",
        plain: true
      });
    };

    /**
     * @desc Converts the current time into epoch_millis format
     * @param no params
     * @return void
     */
    var getCurrentTime = function() {
      var CurrentTime = $filter("date")(new Date(), "MM/dd/yyyy hh:mm a");
      return new Date(CurrentTime).getTime();
    };

    /**
     * @desc Get the relative time based on the option selected 'Relative time'
     * @desc Calculation for relative time = Mins * 60 * 1000
     * @param no params
     * @return void
     */
    var getRelativeTime = function() {
      var relativeTime;
      var currentTime = getCurrentTime();
      switch ($scope.selectedRelative) {
        case "5 Min":
          relativeTime = currentTime - 300 * 1000;
          break;
        case "10 Min":
          relativeTime = currentTime - 600 * 1000;
          break;
        case "15 Min":
          relativeTime = currentTime - 900 * 1000;
          break;
        case "1 Hour":
          relativeTime = currentTime - 3600 * 1000;
          break;
        case "2 Hours":
          relativeTime = currentTime - 7200 * 1000;
          break;
        case "5 Hours":
          relativeTime = currentTime - 18000 * 1000;
          break;
        case "1 Day":
          relativeTime = currentTime - 86400 * 1000;
          break;
        case "1 Week":
          relativeTime = currentTime - 604800 * 1000;
          break;
        default:
          //By default it points to 5 Min
          relativeTime = currentTime - 300 * 1000;
      }
      return relativeTime;
    };

    /**
     * [choices Holds the multiple search Conditions]
     * @type {Array}
     */
    $scope.choices = [{}];
    /**
     * @desc Intialize and Reset to the original Value for SipController
     * @param no params
     * @return void
     */

    $scope.init = function() {
      choice.selectedMethod = SipMethod[0];
      $scope.searchBy();
      $scope.filterBy();
      choice.selectedCallOrigin = searchByOptions[0];
      choice.selectedFilter = filterByOptions[0];
    };

    $scope.reset = function() {
      $scope.time = {
        option: "Absolute"
      };
      $scope.DefaultTime = "07/30/2016 12:00 AM";
      $scope.PresentTime = $filter("date")(new Date(), "MM/dd/yyyy hh:mm a");
      $scope.TimeDuration = [
        "5 Min",
        "10 Min",
        "15 Min",
        "1 Hour",
        "2 Hours",
        "5 Hours",
        "1 Day",
        "1 Week"
      ];
      $scope.SipMethod = [
        "INVITE",
        "REGISTER",
        "NOTIFY",
        "SUBSCRIBE",
        "ACK",
        "BYE",
        "CANCEL",
        "OPTIONS",
        "PRACK",
        "PUBLISH",
        "INFO",
        "REFER",
        "MESSAGE",
        "UPDATE"
      ];
      $scope.searchByOptions = [
        "From",
        "To",
        "Request URI",
        "P-Asserted-Identity"
      ];
      $scope.filterByOptions = ["Domain", "User Part"];
      getRelativeTime();
      $scope.cssClass = "col-md-8";
      $scope.selectedFilter = false;
      $scope.qstring = false;
      $scope.choices[0].qsearch = "";
      $scope.firstRow = false;
      this.hits = null;
      clearOutputPanel();
      $scope.users = [];
      $scope.CorrId = null;
      $scope.pageSize = 20;
      $scope.currentPage = 1;
      // Recursively removes until the filter becomes one
      while ($scope.choices.length > 1) {
        $scope.removeCondition();
      }
    };

    //reset() is invovked by below statement
    $scope.reset();

    $scope.formReset = function() {
      $scope.resultLoad = "skip";
      $scope.reset();
    };

    /**
     * [fetchGlobalInfo Read the value from the cookie stored]
     * @return {[void]} [description]
     */
    $scope.fetchGlobalInfo = function() {
      var globalCookie = $cookies.get("globalConfiguration");
      if (globalCookie) {
        $scope.test = globalCookie;
        var json = JSON.parse(globalCookie);
        console.log("Custom Settings Applied");
        console.log(json);
        if (json.sort === "Ascending") {
          $scope.sortPreference = "asc";
        } else if (json.sort === "Descending") {
          $scope.sortPreference = "desc";
        }
        if (json.index) {
          $scope.searchIndex = json.index;
        }
        $scope.sampleSize = json.size;
      } else {
        console.log("Default Settings is Applied");
        $scope.searchIndex = "bwlog*";
        $scope.sortPreference = "asc";
        $scope.sampleSize = "1000";
      }
    };

    $scope.fetchGlobalInfo();

    /**
     * @desc Intialize searchBy Options
     * @param no params
     * @return void
     */
    $scope.searchBy = function() {
      $scope.searchByOptions = [
        "From",
        "To",
        "Request URI",
        "P-Asserted-Identity"
      ];
    };

    /**
     * @desc Intialize filterBy Options
     * @param no params
     * @return void
     */
    $scope.filterBy = function() {
      $scope.filterByOptions = ["Domain", "User Part"];
    };

    /**
     * @desc getting Absolute Time - From Time
     * @param no params
     * @return void
     */
    var getAbsoluteFromTime = function() {
      var UserFromDate = angular.element($("#userfromdate")).val();
      return new Date(UserFromDate).getTime();
    };

    /**
     * @desc getting Absolute Time - End Time
     * @param no params
     * @return void
     */
    var getAbsoluteToTime = function() {
      var UserToDate = angular.element($("#usertodate")).val();
      return new Date(UserToDate).getTime();
    };

    /**
     * @desc Facilate adding more search conditons
     * @param no params
     * @return nothing
     */
    $scope.addCondition = function() {
      // Prevents adding more than 5 search conditons
      if ($scope.choices.length + 1 > 5) {
        $scope.openModalBox("Further Filter Can Not be Applied");
        return;
      }
      var newItemNo = $scope.choices.length + 1;
      $scope.choices.push({
        newItemNo
      });
    };

    /**
     * @desc Remove the search filter which is added previously
     * @param no params
     * @return void
     */
    $scope.removeCondition = function() {
      // Must have atleast one search option
      // Prevent '-' button to remove all the fields
      if ($scope.choices.length === 1) {
        $scope.openModalBox("Atleast One Search Filter Needed");
        return;
      }
      var lastItem = $scope.choices.length - 1;
      $scope.choices.splice(lastItem);
    };

    /**
     * @desc Assign 'time from' and 'time to' based upon time context
     * @param no params
     * @return fromTime, toTime
     */
    var assignTime = function() {
      var fromTime;
      var endTime;
      // Relative Time Functionality
      if ($scope.time.option === "Relative") {
        fromTime = getRelativeTime();
        endTime = getCurrentTime();
      } else {
        // Absolute Time Functionality
        fromTime = getAbsoluteFromTime();
        endTime = getAbsoluteToTime();
      }
      $scope.timeFrame = [fromTime, endTime];
      return [fromTime, endTime];
    };

    /**
     * @desc Frames the search field based given input field, refer query matrix
     * @param searchBy, filterBy
     * @return term
     */
    var frameSearchField = function(searchBy, filterBy) {
      var condOne = searchBy;
      var term = "sip";
      // Deciding 'from' or 'to' Predicate
      if (!condOne.indexOf("From")) {
        term = term + "from";
      } else if (!condOne.indexOf("To")) {
        term = term + "to";
      } else if (!condOne.indexOf("Request")) {
        term = term + "ruri";
      } else if (!condOne.indexOf("P-Asserted-Identity")) {
        term = term + "pai";
      }

      var condTwo = filterBy;
      if (!condTwo.indexOf("Domain")) {
        term = term + "domain";
      } else {
        term = term + "user";
      }
      return term;
    };

    /**
     * @desc Helps to frame the search field query object
     * @desc It is consumed by fetchCorridTime
     * @param searchField - field name to be String
     * @param queryString - search string for the given searchField
     * @return searchField object which contains the object
     */
    var frameSearchFieldBuilder = function(searchField, queryString) {
      var searchField = {
        query_string: {
          default_field: searchField,
          query: queryString,
          analyze_wildcard: true
        }
      };
      return searchField;
    };

    /**
     * @desc queryBuilder
     * @param fromTime, toTime, searchCondition, sipmethod
     * @return void
     */
    var queryBuilder = function(
      fromTime,
      toTime,
      searchCondition,
      sipmethod,
      sortOrder
    ) {
      var query = {
        sort: [{
          logtimestamp: {
            order: sortOrder
          }
        }],
        stored_fields: ["logtimestamp", "body"],
        aggs: {
          corrid_agg: {
            terms: {
              field: "correlationid",
              size: "1000",
              collect_mode: "breadth_first"
            },
            aggs: {
              timecorrid_agg: {
                min: {
                  field: "logtimestamp"
                }
              },
              corrid_bucket_sort: {
                bucket_sort: {
                  sort: [{
                    timecorrid_agg: {
                      order: "desc"
                    }
                  }],
                  size: 1000
                }
              }
            }
          }
        },
        query: {
          bool: {
            must: {
              query_string: {
                query: "*"
              }
            },
            filter: {
              bool: {
                must: [{
                    range: {
                      logtimestamp: {
                        gte: fromTime,
                        lte: toTime,
                        format: "epoch_millis"
                      }
                    }
                  },
                  {
                    term: {
                      sipmethod: sipmethod
                    }
                  },
                  searchCondition
                ]
              }
            }
          }
        }
      };
      return query;
    };

    /**
     * @desc Fetches the result for given set of correlationid
     * @param pagenumber
     * @return void
     */
    $scope.fetchPages = function(pagenumber) {
      if ($scope.resultLoad === "skip") {
        $scope.resultLoad === "pass over";
        return;
      }
      clearOutputPanel();
      $scope.CorrId = null;
      console.log("Page Number " + pagenumber);
      var time = assignTime();
      var j;
      var Id = [];
      // HIK 17 October 2016
      // Fixed bug while moving between pages, displaying progress and deleting info
      $scope.setCorrelationIdPanelTrue();
      this.hits = null;
      $scope.fromTime = time[0];
      $scope.endTime = time[1];
      if (pagenumber === 1) {
        j = 0;
      } else {
        j = pagenumber * 20 - 20;
      }
      for (
        var i = j; i < $scope.listofCorrelationId.length && i < pagenumber * 20; i++
      ) {
        Id.push($scope.listofCorrelationId[i].key);
      }
      $http
        .get("../api/sip/fetchToolTipInfo", {
          params: {
            searchIndex: $scope.searchIndex,
            corrid: Id,
            fromtime: $scope.fromTime,
            totime: $scope.endTime,
            method: $scope.choice.selectedMethod,
            sortOrder: $scope.sortPreference
          }
        })
        .then(response => {
          this.hits = response.data;
          $scope.setCorrelationIdPanelFalse();
        });
    };

    /**
     * @desc Fetches the Correlation Id and TimeStamp Related to it
     * @desc Two Stage process, fetch ID and then perform mulitsearch
     * @param no params
     * @return void
     */
    $scope.fetchCorridTime = function() {
      //Starts the Radical Progress
      $scope.setCorrelationIdPanelTrue();
      $scope.resultLoad = "pass over";
      //Flushes out the hits to out page number
      this.hits = null;
      //Flushes the log message from output panel
      clearOutputPanel();
      $scope.users = [];
      $scope.CorrId = null;
      $scope.paramQuery = [];
      var filterQueryObject = [];
      if ($scope.choices[0].qsearch === "") {
        $scope.choices[0].qsearch = "*";
      }
      for (var i = 0; i < $scope.choices.length; i++) {
        var searchTerm = frameSearchField(
          $scope.choices[i].selectedCallOrigin,
          $scope.choices[i].selectedFilter
        );
        var searchQuery = frameSearchFieldBuilder(
          searchTerm,
          $scope.choices[i].qsearch
        );
        filterQueryObject.push(searchQuery);
      }
      var time = assignTime();
      //console.log(time);
      $scope.fromTime = time[0];
      $scope.endTime = time[1];
      $scope.paramQuery = queryBuilder(
        $scope.fromTime,
        $scope.endTime,
        filterQueryObject,
        $scope.choice.selectedMethod,
        $scope.sortPreference
      );
      $http
        .get("../api/sip/listCorrelationId", {
          params: {
            searchIndex: $scope.searchIndex,
            rest_total_hits_as_int: true,
            ignore_throttled: true,
            advanceQuery: $scope.paramQuery
          }
        })
        .then(response => {
          if (response.data === "Empty") {
            $scope.openModalBox("No Results Found");
            $scope.setCorrelationIdPanelFalse();
            return;
          } else if (response.data === "Error") {
            $scope.openModalBox("No Results Found");
            $scope.setCorrelationIdPanelFalse();
            return;
          }
          $scope.listofCorrelationId = response.data;
          var myArr = response.data;
          try {
            if (myArr.hits.hits.length < 1) {
              // Used to stop Radical Progress when no correlation Id returned
              $scope.setCorrelationIdPanelFalse();
              $scope.openModalBox("No Results Found");
              return;
            }
          } catch (e) {
            // Page size is used in pagination control stucture
            $scope.PageSize = response.data.length;
            $scope.fetchPages(1);
          }
        });
    };

    /**
     * @desc Converts the Angular Bracket into &lt and &gt
     * @param no params
     * @return void
     */
    function htmlEntities(str) {
      return String(str)
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
    }

    /**
     * [renderLogMessage renders the logmessage for given correlationId]
     * @param  {[object]} myArr      [json object from server]
     * @param  {[string]} uniquetime [log file timestamp]
     * @return {[object]}            [holds logmessage, logfile]
     */
    function renderLogMessage(myArr, uniquetime) {
      var logMessage = "";
      var logFile = "";
      //logFile variable is used hold log message for  file being blacked
      $scope.logFile = myArr;
      $scope.logFileName = uniquetime;
      var xsiEventApp = "/app/xsi_event#/";
      var sipCallFlow = "/app/sip#/sip-Call-Flow/id/";

      /**
       * [firstLinePatternRE used to hold the regex for the first line]
       * Used to capture the first Line in log message, refer CallCorrelationIdentifierFD-R200
       * @type {[string]}
       */
      var firstLinePatternRE = /^(\d{4}\.\d{2}\.\d{2}\s+.*)\n/g;

      /**
       * [correlationIdPatternRe used to hold the regex for the correlationId]
       * Used to capture the correaltionid in first line, refer CallCorrelationIdentifierFD-R200
       * @type {[String]}
       */
      var correlationIdPatternRe = /\s\w{8}-\w{4}-\w{4}-\w{4}-\w{12}\s/g;
      /**
       * [chanIdPatternRE Regular Expression to Capture ChannelId]
       * @type {[string]}
       */
      var chanIdPatternRE = /(&lt;xsi:channelId&gt;.*&lt;\/xsi:channelId&gt;)/g;

      /**
       * [subIdPatternRE Regular Expression to Capture subscriptionId]
       * @type {[string]}
       */
      var subIdPatternRE = /(&lt;xsi:subscriptionId&gt;.*&lt;\/xsi:subscriptionId&gt;)/g;

      /**
       * [eventIdPatternRE Regular Expression to Capture EventId]
       * @type {[string]}
       */
      var eventIdPatternRE = /(&lt;xsi:eventID&gt;.*&lt;\/xsi:eventID&gt;)/g;

      // Below code snippet is used to decorate the Log Message First Line
      for (var i = 0; i < myArr.length; i++) {
        var xx = htmlEntities(myArr[i]._source.source);
        logFile = logFile.concat(myArr[i]._source.source);
        var y = xx.match(firstLinePatternRE);
        xx = xx.replace(
          firstLinePatternRE,
          '<div id="decorate">' + y[0] + "</div>"
        );

        var correlationId = xx.match(correlationIdPatternRe);
        if (correlationId) {
          xx = xx.replace(
            correlationIdPatternRe,
            '<a  href="' +
            sipCallFlow +
            correlationId[0].trim() +
            '" target="_blank" >' +
            correlationId +
            "</a>"
          );
        }

        var chanId = xx.match(chanIdPatternRE);
        if (chanId) {
          // Time is normalized to epooch due to xsi event bug
          var chanQueryString =
            "channel/" +
            chanId[0].slice(21, 57) +
            "/" +
            $scope.timeFrame[0] +
            "/" +
            $scope.timeFrame[1];
          xx = xx.replace(
            chanIdPatternRE,
            '<a ng-click="channelId()" href="' +
            xsiEventApp +
            chanQueryString +
            '" target="_blank ">' +
            chanId +
            "</a>"
          );
        }

        var subId = xx.match(subIdPatternRE);
        if (subId) {
          var QueryString =
            "subscription/" +
            subId[0].slice(26, 62) +
            "/" +
            $scope.timeFrame[0] +
            "/" +
            $scope.timeFrame[1];
          xx = xx.replace(
            subIdPatternRE,
            '<a  href="' +
            xsiEventApp +
            QueryString +
            '" target="_blank ">' +
            subId +
            "</a>"
          );
        }

        var eventId = xx.match(eventIdPatternRE);
        if (eventId) {
          var eventQueryString =
            "event/" +
            eventId[0].slice(19, 55) +
            "/" +
            $scope.timeFrame[0] +
            "/" +
            $scope.timeFrame[1];
          xx = xx.replace(
            eventIdPatternRE,
            '<a  href="' +
            xsiEventApp +
            eventQueryString +
            '" target="_blank ">' +
            eventId +
            "</a>"
          );
        }
        logMessage = logMessage.concat(xx);
      }
      return [logMessage, logFile];
    }

    /**
     * @desc retrieve the complete call log message based on the correlationid
     * @param correlationid, uniquetime
     * @return void
     */
    $scope.fetchLogMessage = function(correlationid, uniquetime) {
      $scope.CorrId = correlationid;
      $scope.progress = "true";
      clearOutputPanel();
      $http
        .get("../api/sip/logmessage", {
          params: {
            searchIndex: $scope.searchIndex,
            correlationId: correlationid
          }
        })
        .then(response => {
          var result = response.data.hits.hits;
          if (result.length < 1) {
            $scope.openModalBox("No Logs Found");
          }

          /**
           * [result description holds logMessage, logFile]
           * [result [0]logMessage formatted output displayed to user]
           * [resut [1]logFile original text file]
           * @type {[object]}
           */
          var result = renderLogMessage(result, uniquetime);
          //AngularJs does not support rendering the HTML components
          //so We need to trustAsHtml before sending to ng-model
          //$scope.logM = $sce.trustAsHtml(logMessage);
          $scope.logM = $sce.trustAsHtml(result[0]);
          $scope.logFileMessage = result[1];
          $scope.progress = "false";
        });
    };

    /**
     * @desc It helps to download the log file with timestamp as filename
     * @param no params
     * @return void
     */
    $scope.downloadFile = function() {
      var fileName = $scope.logFileName;
      /*
      Replace the empty space by Underscore
      Making it Linux Friendly
       */
      var logFileName = fileName.replace(/ /g, "_");
      var element = document.createElement("a");
      /**
       * Added to fix the download file feature in IE browser
       * There is limitation of character that can be passed in url
       */
      if (navigator.msSaveBlob) {
        // IE 10+
        navigator.msSaveBlob(
          new Blob([$scope.logFileMessage], {
            type: "text/plan;charset=utf-8;"
          }),
          "siplog_" + logFileName + ".txt"
        );
      } else {
        // Chrome && FireFox
        element.setAttribute(
          "href",
          "data:text/plain;charset=utf-8," +
          encodeURIComponent($scope.logFileMessage)
        );
        element.setAttribute("download", "siplog_" + $scope.CorrId + ".txt");
        element.style.display = "none";
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);
      }
    };

    /**
     * @desc Make fullScreen of Complete Log Panel
     * @param no params
     * @return void
     */
    $scope.fullScreen = function() {
      if ($scope.fullScreenMode === true) {
        $scope.cssClass = "col-md-8";
        $scope.fullScreenMode = false;
        document.getElementById("full-screen-container").style.marginTop = null;
      } else {
        $scope.fullScreenMode = true;
        $scope.cssClass = "col-md-12";
        //During Full screen mode, to move the focus to top of the page
        $window.scrollTo(
          0,
          angular.element(document.getElementById("unitetheme")).offsetTop
        );
        document.getElementById("full-screen-container").style.marginTop =
          "100px";
      }
    };
  });
