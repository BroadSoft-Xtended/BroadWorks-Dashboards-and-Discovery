import { uiModules } from "ui/modules";
uiModules
.get('app/xsi_event', ['720kb.tooltips','ngDialog','angularUtils.directives.dirPagination','ngCookies',
 'ui.bootstrap.contextMenu'])
.controller('indexRemoveController', function ($scope, $route, $interval, $http, $sce,  $filter, $cookies, ngDialog, $rootScope) {

	$rootScope.$on("CallRemoveMethod", function(){
		console.log("call remove");
	   $scope.fetchIndexPattern();
	});
	$scope.updateAllControllers = function () {
	$rootScope.$emit("CallSelectMethod", {});
	$rootScope.$emit("CallUpdateMethod", {});
  };
  $scope.fetchIndexPattern = function () {
    $scope.displayInfo = '';
    $scope.progress = 'true';
    $http.get('../api/xsi_event/selectTribeIndexPattern').then((response) => {
      console.log(response);
      $scope.indexRemove = response.data.hits.hits;}
      //console.log($scope.indexRemove)ck(response)
       , function errorCallback(response) {
      console.log('ERROR1');
      $scope.progress = 'false';
      $scope.openErrorAlert('ERROR - Could not Access Server');
    });
  };

  $scope.removeIndexPattern = function (ID) {
    $scope.displayInfo = '';
    $scope.progress = 'true';
    $http.get('../api/xsi_event/removeIndexPattern',{
      params:{
        documentID: ID._id,
      }
    }).then((response) => {
      $scope.openModalBox('Index Removed from List');
      setTimeout(function () {  $scope.fetchIndexPattern(); }, 1000);
	  setTimeout($scope.updateAllControllers, 1000);	
    }, function errorCallback(response) {
      console.log('ERROR');
      $scope.progress = 'false';
      $scope.openErrorAlert('ERROR - Could not Access Server');
    });
  };
  // Could not able to index data
});
