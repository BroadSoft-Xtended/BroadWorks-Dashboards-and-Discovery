import $ from 'jquery';
import moment from 'moment';
import chrome from 'ui/chrome';
import uiModules from 'ui/modules';
import uiRoutes from 'ui/routes';
var angular = require('angular');
require('bootstrap');

import './lib/dependency.js'
import './less/main.less';
import overviewTemplate from './templates/index.html';
import logoUrl from 'plugins/xsi_event/logo.png';


uiRoutes.enable();
uiRoutes
.when('/channel/:channelID/:startDt/:endDt/', {
  template: overviewTemplate,
  controller: 'xsiEvent',
  controllerAs: 'ctrl'
})
.when('/subscription/:subscriptionID/:startDt/:endDt/', {
  template: overviewTemplate,
  controller: 'xsiEvent',
  controllerAs: 'ctrl'
})
.when('/event/:eventID/:startDt/:endDt/', {
  template: overviewTemplate,
  controller: 'xsiEvent',
  controllerAs: 'ctrl'
})
.when('/user/:userID/:startDt/:endDt/', {
  template: overviewTemplate,
  controller: 'xsiEvent',
  controllerAs: 'ctrl'
})
.when('/', {
  template: overviewTemplate,
  controller: 'xsiEvent',
  controllerAs: 'ctrl'
});
 
uiModules
.get('app/xsi_event', ['720kb.tooltips','ngDialog','angularUtils.directives.dirPagination','ngCookies'])
.controller('xsiEvent', function ($scope, $http, $routeParams, $filter, $sce, $route, $interval, $window, ngDialog, $cookies) {
//alert("hi");
    $scope.version = "Version 1.0";
	$scope.title = "XSI Event Log Utility";
	$scope.relativeCombo = "5 min";
	var isAbsolute = false;
	var startDt = "";
	var endDt = "";	
	$scope.showAb = true;
	$scope.showRe = false;
	$scope.showCS = true;
	$scope.showUE = false;
	$scope.showUEID = false;
	$scope.showCID = false; 
	$scope.showCor = false;
	$scope.showChannelList = false;
	$scope.showLog = false;
	$scope.myHTML = "";
	$scope.output = "";
	$scope.userID = "elongmiller@broadsoft.com";
	$scope.event = "CallSubscriptionEvent";
	$scope.eventid = "*";
	$scope.chID = "879bf7b0-9375-4220-b582-6f33fb45dea0";
	$scope.subID = "c2cd1b54-43d0-4663-b187-e28ad6719434";
	
	$scope.InitTime = '08/29/2016 06:00 AM';
	$scope.CurrentTime =  $filter('date')(new Date(), 'MM/dd/yyyy hh:mm a');
	$scope.correlationID = "LIST OF CORRELATION IDS";
	$scope.jsonresponse = "LOGS";
	$scope.showOnePane = false;
	$scope.showTwoPane = false;
	$scope.showThreePane = false;
	$scope.showForAbsolute = false;
	var userID = "";
	var evntName = "";
	var exp1 = /(&lt;xsi:channelId&gt;.*&lt;\/xsi:channelId&gt;)/g;
	var exp2 = /(&lt;xsi:subscriptionId&gt;.*&lt;\/xsi:subscriptionId&gt;)/g;
	var exp3 = /(&lt;xsi1:type="&gt;.*&lt;\/"&gt;)/g;
		
	var sipLogName = "";
	var logContent = "";
	$scope.isClickAllowed = false;
	var chsubcall = false;

	// set other one as *
	if($routeParams.userID) {
		$scope.userID = $routeParams.userID;
		$scope.event = '*';
		$scope.showCS = false;
		$scope.showUE = true;
		$scope.showUEID = false;
		isAbsolute = true;
	} 
	if($routeParams.eventID)
	{
		$scope.eventid = $routeParams.eventID;
		$scope.userID = '*';
		$scope.showCS = false;
		$scope.showUE = false;
		$scope.showUEID = true;
		isAbsolute = true;
	} 	
	if($routeParams.channelID)
	{
		$scope.chID = $routeParams.channelID;
		$scope.subID = '*';
		$scope.showCS = true;
		$scope.showUE = false;
		$scope.showUEID = false;
		isAbsolute = true;
	} 
	if($routeParams.subscriptionID)
	{
		$scope.subID = $routeParams.subscriptionID;
		$scope.chID = '*';
		$scope.showCS = true;
		$scope.showUE = false;
		$scope.showUEID = false;
		isAbsolute = true;
	} 
	if($routeParams.startDt)
	{
		//$scope.InitTime = new Date( $routeParams.startDt *1000).toLocaleString();
		$scope.InitTime = new Date( Math.floor($routeParams.startDt )).toLocaleString();
	} 
	if($routeParams.endDt) {
		//$scope.CurrentTime = new Date( $routeParams.endDt *1000).toLocaleString();
		$scope.CurrentTime = new Date( Math.floor($routeParams.endDt) ).toLocaleString();
	} 

	$( function() {
		$( '#datetimepicker1' ).datetimepicker();
		$( '#datetimepicker2' ).datetimepicker();
	} );

	$('#datetimepicker1 input').click(function(event){
	   $('#datetimepicker1 ').data("DateTimePicker").show();
	});
	$('#datetimepicker2 input').click(function(event){
	   $('#datetimepicker2 ').data("DateTimePicker").show();
	});
	$scope.openModalBox = function (message) {
		ngDialog.open({ template: '<p>' + message + '</p>', plain: true });
	};

	//Converts the current time into epoch_millis format
	  var getCurrentTime = function () {
		var CurrentTime = $filter('date')(new Date(), 'MM/dd/yyyy hh:mm a');
		return (new Date(CurrentTime)).getTime();
	  };
	  var FromDate = function () {
			var UserFromDate = angular.element(startDate).val();
			return (new Date(UserFromDate)).getTime();
	 };

	  var ToDate = function () {
		var UserToDate = angular.element(endDate).val();
		return (new Date(UserToDate)).getTime();
	  };
	 	
	$scope.dispAb = function() {
		$scope.showAb = true;
		$scope.showRe = false;
	}
    $scope.dispRe = function() {
		$scope.showAb = false;
		$scope.showRe = true;
	  }
	$scope.dispUE = function() {
		$scope.showUE = true;
		$scope.showUEID = false;
		$scope.showCS = false;
		$scope.showCID = false;
	}
    $scope.dispCS = function() {
		$scope.showUE = false;
		$scope.showUEID = false;
		$scope.showCID = false;
		$scope.showCS = true;
	  }
	$scope.dispUEID = function() {
		$scope.showCID = false;
		$scope.showUE = false;
		$scope.showCS = false;
		$scope.showUEID = true;
	}
	$scope.dispCID = function() {
		$scope.showCID = true;
		$scope.showUE = false;
		$scope.showCS = false;
		$scope.showUEID = false;
	}
	$scope.reset = function() {
		$scope.InitTime = '08/29/2016 06:00 AM';
		$scope.CurrentTime =  $filter('date')(new Date(), 'MM/dd/yyyy hh:mm a');
		$scope.userID = "";
		$scope.event = "";
		$scope.eventid = "";
		$scope.chID = "";
		$scope.subID = "";
		$scope.showCor = false;
		$scope.showChannelList = false;
		$scope.showLog = false;
		$scope.showLogs = false;
		$scope.myHTML = "";
		$scope.output = "";
		$scope.allLogs = "";
		$scope.correID = "";
		$("#spinner").hide();
	} 
	if(isAbsolute) {
	  //alert("is ab");
		
	  	$scope.jsonresponse = "LOGS";
		$scope.showLogs = false;
		$scope.showCorForAbsolute = false;
		$scope.showChForAbsolute = false;
		$scope.showChannelList = false;
		$scope.showCor = false;
		$scope.showLog = false;
		$scope.myHTML = "";
		$scope.output = "";
		startDt = "";
		endDt = "";

	  	if ($scope.showRe && $scope.relativeCombo != "")
		{
			var relativeTime;
			var currentTime = getCurrentTime();
			if ($scope.relativeCombo == "5 min")
			{
			  relativeTime = (currentTime - (300 * 1000));
			}
			else if ($scope.relativeCombo == "10 min") {
			  relativeTime = (currentTime - (600 * 1000));
			}
			else if ($scope.relativeCombo == "15 min") {
			  relativeTime = (currentTime - (900 * 1000));
			}
			else if ($scope.relativeCombo == "1 hour") {
			  relativeTime = (currentTime - (3600 * 1000));
			}
			else if ($scope.relativeCombo == "2 hours") {
			  relativeTime = (currentTime - (7200 * 1000));
			}
			else if ($scope.relativeCombo == "5 hours") {
			  relativeTime = (currentTime - (18000 * 1000));
			}
			else if ($scope.relativeCombo == "8 hours") {
			  relativeTime = (currentTime - (28800 * 1000));
			}
			else if ($scope.relativeCombo == "1 day") {
			  relativeTime = (currentTime - (86400 * 1000));
			}
			else if ($scope.relativeCombo == "2 days") {
			  relativeTime = (currentTime - (172800 * 1000));
			}
			else if ($scope.relativeCombo == "1 week") {
			  relativeTime = (currentTime - (604800 * 1000));
			}
			startDt =  relativeTime;
			endDt = getCurrentTime();
		} else {
			startDt = new Date($scope.InitTime).getTime();
			endDt = new Date($scope.CurrentTime).getTime();
		}
		if(isNaN(startDt)) {
			$scope.openModalBox('Start Date is missing!!!');
			return;
		}
		if(isNaN(endDt)) {
			$scope.openModalBox('End Date is missing!!!');
			return;
		}
		if($scope.showUE) {
			$scope.isClickAllowed = false;
			if($scope.uiderr) $scope.uiderr = false;
			if($scope.evnameerr) $scope.evnameerr  = false;
			if($scope.userID == null || $scope.userID == 'undefined' || $scope.userID == "") {
				$scope.uiderr = true;
				return;
			}
			if($scope.event == null || $scope.event == 'undefined' || $scope.event == "") {
				if($scope.uiderr) $scope.uiderr = false;
				$scope.evnameerr = true;
				return;
			}
			if($scope.evnameerr) $scope.evnameerr  = false;
			if($scope.userID == "*" && $scope.event == "*")
			{
				$scope.openModalBox('Both UserID and Event cannot be * !!!');
				return;
			}
		}
		if($scope.showUEID) {
			$scope.isClickAllowed = false;
			if($scope.uiderr) $scope.uiderr = false;
			if($scope.eviderr) $scope.eviderr  = false;
			if($scope.userID == null || $scope.userID == 'undefined' || $scope.userID == "") {
				$scope.uiderr = true;
				return;
			}
			if($scope.eventid == null || $scope.eventid == 'undefined' || $scope.eventid == "") {
				if($scope.uiderr) $scope.uiderr = false;
				$scope.eviderr = true;
				return;
			}
			if($scope.eviderr) $scope.eviderr  = false;
			if($scope.userID == "*" && $scope.eventid == "*")
			{
				$scope.openModalBox('Both UserID and Event cannot be * !!!');
				return;
			}
		}
		if($scope.showCS) {
			$scope.isClickAllowed = false;
			if($scope.chiderr) $scope.chiderr = false;
			if($scope.subiderr) $scope.subiderr  = false;
			if($scope.chID == null || $scope.chID == 'undefined' || $scope.chID == "") {
				$scope.chiderr = true;
				return;
			}
			if($scope.subID == null || $scope.subID == 'undefined' || $scope.subID == "") {
				if($scope.chiderr) $scope.chiderr = false;
				$scope.subiderr = true;
				return;
			}
			if($scope.subiderr) $scope.subiderr  = false;
			if($scope.chID == "*" && $scope.subID == "*")
			{
				$scope.openModalBox('Both Channel ID and Subscription ID cannot be * !!!');
				return;
			}
		}
		if($scope.showCID) {
			$scope.isClickAllowed = false;
			if($scope.coiderr) $scope.coiderr  = false;
			if($scope.correID == null || $scope.correID == 'undefined' || $scope.correID == '') {
				$scope.coiderr = true;
				return;
			}
		}

		if($scope.showUE) {
			chsubcall = false;
			$scope.showCor = false;
			$scope.showChannelList = false;
			$scope.showCorForAbsolute = false;
			$scope.correlationID = "List of Channel IDs";
			if($scope.showOnePane) $scope.showOnePane = false;
			$scope.showTwoPane = true;
			$scope.showThreePane = true;
			$("#spinner").show();
			$scope.showLogs = false;
			var UserID = userID = $scope.userID;
			var eventName = evntName = $scope.event;
			var wildcard = '';
			logContent = '';
			
			if((eventName != '*' && eventName.includes('*')) || (UserID != '*' && UserID.includes('*')))
			{
				wildcard = '*'
			} 
			$http.get(`../api/xsi_event/uename`, {params:{userId:$scope.userID, event:$scope.event, startDT:startDt, endDT:endDt, wildcard:wildcard}}).then((response) => {
				var myArr = response.data;
			      if (myArr)
				  {
					try {
					  if (myArr.hits.hits.length == 0)
					  {
					  	$("#spinner").hide();
						$scope.openModalBox('No Channel ID found !!!');
						$scope.isClickAllowed = false;
						$scope.showChForAbsolute = false;
						$scope.showLog = false;
						this.hits = null;
						return;
					  }
					} catch (e) {
						$("#spinner").hide();
					  this.hits = response.data;

					}
				  }
				this.hits = response.data;
				$scope.showChForAbsolute = true;
			});
		}else if($scope.showUEID) {
			chsubcall = false;
			$scope.showCor = false;
			$scope.showChannelList = false;
			$scope.showCorForAbsolute = false;
			$scope.correlationID = "List of Channel IDs";
			if($scope.showOnePane) $scope.showOnePane = false;
			$scope.showTwoPane = true;
			$scope.showThreePane = true;
			$("#spinner").show();
			$scope.showLogs = false;
			var UserID = userID = $scope.userID;
			logContent = '';

			var wildcard = '';
			
			if(UserID != '*' && UserID.includes('*'))
			{
				wildcard = '*';
			} 
			$http.get(`../api/xsi_event/ueid`, {params:{userId:$scope.userID, eventid:$scope.eventid, startDT:startDt, endDT:endDt, wildcard:wildcard}}).then((response) => {
				var myArr = response.data;
			      if (myArr)
				  {
					try {
					  if (myArr.hits.hits.length == 0)
					  {
					  	$("#spinner").hide();
						$scope.openModalBox('No Channel ID found');
						$scope.isClickAllowed = false;
						$scope.showChForAbsolute = false;
						$scope.showLog = false;
						this.hits = null;
						return;
					  }
					} catch (e) {
						$("#spinner").hide();
					  this.hits = response.data;

					}
				  }
				this.hits = response.data;
				$scope.showChForAbsolute = true;
			});
		} else if($scope.showCS) {
			chsubcall = true;
			$scope.correlationID = "LIST OF CORRELATION IDS";
			if($scope.showOnePane) $scope.showOnePane = false;
			$scope.showTwoPane = true;
			$scope.showThreePane = true;
			$("#spinner").show();
			$scope.showLogs = false;
			$scope.showCor = false;
			$scope.showChannelList = false;
			$scope.showChForAbsolute = false;
			logContent = '';
			
			$http.get(`../api/xsi_event/indices`, {params:{chid:$scope.chID, subid:$scope.subID, startDT:startDt, endDT:endDt}}).then((response) => {
				var myArr = response.data;
			      if (myArr)
				  {
					try {
					  if (myArr.hits.hits.length == 0)
					  {
					  	$("#spinner").hide();
						$scope.openModalBox('No Correlation ID found !!!');
						$scope.isClickAllowed = false;
						$scope.showCorForAbsolute = false;
						$scope.showLog = false;
						this.hits = null;
						return;
					  }
					} catch (e) {
						$("#spinner").hide();
					  this.hits = response.data;

					}
				  }
				this.hits = response.data;
				$scope.showCorForAbsolute = true;
			});
		} else {
			if($scope.showCID) {
				chsubcall = false;
				$scope.correlationID = "List of Channel IDs";
				if($scope.showOnePane) $scope.showOnePane = false;
				$scope.showTwoPane = true;
				$scope.showThreePane = true;
				$("#spinner").show();
				$scope.showLogs = false;
				$("#spinner").show();
				$scope.showCor = false;
				$scope.showChannelList = false;
				$scope.showCorForAbsolute = false;
				$scope.showLog = false;
				$scope.allLogs = '';
				var myArr = '';
				$http.get(`../api/xsi_event/correlationid`, {params:{startDT:startDt, endDT:endDt, corrId:$scope.correID}}).then((response) => {
					var myArr = response.data;
					  if (myArr)
					  {
						try {
						  if (myArr.hits.hits.length == 0)
						  {
							$("#spinner").hide();
							$scope.openModalBox('No Channel ID found');
							$scope.isClickAllowed = false;
							$scope.showChForAbsolute = false;
							$scope.showLog = false;
							this.hits = null;
							return;
						  }
						} catch (e) {
							$("#spinner").hide();
						  this.hits = response.data;

						}
					  }
					this.hits = response.data;
					$scope.showChForAbsolute = true;
				});
			}
		}
		$scope.onclickof= function(index, currenttimestamp){

			logContent = '';
			$scope.showLog = true;
			$("#spinner2").show();
			$http.get(`../api/xsi_event/indices`, {params:{startDT:startDt, endDT:endDt, corrId:index}}).then((response) => {

			  var myArr = response.data.hits.hits;
			  console.log(myArr);
			  if (myArr.length < 1)
			  {
			  $scope.showLog = false;
			  $("#spinner2").hide();
			  $scope.openModalBox('No Logs found!!!');
				//alert('No Logs Found');
				$scope.isClickAllowed = false;
				$scope.showLog = false;
				return;
			  }
			  $scope.showLog = false;
			  $("#spinner2").hide();
			  var logMessage = '';
			  for (var i = 0; i < myArr.length; i++)
			  {
				var xx = htmlEntities(myArr[i]._source.source);
				var exp = /^(\d{4}\.\d{2}\.\d{2}\s+.*)\n/g;
				var y = xx.match(exp); 
				xx = xx.replace(exp, '<div id="decorate">' + y[0] + '</div>');
				// to highlight channel id
				var y1 = xx.match(exp1);
				xx = xx.replace(exp1, '<strong>' + y1 + '</strong>');
				// to highlight subscription id
				var y2 = xx.match(exp2);
				xx = xx.replace(exp2, '<strong>' + y2 + '</strong>');
				// to highlight event name
				var y3 = xx.match(exp3);
				xx = xx.replace(exp3, '<strong>' + y3 + '</strong>');
				logMessage = logMessage.concat(xx);
			  }
			  for (var i = 0; i < myArr.length; i++)
			  {
				var xx = myArr[i]._source.source;
				logContent = logContent.concat(xx);
			  }
				$scope.showLog = true;
				$("#spinner2").hide();
				$scope.jsonresponse = "Complete Log for Correlation ID: " + index + " ";
				$scope.myHTML = $sce.trustAsHtml(logMessage);
			});
			currenttimestamp = currenttimestamp.replace(/\s+/, "_");
			currenttimestamp = currenttimestamp.replace(/\s+/, "_");
			sipLogName = 'xsilog_' + currenttimestamp + '.log';
			$scope.isClickAllowed = true;
			
		}
				$scope.fetchLogForChannelID= function(index, currenttimestamp){

			logContent = '';
			$scope.showLog = true;
			$("#spinner2").show();
			$http.get(`../api/xsi_event/channelid`, {params:{startDT:startDt, endDT:endDt, chId:index}}).then((response) => {

			  var myArr = response.data.hits.hits;
			  console.log(myArr);
			  if (myArr.length < 1)
			  {
			  $scope.showLog = false;
			  $("#spinner2").hide();
				//alert('No Logs Found');
				$scope.openModalBox('No Logs found !!!');
				$scope.isClickAllowed = false;
				$scope.showLog = false;
				return;
			  }
			  $scope.showLog = false;
			  $("#spinner2").hide();
			  var logMessage = '';
			  for (var i = 0; i < myArr.length; i++)
			  {
				var xx = htmlEntities(myArr[i]._source.source);
				var exp = /^(\d{4}\.\d{2}\.\d{2}\s+.*)\n/g;
				var y = xx.match(exp); 
				xx = xx.replace(exp, '<div id="decorate">' + y[0] + '</div>');
				// to highlight channel id
				var y1 = xx.match(exp1);
				//alert(y1);
				xx = xx.replace(exp1, '<strong>' + y1 + '</strong>');
				// to highlight subscription id
				var y2 = xx.match(exp2);
				xx = xx.replace(exp2, '<strong>' + y2 + '</strong>');
				// to highlight event name
				var y3 = xx.match(exp3);
				xx = xx.replace(exp3, '<strong>' + y3 + '</strong>');
				logMessage = logMessage.concat(xx);
			  }
			  for (var i = 0; i < myArr.length; i++)
			  {
				var xx = myArr[i]._source.source;
				logContent = logContent.concat(xx);
			  }
				$scope.showLog = true;
				$("#spinner2").hide();
				$scope.jsonresponse = "Complete Log for Channel ID: " + index + " ";
				$scope.myHTML = $sce.trustAsHtml(logMessage);
			});
			currenttimestamp = currenttimestamp.replace(/\s+/, "_");
			currenttimestamp = currenttimestamp.replace(/\s+/, "_");
			sipLogName = 'xsilog_' + currenttimestamp + '.log';
			$scope.isClickAllowed = true;
			
		}
		$scope.download = function(){
			download(sipLogName, logContent);
		}

		function htmlEntities(str)
		{
			return String(str).replace(/</g, '&lt;').replace(/>/g, '&gt;');
		}
		function download(filename, text) {
			var pom = document.createElement('a');
			pom.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
			pom.setAttribute('download', filename);

			if (document.createEvent) {
				var event = document.createEvent('MouseEvents');
				event.initEvent('click', true, true);
				pom.dispatchEvent(event);
			}
			else {
				pom.click();
			}
		}
	  }
	  
	  $scope.go = function() {
		isAbsolute = false;
		$scope.jsonresponse = "LOGS";
		$scope.showLogs = false;
		$scope.showCorForAbsolute = false;
		$scope.showChForAbsolute = false;
		$scope.showChannelList = false;
		$scope.showCor = false;
		$scope.showLog = false;
		$scope.myHTML = "";
		$scope.output = "";
		startDt = "";
		endDt = "";
	  	if ($scope.showRe && $scope.relativeCombo != "")
		{
			var relativeTime;
			var currentTime = getCurrentTime();
			if ($scope.relativeCombo == "5 min")
			{
			  relativeTime = (currentTime - (300 * 1000));
			}
			else if ($scope.relativeCombo == "10 min") {
			  relativeTime = (currentTime - (600 * 1000));
			}
			else if ($scope.relativeCombo == "15 min") {
			  relativeTime = (currentTime - (900 * 1000));
			}
			else if ($scope.relativeCombo == "1 hour") {
			  relativeTime = (currentTime - (3600 * 1000));
			}
			else if ($scope.relativeCombo == "2 hours") {
			  relativeTime = (currentTime - (7200 * 1000));
			}
			else if ($scope.relativeCombo == "5 hours") {
			  relativeTime = (currentTime - (18000 * 1000));
			}
			else if ($scope.relativeCombo == "8 hours") {
			  relativeTime = (currentTime - (28800 * 1000));
			}
			else if ($scope.relativeCombo == "1 day") {
			  relativeTime = (currentTime - (86400 * 1000));
			}
			else if ($scope.relativeCombo == "2 days") {
			  relativeTime = (currentTime - (172800 * 1000));
			}
			else if ($scope.relativeCombo == "1 week") {
			  relativeTime = (currentTime - (604800 * 1000));
			}
			startDt =  relativeTime;
			endDt = getCurrentTime();
		} else {
			startDt = FromDate();
			endDt = ToDate();
		}
		if(isNaN(startDt)) {
			$scope.openModalBox('Start Date is missing !!!');
			return;
		}
		if(isNaN(endDt)) {
			/*$scope.errMsg = "End Date is missing!!!";
			$(function() {
			$('#umodal').fadeIn();
			  $('#closeBnt').click(function(){
				$('#umodal').hide();
			  });
			});*/
			$scope.openModalBox('End Date is missing!!!');
			return;
		}
		if($scope.showUE) {
		$scope.isClickAllowed = false;
			if($scope.uiderr) $scope.uiderr = false;
			if($scope.eviderr) $scope.eviderr  = false;
			if($scope.userID == null || $scope.userID == 'undefined' || $scope.userID == "") {
				$scope.uiderr = true;
				return;
			}
			if($scope.event == null || $scope.event == 'undefined' || $scope.event == "") {
				//alert("Subscription ID missing");
				if($scope.uiderr) $scope.uiderr = false;
				$scope.eviderr = true;
				return;
			}
			if($scope.eviderr) $scope.eviderr  = false;
			if($scope.userID == "*" && $scope.event == "*")
			{
				$scope.openModalBox('Both UserID and Event cannot be * !!!');
				return;
			}
		}
		if($scope.showUEID) {
			$scope.isClickAllowed = false;
			if($scope.uiderr) $scope.uiderr = false;
			if($scope.eviderr) $scope.eviderr  = false;
			if($scope.userID == null || $scope.userID == 'undefined' || $scope.userID == "") {
				$scope.uiderr = true;
				return;
			}
			if($scope.eventid == null || $scope.eventid == 'undefined' || $scope.eventid == "") {
				if($scope.uiderr) $scope.uiderr = false;
				$scope.eviderr = true;
				return;
			}
			if($scope.eviderr) $scope.eviderr  = false;
			if($scope.userID == "*" && $scope.eventid == "*")
			{
				$scope.openModalBox('Both UserID and Event cannot be * !!!');
				return;
			}
		}
		if($scope.showCS) {
		$scope.isClickAllowed = false;
			if($scope.chiderr) $scope.chiderr = false;
			if($scope.subiderr) $scope.subiderr  = false;
			if($scope.chID == null || $scope.chID == 'undefined' || $scope.chID == "") {
				$scope.chiderr = true;
				return;
			}
			if($scope.subID == null || $scope.subID == 'undefined' || $scope.subID == "") {
				//alert("Subscription ID missing");
				if($scope.chiderr) $scope.chiderr = false;
				$scope.subiderr = true;
				return;
			}
			if($scope.subiderr) $scope.subiderr  = false;
			if($scope.chID == "*" && $scope.subID == "*")
			{
				$scope.openModalBox('Both Channel ID and Subscription ID cannot be * !!!');
				return;
			}
		}
		if($scope.showCID) {
		$scope.isClickAllowed = false;
			if($scope.coiderr) $scope.coiderr  = false;
			if($scope.correID == null || $scope.correID == 'undefined' || $scope.correID == '') {
				$scope.coiderr = true;
				return;
			}
		}

		if($scope.showUE) {
			chsubcall = false;
			$scope.showCor = false;
			$scope.correlationID = "List of Channel IDs";
			if($scope.showOnePane) $scope.showOnePane = false;
			$scope.showTwoPane = true;
			$scope.showThreePane = true;
			$("#spinner").show();
			$scope.showLogs = false;
			var UserID = userID = $scope.userID;
			var eventName = evntName = $scope.event;
			var wildcard = '';
			logContent = '';
			
			if((eventName != '*' && eventName.includes('*')) || (UserID != '*' && UserID.includes('*')))
			{
				wildcard = '*'
			} 
			$http.get(`../api/xsi_event/uename`, {params:{userId:$scope.userID, event:$scope.event, startDT:startDt, endDT:endDt, wildcard:wildcard}}).then((response) => {
				var myArr = response.data;
			      if (myArr)
				  {
					try {
					  if (myArr.hits.hits.length == 0)
					  {
					  	$("#spinner").hide();
						$scope.openModalBox('No Channel ID found !!!');
						$scope.isClickAllowed = false;
						$scope.showChannelList = false;
						$scope.showLog = false;
						this.hits = null;
						return;
					  }
					} catch (e) {
						$("#spinner").hide();
					  this.hits = response.data;

					}
				  }
				this.hits = response.data;
				$scope.showChannelList = true;
			});
		}else if($scope.showUEID) {
			chsubcall = false;
			$scope.showCor = false;
			$scope.correlationID = "List of Channel IDs";
			if($scope.showOnePane) $scope.showOnePane = false;
			$scope.showTwoPane = true;
			$scope.showThreePane = true;
			$("#spinner").show();
			$scope.showLogs = false;
			var UserID = userID = $scope.userID;
			logContent = '';

			var wildcard = '';
			
			if(UserID != '*' && UserID.includes('*'))
			{
				wildcard = '*';
			} 
			$http.get(`../api/xsi_event/ueid`, {params:{userId:$scope.userID, eventid:$scope.eventid, startDT:startDt, endDT:endDt, wildcard:wildcard}}).then((response) => {
				var myArr = response.data;
			      if (myArr)
				  {
					try {
					  if (myArr.hits.hits.length == 0)
					  {
					  	$("#spinner").hide();
						$scope.openModalBox('No Channel ID found');
						$scope.isClickAllowed = false;
						$scope.showChannelList = false;
						$scope.showLog = false;
						this.hits = null;
						return;
					  }
					} catch (e) {
						$("#spinner").hide();
					  this.hits = response.data;

					}
				  }
				this.hits = response.data;
				$scope.showChannelList = true;
			});
		} else if($scope.showCS) {
			chsubcall = true;
			$scope.correlationID = "LIST OF CORRELATION IDS";
			if($scope.showOnePane) $scope.showOnePane = false;
			$scope.showTwoPane = true;
			$scope.showThreePane = true;
			$("#spinner").show();
			$scope.showLogs = false;
			$scope.showChannelList = false;
			logContent = '';
			
			$http.get(`../api/xsi_event/indices`, {params:{chid:$scope.chID, subid:$scope.subID, startDT:startDt, endDT:endDt}}).then((response) => {
				var myArr = response.data;
			      if (myArr)
				  {
					try {
					  if (myArr.hits.hits.length == 0)
					  {
					  	$("#spinner").hide();
						$scope.openModalBox('No Correlation ID found !!!');
						$scope.isClickAllowed = false;
						$scope.showCor = false;
						$scope.showLog = false;
						this.hits = null;
						return;
					  }
					} catch (e) {
						$("#spinner").hide();
					  this.hits = response.data;

					}
				  }
				this.hits = response.data;
				$scope.showCor = true;
			});
		} else {
			if($scope.showCID) {
				chsubcall = false;
				$scope.correlationID = "List of Channel IDs";
				if($scope.showOnePane) $scope.showOnePane = false;
				$scope.showTwoPane = true;
				$scope.showThreePane = true;
				$("#spinner").show();
				$scope.showLogs = false;
				$("#spinner").show();
				$scope.showCor = false;
				$scope.showLog = false;
				$scope.allLogs = '';
				var myArr = '';
				$http.get(`../api/xsi_event/correlationid`, {params:{startDT:startDt, endDT:endDt, corrId:$scope.correID}}).then((response) => {
					var myArr = response.data;
					  if (myArr)
					  {
						try {
						  if (myArr.hits.hits.length == 0)
						  {
							$("#spinner").hide();
							$scope.openModalBox('No Channel ID found');
							$scope.isClickAllowed = false;
							$scope.showChannelList = false;
							$scope.showLog = false;
							this.hits = null;
							return;
						  }
						} catch (e) {
							$("#spinner").hide();
						  this.hits = response.data;

						}
					  }
					this.hits = response.data;
					$scope.showChannelList = true;
				});
			}
		}
		$scope.onclickof= function(index, currenttimestamp){

			logContent = '';
			$scope.showLog = true;
			$("#spinner2").show();
			$http.get(`../api/xsi_event/indices`, {params:{startDT:startDt, endDT:endDt, corrId:index}}).then((response) => {

			  var myArr = response.data.hits.hits;
			  console.log(myArr);
			  if (myArr.length < 1)
			  {
			  $scope.showLog = false;
			  $("#spinner2").hide();
				//alert('No Logs Found');
				$scope.openModalBox('No Logs found !!!');
				$scope.isClickAllowed = false;
				$scope.showLog = false;
				return;
			  }
			  $scope.showLog = false;
			  $("#spinner2").hide();
			  var logMessage = '';
			  for (var i = 0; i < myArr.length; i++)
			  {
				var xx = htmlEntities(myArr[i]._source.source);
				var exp = /^(\d{4}\.\d{2}\.\d{2}\s+.*)\n/g;
				var y = xx.match(exp); 
				xx = xx.replace(exp, '<div id="decorate">' + y[0] + '</div>');
				// to highlight channel id
				var y1 = xx.match(exp1);
				//alert(y1);
				xx = xx.replace(exp1, '<strong>' + y1 + '</strong>');
				// to highlight subscription id
				var y2 = xx.match(exp2);
				xx = xx.replace(exp2, '<strong>' + y2 + '</strong>');
				// to highlight event name
				var y3 = xx.match(exp3);
				xx = xx.replace(exp3, '<strong>' + y3 + '</strong>');
				logMessage = logMessage.concat(xx);
			  }
			  for (var i = 0; i < myArr.length; i++)
			  {
				var xx = myArr[i]._source.source;
				logContent = logContent.concat(xx);
			  }
				$scope.showLog = true;
				$("#spinner2").hide();
				$scope.jsonresponse = "Complete Log for Correlation ID: " + index + " ";
				$scope.myHTML = $sce.trustAsHtml(logMessage);
			});
			currenttimestamp = currenttimestamp.replace(/\s+/, "_");
			currenttimestamp = currenttimestamp.replace(/\s+/, "_");
			sipLogName = 'xsilog_' + currenttimestamp + '.log';
			$scope.isClickAllowed = true;
			
		}
		$scope.fetchLogForChannelID= function(index, currenttimestamp){

			logContent = '';
			$scope.showLog = true;
			$("#spinner2").show();
			$http.get(`../api/xsi_event/channelid`, {params:{startDT:startDt, endDT:endDt, chId:index}}).then((response) => {

			  var myArr = response.data.hits.hits;
			  console.log(myArr);
			  if (myArr.length < 1)
			  {
			  $scope.showLog = false;
			  $("#spinner2").hide();
				//alert('No Logs Found');
				$scope.openModalBox('No Logs found !!!');
				$scope.isClickAllowed = false;
				$scope.showLog = false;
				return;
			  }
			  $scope.showLog = false;
			  $("#spinner2").hide();
			  var logMessage = '';
			  for (var i = 0; i < myArr.length; i++)
			  {
				var xx = htmlEntities(myArr[i]._source.source);
				var exp = /^(\d{4}\.\d{2}\.\d{2}\s+.*)\n/g;
				var y = xx.match(exp); 
				xx = xx.replace(exp, '<div id="decorate">' + y[0] + '</div>');
				// to highlight channel id
				var y1 = xx.match(exp1);
				//alert(y1);
				xx = xx.replace(exp1, '<strong>' + y1 + '</strong>');
				// to highlight subscription id
				var y2 = xx.match(exp2);
				xx = xx.replace(exp2, '<strong>' + y2 + '</strong>');
				// to highlight event name
				var y3 = xx.match(exp3);
				xx = xx.replace(exp3, '<strong>' + y3 + '</strong>');
				logMessage = logMessage.concat(xx);
			  }
			  for (var i = 0; i < myArr.length; i++)
			  {
				var xx = myArr[i]._source.source;
				logContent = logContent.concat(xx);
			  }
				$scope.showLog = true;
				$("#spinner2").hide();
				$scope.jsonresponse = "Complete Log for Channel ID: " + index + " ";
				$scope.myHTML = $sce.trustAsHtml(logMessage);
			});
			currenttimestamp = currenttimestamp.replace(/\s+/, "_");
			currenttimestamp = currenttimestamp.replace(/\s+/, "_");
			sipLogName = 'xsilog_' + currenttimestamp + '.log';
			$scope.isClickAllowed = true;
			
		}
		$scope.download = function(){
			download(sipLogName, logContent);
		}

		function htmlEntities(str)
		{
			return String(str).replace(/</g, '&lt;').replace(/>/g, '&gt;');
		}
		function download(filename, text) {
			var pom = document.createElement('a');
			pom.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
			pom.setAttribute('download', filename);

			if (document.createEvent) {
				var event = document.createEvent('MouseEvents');
				event.initEvent('click', true, true);
				pom.dispatchEvent(event);
			}
			else {
				pom.click();
			}
		}
	  } 
	    $scope.fullScreen = function ()
	  {
	  if(isAbsolute)
	  {
	  //alert("isab");
		if ($scope.fullScreenMode) {
		  $scope.fullScreenMode = false;
		   $scope.showTwoPane = true;
		   if(chsubcall) {
			$scope.showCorForAbsolute = true;
			$scope.showChForAbsolute = false;
		  } else {
		  	$scope.showCorForAbsolute = false;
			$scope.showChForAbsolute = true;
		  }
		}
		else {
		  $scope.fullScreenMode = true;
		  $scope.showTwoPane = false;
		  $scope.showChForAbsolute = false;
		  $scope.showCorForAbsolute = false;
		}
	  } else {
	  		if ($scope.fullScreenMode) {
		  $scope.fullScreenMode = false;
		   $scope.showTwoPane = true;
		   if(!chsubcall) {
			$scope.showChannelList = true;
		  } else {
			$scope.showChannelList = false;
			$scope.showCor = true;
		  }
		}
		else {
		  $scope.fullScreenMode = true;
		  $scope.showTwoPane = false;
		  $scope.showChannelList = false;
		  $scope.showCor = false;
		}
		/*if($scope.showLogs){
			if ($scope.fullScreenMode) {
			  $scope.fullScreenMode = false;
			}
			else {
			  $scope.fullScreenMode = true;
			}
		} else {
		  if($scope.showTwoPane) {
		   $scope.showTwoPane = false;
		   } else {
		   $scope.showTwoPane = true;
		   }
		if ($scope.fullScreenMode) {
		  $scope.fullScreenMode = false;
		  $scope.showLog = true;
		}
		else {
		  $scope.fullScreenMode = true;
		}
	  }*/
	  }
	}
});

