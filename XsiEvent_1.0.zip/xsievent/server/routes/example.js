
export default function (server) {
  var callWithRequest = server.plugins.elasticsearch.callWithRequest;
      server.route({
    method: 'GET',
    path: '/api/xsi_event/correlationid',
    handler: function (request, reply) {
		var startDt =request.query.startDT;
		var endDt = request.query.endDT;
		var corrid = request.query.corrId;
		callWithRequest(request, 'search', {
			  index: 'bwlog*, bwlog*xsievent*',
			  type:'log_record',
			  body: {
				  size : '0',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					fields : [ 'logtimestamp', 'body'],
					aggs : {
						corrid_agg : {
							terms : {
								field : 'ocicchannelid',
								size : '1000',
								collect_mode : 'breadth_first'
							}
						}
					},
					query: {
						filtered : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									}
									]
								}
							},
							query:{
							  term:{
								correlationid: corrid
							  }
							}
						}
					}
				}
		  }).then(function (response) {
				var keyPair = {};
				keyPair = response.aggregations.corrid_agg.buckets;
				if (keyPair.length >= 1) {
				  reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				} 
				else {
				  reply(response);
				}
		  });
	}
	});
    server.route({
    method: 'GET',
    path: '/api/xsi_event/uename',
    handler: function (request, reply) {

	var uid = request.query.userId;
	var evnt = request.query.event;
	var startDt =request.query.startDT;
	var endDt = request.query.endDT;
	var wildcard = request.query.wildcard;
	if(uid == '*') {
			if(wildcard == '') {
		      callWithRequest(request, 'search', {
			  index: 'bwlog*, bwlog*xsievent*',
			  type:'log_record',
			  body: {
				  size : '0',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					fields : [ 'logtimestamp', 'body'],
					aggs : {
						corrid_agg : {
							terms : {
								field : 'ocicchannelid',
								size : '1000',
								collect_mode : 'breadth_first'
							}
						}
					},
					query: {
						filtered : {
							filter : {
								bool : {
									must : [ {
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									}
									],
									should: [
										{ 	
										match_phrase: 
											{ 
												xsievent: evnt
											} 
										},
										{ 	
										match_phrase: 
											{ 
												xsitype: evnt
											} 
										}
									],
									minimum_number_should_match : '1'
								}
							}	
						}
					}
				}
		  }).then(function (response) {
				var keyPair = {};
				keyPair = response.aggregations.corrid_agg.buckets;
				if (keyPair.length >= 1) {
				  reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				}
				else {
				  reply(response);
				}
		  });
		  } else {
				callWithRequest(request, 'search', {
				  index: 'bwlog*, bwlog*xsievent*',
				  type:'log_record',
				  body: {
					  size : '0',
						sort : [ {
							logtimestamp : {
								order : 'asc'
							}
						} ],
						fields : [ 'logtimestamp', 'body'],
						aggs : {
							corrid_agg : {
								terms : {
									field : 'ocicchannelid',
									size : '1000',
									collect_mode : 'breadth_first'
								}
							}
						},
						query: {
							filtered : {
								filter : {
									bool : {
										must : [ {
											range : {
												logtimestamp : {
													gte : startDt,
													lte : endDt,
													format: 'epoch_millis',
												}
											}
										}
										],
										should: [
											{ 
												query: 
												{ 
													wildcard : { xsievent : evnt }
												}
											},
											{
												query: 
											   
												   { 
														wildcard : { xsitype : evnt }
													}
											}
										],
										minimum_number_should_match : '1'
									}
								}		
							}
						}
					}
			  }).then(function (response) {
					var keyPair = {};
					keyPair = response.aggregations.corrid_agg.buckets;
					if (keyPair.length >= 1) {
					  reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
						return res;
					  }));
					}
					else {
					  reply(response);
					}
			  });
		  }
	  }	else if(evnt == '*') {
			if(wildcard == '') {
			callWithRequest(request, 'search', {
			  index: 'bwlog*xslog*, bwlog*xsievent*',
			  type:'log_record',
			  body: {
					size : '0',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					fields : [ 'logtimestamp', 'body'],
					aggs : {
						corrid_agg : {
							terms : {
								field : 'ocicchannelid',
								size : '1000',
								collect_mode : 'breadth_first'
							}
						}
					},
					query: {
						filtered : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis',
											}
										}
									}
									]
								}
							},
							query:{
							  term:{
								ocicuserid: uid
							  }
							}	
						}
					}
				}
		  }).then(function (response) {
				var keyPair = {};
				keyPair = response.aggregations.corrid_agg.buckets;
				if (keyPair.length >= 1) {

				  reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				}
				else {
				  reply(response);
				}
		  });
		  } else {
			callWithRequest(request, 'search', {
			  index: 'bwlog*, bwlog*xsievent*',
			  type:'log_record',
			  body: {
				  size : '0',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					fields : [ 'logtimestamp', 'body'],
					aggs : {
						corrid_agg : {
							terms : {
								field : 'ocicchannelid',
								size : '1000',
								collect_mode : 'breadth_first'
							}
						}
					},
					query: {
						filtered : {
							filter : {
								bool : {
									must : [ {
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis',
											}
										}
									},{
									query: {
										wildcard :{
											ocicuserid:uid
											}
										}
									}
									
									]
								}
							}		
						}
					}
				}
		  }).then(function (response) {
				var keyPair = {};
				keyPair = response.aggregations.corrid_agg.buckets;
				if (keyPair.length >= 1) {
				  reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				}
				else {
				  reply(response);
				}
		  });
		  }
	  } else {
		if(wildcard == '') {
			  callWithRequest(request, 'search', {
				  index: 'bwlog*, bwlog*xsievent*',
				  type:'log_record',
				  body: {
					  size : '0',
						sort : [ {
							logtimestamp : {
								order : 'asc'
							}
						} ],
						fields : [ 'logtimestamp', 'body'],
						aggs : {
							corrid_agg : {
								terms : {
									field : 'ocicchannelid',
									size : '1000',
									collect_mode : 'breadth_first'
								}
							}
						},
						query: {
							filtered : {
								filter : {
									bool : {
										must : [ {
											range : {
												logtimestamp : {
													gte : startDt,
													lte : endDt,
													format: 'epoch_millis',
												}
											}
										},
										{ 	
											match_phrase: 
												{ 
													ocicuserid: uid
												} 
											}
										]
									}
								},
								query: {
									bool: {
										should: [
											{ 	
											match_phrase: 
												{ 
													xsievent: {
															query:evnt
														}   
												} 
											},
											{ 	
											match_phrase: 
												{ 
													xsitype: {
															query:evnt
														}   
												} 
											}
										],
										minimum_should_match : '1'
									}
								}		
							}
						}
					}
			  }).then(function (response) {
					var keyPair = {};
					keyPair = response.aggregations.corrid_agg.buckets;
					if (keyPair.length >= 1) {
					  reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
						return res;
					  }));
					}
					else {
					  reply(response);
					}
			  });
		} 
		if(uid.includes('*') && !evnt.includes('*')) {
				callWithRequest(request, 'search', {
			  index: 'bwlog*, bwlog*xsievent*',
			  type:'log_record',
			  body: {
				  size : '0',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					fields : [ 'logtimestamp', 'body'],
					aggs : {
						corrid_agg : {
							terms : {
								field : 'ocicchannelid',
								size : '1000',
								collect_mode : 'breadth_first'
							}
						}
					},
					query: {
						filtered : {
							filter : {
								bool : {
									must : [ {
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis',
											}
										}
									}
									]
								}
							},
							query: {
								bool: {
									must: [
										{
										query: {
											wildcard :{
												ocicuserid:uid
												}
											}
										}
									],
								should: [
									{ 	
									match_phrase: 
										{ 
											xsievent: {
													query:evnt
												}   
										} 
									},
									{ 	
									match_phrase: 
										{ 
											xsitype: {
													query:evnt
												}   
										} 
									}
								],
								minimum_should_match : '1'
								}
							}		
						}
					}
				}
		  }).then(function (response) {
				var keyPair = {};
				keyPair = response.aggregations.corrid_agg.buckets;
				if (keyPair.length >= 1) {
				  reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				}
				else {
				  reply(response);
				}
		  });
		} else if(evnt.includes('*') && !uid.includes('*')) {
				callWithRequest(request, 'search', {
			  index: 'bwlog*, bwlog*xsievent*',
			  type:'log_record',
			  body: {
				  size : '0',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					fields : [ 'logtimestamp', 'body'],
					aggs : {
						corrid_agg : {
							terms : {
								field : 'ocicchannelid',
								size : '1000',
								collect_mode : 'breadth_first'
							}
						}
					},
					query: {
						filtered : {
							filter : {
								bool : {
									must : [ {
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis',
											}
										}
									}
									]
								}
							},
							query: {
								bool: {
									must: [
										{ 	
										match_phrase: 
											{ 
												ocicuserid: {
														query:uid
												}  
											} 
										}
									],
									should: [
										{ 
											query: 
											{ 
												wildcard : { xsievent : evnt }
											}
										},
										{
											query: 
										   
											   { 
													wildcard : { xsitype : evnt }
												}
										}
									],
									minimum_should_match : '1'
								}
							}		
						}
					}
				}
		  }).then(function (response) {
				var keyPair = {};
				keyPair = response.aggregations.corrid_agg.buckets;
				if (keyPair.length >= 1) {
				  reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				}
				else {
				  reply(response);
				}
		  });
		} else {
			if(evnt.includes('*') && uid.includes('*')) {
				callWithRequest(request, 'search', {
				  index: 'bwlog*, bwlog*xsievent*',
				  type:'log_record',
				  body: {
					  size : '0',
						sort : [ {
							logtimestamp : {
								order : 'asc'
							}
						} ],
						fields : [ 'logtimestamp', 'body'],
						aggs : {
							corrid_agg : {
								terms : {
									field : 'ocicchannelid',
									size : '1000',
									collect_mode : 'breadth_first'
								}
							}
						},
						query: {
							filtered : {
								filter : {
									bool : {
										must : [ {
											range : {
												logtimestamp : {
													gte : startDt,
													lte : endDt,
													format: 'epoch_millis',
												}
											}
										}
										]
									}
								},
								query: {
									bool: {
										must: [
											{
											query: {
												wildcard :{
													ocicuserid:uid
													}
												}
											}
										],
										should: [
											{ 
												query: 
												{ 
													wildcard : { xsievent : evnt }
												}
											},
											{
												query: 
											   
												   { 
														wildcard : { xsitype : evnt }
													}
											}
										],
										minimum_should_match : '1'
									}
								}		
							}
						}
					}
			  }).then(function (response) {
					var keyPair = {};
					keyPair = response.aggregations.corrid_agg.buckets;
					if (keyPair.length >= 1) {
					  reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
						return res;
					  }));
					}
					else {
					  reply(response);
					}
			  });
			}
		}
		}	
	
	}
	});
    server.route({
    method: 'GET',
    path: '/api/xsi_event/channelid',
    handler: function (request, reply) {
		var startDt =request.query.startDT;
		var endDt = request.query.endDT;
		var channelid =  request.query.chId;
		callWithRequest(request, 'search', {
			  index: 'bwlog*, bwlog*xsievent*',
			  type:'log_record',
			  body: {
					size : '1000',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query : {
						filtered : {
							query : {
								term : {
									ocicchannelid: channelid,
								}
							}
						}
					}
				}
		  }).then(function (response) {
				var myArr = response.hits.hits;
					reply(
						response
					);
	  });
	}
	});
    server.route({
    method: 'GET',
    path: '/api/xsi_event/ueid',
    handler: function (request, reply) {
		var uid = request.query.userId;
		var evntid = request.query.eventid;
		var startDt =request.query.startDT;
		var endDt = request.query.endDT;
		var wildcard = request.query.wildcard;
		if(uid == '*')
		{
			callWithRequest(request, 'search', {
			  index: 'bwlog*, bwlog*xsievent*',
			  type:'log_record',
			  body: {
				  size : '0',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					fields : [ 'logtimestamp', 'body'],
					aggs : {
						corrid_agg : {
							terms : {
								field : 'ocicchannelid',
								size : '1000',
								collect_mode : 'breadth_first'
							}
						}
					},
					query: {
						filtered : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									}
									]
								}
							},
							query:{
							  term:{
								ociceventid: evntid
							  }
							}
						}
					}
				}
		  }).then(function (response) {
				var keyPair = {};
				keyPair = response.aggregations.corrid_agg.buckets;
				if (keyPair.length >= 1) {
				  reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				} 
				else {
				  reply(response);
				}
		  });
		} else if(evntid == '*'){
			if(wildcard == '') {
			callWithRequest(request, 'search', {
			  index: 'bwlog*, bwlog*xsievent*',
			  type:'log_record',
			  body: {
				  size : '0',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					fields : [ 'logtimestamp', 'body'],
					aggs : {
						corrid_agg : {
							terms : {
								field : 'ocicchannelid',
								size : '1000',
								collect_mode : 'breadth_first'
							}
						}
					},
					query: {
						filtered : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									}
									]
								}
							},
							query:{
							  term:{
								ocicuserid: uid
							  }
							}
						}
					}
				}
		  }).then(function (response) {
				var keyPair = {};
				keyPair = response.aggregations.corrid_agg.buckets;
				if (keyPair.length >= 1) {
				  reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				} 
				else {
				  reply(response);
				}
		  });
			} else {
				callWithRequest(request, 'search', {
				  index: 'bwlog*, bwlog*xsievent*',
				  type:'log_record',
				  body: {
					  size : '0',
						sort : [ {
							logtimestamp : {
								order : 'asc'
							}
						} ],
						fields : [ 'logtimestamp', 'body'],
						aggs : {
							corrid_agg : {
								terms : {
									field : 'ocicchannelid',
									size : '1000',
									collect_mode : 'breadth_first'
								}
							}
						},
						query: {
							filtered : {
								filter : {
									bool : {
										must : [ {
											range : {
												logtimestamp : {
													gte : startDt,
													lte : endDt,
													format: 'epoch_millis',
												}
											}
										}										
										]
									}
								},
								query:{
								  wildcard:{
									ocicuserid: uid
								  }
								}								
							}
						}
					}
			  }).then(function (response) {
					var keyPair = {};
					keyPair = response.aggregations.corrid_agg.buckets;
					if (keyPair.length >= 1) {
					  reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
						return res;
					  }));
					}
					else {
					  reply(response);
					}
			  });
			}
			
		} else {
			if(wildcard == '') {
				callWithRequest(request, 'search', {
				  index: 'bwlog*, bwlog*xsievent*',
				  type:'log_record',
				  body: {
					  size : '0',
						sort : [ {
							logtimestamp : {
								order : 'asc'
							}
						} ],
						fields : [ 'logtimestamp', 'body'],
						aggs : {
							corrid_agg : {
								terms : {
									field : 'ocicchannelid',
									size : '1000',
									collect_mode : 'breadth_first'
								}
							}
						},
						query: {
							filtered : {
								filter : {
									bool : {
										must : [ 
										{
											range : {
												logtimestamp : {
													gte : startDt,
													lte : endDt,
													format: 'epoch_millis'
												}
											}
										},
										{ 	
											match_phrase: 
												{ 
													ocicuserid: uid 
												} 
										},
										{ 
											match_phrase: 
												{
													ociceventid: evntid 
												} 
										}
										]
									}
								}
							}
						}
					}
			  }).then(function (response) {
					var keyPair = {};
					keyPair = response.aggregations.corrid_agg.buckets;
					if (keyPair.length >= 1) {
					  reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
						return res;
					  }));
					} 
					else {
					  reply(response);
					}
			  });
			} else {
				callWithRequest(request, 'search', {
				  index: 'bwlog*, bwlog*xsievent*',
				  type:'log_record',
				  body: {
					  size : '0',
						sort : [ {
							logtimestamp : {
								order : 'asc'
							}
						} ],
						fields : [ 'logtimestamp', 'body'],
						aggs : {
							corrid_agg : {
								terms : {
									field : 'ocicchannelid',
									size : '1000',
									collect_mode : 'breadth_first'
								}
							}
						},
						query: {
							filtered : {
								filter : {
									bool : {
										must : [ 
										{
											range : {
												logtimestamp : {
													gte : startDt,
													lte : endDt,
													format: 'epoch_millis'
												}
											}
										},
										{ 
											match_phrase: 
												{
													ociceventid: evntid 
												} 
										},
										{
											query: {
												wildcard :{
													ocicuserid:uid
													}
											}
										}
										]
									}
								}
							}
						}
					}
			  }).then(function (response) {
					var keyPair = {};
					keyPair = response.aggregations.corrid_agg.buckets;
					if (keyPair.length >= 1) {
					  reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
						return res;
					  }));
					} 
					else {
					  reply(response);
					}
			  });
			}
		}
	}
	});
   server.route({
    method: 'GET',
    path: '/api/xsi_event/indices',
    handler: function (request, reply) {
	var chanId = request.query.chid;
	var subid = request.query.subid;
	var startDt =request.query.startDT;
	var endDt = request.query.endDT;
	var correlationID = request.query.corrId;
	var wildcard = request.query.wildcard;

	if( typeof correlationID == 'undefined') {
	
	  if(chanId == '*') {
		      callWithRequest(request, 'search', {
			  index: 'bwlog*, bwlog*xsievent*',
			  type:'log_record',
			  body: {
				  size : '0',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					fields : [ 'logtimestamp', 'body'],
					aggs : {
						corrid_agg : {
							terms : {
								field : 'correlationid',
								size : '1000',
								collect_mode : 'breadth_first'
							}
						}
					},
					query: {
						filtered : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									}
									]
								}
							},
							query:{
							  term:{
								ocicsubscriptionid: subid
							  }
							}
						}
					}
				}
		  }).then(function (response) {
				var keyPair = {};
				keyPair = response.aggregations.corrid_agg.buckets;
				if (keyPair.length >= 1) {
				  reply(searchInSearch(keyPair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				} 
				else {
				  reply(response);
				}
		  });
	  }	else if(subid == '*') {
			callWithRequest(request, 'search', {
			  index: 'bwlog*, bwlog*xsievent*',
			  type:'log_record',
			  body: {
				  size : '0',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					fields : [ 'logtimestamp', 'body'],
					aggs : {
						corrid_agg : {
							terms : {
								field : 'correlationid',
								size : '1000',
								collect_mode : 'breadth_first'
							}
						}
					},
					query: {
						filtered : {
							filter : {
								bool : {
									must : [ {
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis',
											}
										}
									}
									]
								}
							},
							query:{
							  term:{
								ocicchannelid: chanId
							  }
							}							
						}
					}
				}
		  }).then(function (response) {
				var keyPair = {};
				keyPair = response.aggregations.corrid_agg.buckets;
				if (keyPair.length >= 1) {
				  reply(searchInSearch(keyPair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				}
				else {
				  reply(response);
				}
		  });
	  } else {
      callWithRequest(request, 'search', {
		  index: 'bwlog*, bwlog*xsievent*',
		  type:'log_record',
		  body: {
			  size : '0',
				sort : [ {
					logtimestamp : {
						order : 'asc'
					}
				} ],
				fields : [ 'logtimestamp', 'body'],
				aggs : {
					corrid_agg : {
						terms : {
							field : 'correlationid',
							size : '1000',
							collect_mode : 'breadth_first'
						}
					}
				},
				query: {
					filtered : {
						filter : {
							bool : {
								must : [ {
									range : {
										logtimestamp : {
											gte : startDt,
											lte : endDt,
											format: 'epoch_millis'
										}
									}
								},
									{ 	
										match_phrase: 
											{ 
												ocicsubscriptionid: subid 
											} 
									},
									{ 
										match_phrase: 
											{
												ocicchannelid: chanId 
											} 
									}
								]
							}
						}		
					}
				}
			}
      }).then(function (response) {
			var keyPair = {};
			keyPair = response.aggregations.corrid_agg.buckets;
			if (keyPair.length >= 1) {
			  reply(searchInSearch(keyPair, startDt, endDt, request).then(function (res) {
				return res;
			  }));
			}
			else {
			  reply(response);
			}
      });
	  }
	} else {
			  callWithRequest(request, 'search', {
				  index: 'bwlog*, bwlog*xsievent*',
				  type:'log_record',
				  body: {
						size : '1000',
						sort : [ {
							logtimestamp : {
								order : 'asc'
							}
						} ],
						query : {
							filtered : {
								query : {
									term : {
										correlationid: correlationID,
									}
								}
							}
						}
					}
			  }).then(function (response) {
					var myArr = response.hits.hits;
						reply(
							response
						);
		  });

	}
	}
});

  var searchInSearchChannel = function (chIdArray, startTime, endTime, req) {
    var chidLength = chIdArray.length;
    var finalResult = [];
    var queryBody = [];
    var sample = {};
    if (chidLength < 1) {
      return;
    }
    else {
      for (var x = 0; x < chidLength; x++) {
        queryBody.push('{"index": "bwlog*, bwlog*xsievent*"}');
        var query = { size:1 ,query: {
          filtered:{
            query:{
              term:{
                ocicchannelid: chIdArray[x].key
              }
            }
          }},
    sort:[
      {
        logtimestamp:{
          order:'asc'
        }
      }
    ],
          filter:{
            bool:{
              must:[
                {
                  range:{
                    logtimestamp:{
                      gte:startTime,
                      lte:endTime,
                      format:'epoch_millis'
                    }
                  }
                }
              ]
            }
          }};
        queryBody.push(query);
      }
      return callWithRequest(req,'msearch', {
        'requestTimeout' : 60000,
        body : queryBody
      }).then(function (response) {
        var myArr = response.responses;
        return myArr;
      });
    }
  };

  var searchInSearch = function (corrIdArray, startTime, endTime, req) {
    var corridLength = corrIdArray.length;
    var finalResult = [];
    var queryBody = [];
    var sample = {};
    if (corridLength < 1) {
      return;
    }
    else {
      for (var x = 0; x < corridLength; x++) {
        queryBody.push('{"index": "bwlog*, bwlog*xsievent*"}');
        var query = { size:1 ,query: {
          filtered:{
            query:{
              term:{
                correlationid: corrIdArray[x].key
              }
            }
          }},
    sort:[
      {
        logtimestamp:{
          order:'asc'
        }
      }
    ],
          filter:{
            bool:{
              must:[
                {
                  range:{
                    logtimestamp:{
                      gte:startTime,
                      lte:endTime,
                      format:'epoch_millis'
                    }
                  }
                }
              ]
            }
          }};
        queryBody.push(query);
      }
      return callWithRequest(req,'msearch', {
        'requestTimeout' : 60000,
        body : queryBody
      }).then(function (response) {
        var myArr = response.responses;
        return myArr;
      });
    }


  };
  };



