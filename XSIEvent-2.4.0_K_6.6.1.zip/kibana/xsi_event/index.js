import exampleRoute from './server/routes/example';

export default function (kibana) {

  var mainFile = 'plugins/xsi_event/app';


  return new kibana.Plugin({
	  id: 'xsi_event',
    require: ['elasticsearch'],

    uiExports: {
      app: {
        title: 'XSI Events',
        description: 'XSI Event Log Utility',
        main: mainFile,
		icon: 'plugins/xsi_event/logo-scaled.png',
    init(server) {
        server.injectUiAppVars('xsi events', () => {
        return {
          kbnIndex: server.config.kbnIndex,
          esShardTimeout: server.config.esShardTimeout,
          esApiVersion: server.config.esApiVersion,
        };
      });
      // Add server routes and initalize the plugin here
      serverRoute(server);
    }
      }
    },

    config(Joi) {
      return Joi.object({
        enabled: Joi.boolean().default(true),
      }).default();
    },

    init(server, options) {
      // Add server routes and initalize the plugin here
      exampleRoute(server);
    }

  });
};
