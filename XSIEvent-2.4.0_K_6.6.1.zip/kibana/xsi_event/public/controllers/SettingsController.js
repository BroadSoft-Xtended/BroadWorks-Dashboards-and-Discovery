import { uiModules } from "ui/modules";

uiModules
.get('app/xsi_event', ['720kb.tooltips','ngDialog','angularUtils.directives.dirPagination','ngCookies', 'angularSpinner',
 'ui.bootstrap.contextMenu','ng', 'ngAria', 'ngMessages'])
.controller('settingsController', function ($scope, $route, $cookies, $http, ngDialog) {

   var tabClasses;
  
  function initTabs() {
    tabClasses = ["","","",""];
  }
  
  $scope.getTabClass = function (tabNum) {
    return tabClasses[tabNum];
  };
  
  $scope.getTabPaneClass = function (tabNum) {
    return "tab-pane " + tabClasses[tabNum];
  }
  
  $scope.setActiveTab = function (tabNum) {
    initTabs();
    tabClasses[tabNum] = "active";
  };
  
  //Initialize 
  initTabs();
  $scope.setActiveTab(1);
    /**
  * @desc Comman Non Modal Box for alert.
  * @param message- contains message to be displayed to user
  * @return void
  */
  $scope.openModalBox = function (message) {
    ngDialog.open({ template: '<p>' + message + '</p>', plain: true });
  };
  
    /**
  * @desc Comman Non Modal Box for alert.
  * @param message- contains message to be displayed to user
  * @return void
  */
  $scope.openErrorAlert = function (message) {
    var response = message.split('-');
    ngDialog.open({ template: '<p class="alertBox">' + response[0] + '</p>' +
    '<ul class="alertBoxBody"><li>' + response[1] + '</li></ul>',
    plain: true });
  };
  /**
   * [indexName Contains the Tribe Node Name, along with pattern]
   * @type {List of search index pattern}
   */
  $scope.readTribePropFile = function () {
    $http.get('../api/xsi_event/downloadFile',{

    }).then((response) => {
      if (response.data === 'Error in Configuration File') {
        $scope.openModalBox('Invalid Configuration File');
      } else {
        console.log(response.data);
        $scope.indexName = response.data;
      }
    });
  };
  $scope.readTribePropFile();

  /**
   * [globalSetting Apply the setting globalCookie]
   * @return {[void]} [creates new cookie when setting is applied]
   */
  $scope.globalSetting = function () {
    console.log($scope.Data);
    $cookies.put('globalConfiguration', JSON.stringify($scope.Data));
  };

  $scope.items = [
            { name: 'Small Health Potion', cost: 4 },
            { name: 'Small Mana Potion', cost: 5 },
            { name: 'Iron Short Sword', cost: 12 }
  ];



});
