// To load all the modules
require('ui/autoload/all');
require('./app');