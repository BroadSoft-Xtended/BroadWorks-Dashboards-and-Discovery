
export default function (server) {
    var _server$plugins$elasticsearch$getCluster = server.plugins.elasticsearch.getCluster('data');

    var callWithRequest = _server$plugins$elasticsearch$getCluster.callWithRequest;
    server.route({
    path: '/api/xsi_event/downloadFile',
    method: 'GET',
    handler(req, reply)
    {
      // Home Location of the Kibana
      var config = require('../../tribenode.json');
      //console.log(config.tribeLocation);
      if (typeof config.tribeLocation === 'undefined') {
        reply('Error in Configuration File');
      }
      else {
        reply(config.tribeLocation);
      }
    }
  });
  
   var frameIndexBody = function (document, header) {
    var size = document.length;
    var body = [];
    for (var i = 0; i < size; i++) {
      //console.log('{index: {_index: \'indexpattern\', _type: \'pattern\'}}');
      body.push(header);
      //console.log(document[i]);
      body.push(document[i]);
    }
    return body;
  };

  server.route({
    path: '/api/xsi_event/addTribeIndexPattern',
    method: 'GET',
    handler(req, reply) {
      var document = req.query.document;
      var header = '{index: {_index: "indexpattern", _type: "pattern"}}';
      var doc = [];
      if (document instanceof Array) {
        doc = frameIndexBody(document, header);
      }
      else {
        doc.push(header);
        //console.log(document);
        doc.push(document);
      }
      //console.log(doc);
      //console.log(req.query.document);
      callWithRequest(req,'bulk', {
        'requestTimeout' : 60000,
        body: doc
      }).then(function (response) {
        //console.log(response);
        reply(response);
      }, function (error) {
        reply('Unexpected Error');
      });
    }
  });

  server.route({
    path: '/api/xsi_event/selectTribeIndexPattern',
    method: 'GET',
    handler(req, reply) {
      callWithRequest(req,'search', {
        index: 'indexpattern',
        'requestTimeout' : 60000,
        'size' : 100
      }).then(function (response) {
        //console.log(response);
        reply(response);
      }, function (error) {
        reply('Unexpected Error');
      });
    }
  });

  server.route({
    path: '/api/xsi_event/removeIndexPattern',
    method: 'GET',
    handler(req, reply) {
      callWithRequest(req,'delete', {
        index: 'indexpattern',
        type: 'pattern',
        id: req.query.documentID
      }).then(function (response) {
        //console.log(response);
        reply(response);
      }, function (error) {
        reply('Unexpected Error');
      });
    }
  });

  server.route({
    path: '/api/xsi_event/updateTribeIndexPattern',
    method: 'GET',
    handler(req, reply) {

      callWithRequest(req,'update', {
        index: 'indexpattern',
        type: 'pattern',
        id: req.query.documentID,
        body: {
          doc: {
            index_alias: req.query.updatedPattern
          }
        }
      }).then(function (response) {
        //console.log(response);
        reply(response);
      }, function (error) {
        reply('Unexpected Error');
      });
    }
  });

  server.route({
    path: '/api/xsi_event/readServer',
    method: 'GET',
    handler(req, reply) {
      // Home Location of the Kibana
      var config = require('../../tribenode.json');
      //console.log(config.tribeLocation);
      if (typeof config.javaClient === 'undefined') {
        reply('Error in Configuration File');
      }
      else {
        reply(config.javaClient);
      }
    }
  });
    server.route({
    method: 'GET',
    path: '/api/xsi_event/EvMsgFromEventID',
    handler: function (request, reply) {
		var startDt =request.query.startDT;
		var endDt = request.query.endDT;
		var evntid =  request.query.eventID;
		var noTimeFrame = request.query.noTimeFrame;
		if(noTimeFrame == 'true')
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
				  size : '1500',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query: {
						bool : {
							must:{
							  term:{
								ociceventid: evntid
							  }
							}
						}
					}
				}
		  }).then(function (response) {
				reply(response);
	  });
		} else {
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
				  size : '1500',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query: {
						bool : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									}
									]
								}
							},
							must:{
							  term:{
								ociceventid: evntid
							  }
							}
						}
					}
				}
		  }).then(function (response) {
				reply(response);
	  });
		}
	}
	});
  	server.route({
    method: 'GET',
    path: '/api/xsi_event/ChMsgFromChannelSetID',
    handler: function (request, reply) {
		var startDt =request.query.startDT;
		var endDt = request.query.endDT;
		var channelsetid =  request.query.channelsetID;
		var noTimeFrame = request.query.noTimeFrame;
		if(noTimeFrame == 'true')
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
				  size : '1500',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query: {
						bool : {
							must:{
							  term:{
								channelsetid: channelsetid
							  }
							}
						}
					}
				}
		  }).then(function (response) {
				reply(response);
	  });
		}
		else 
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
				  size : '1500',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query: {
						bool : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									}
									]
								}
							},
							must:{
							  term:{
								channelsetid: channelsetid
							  }
							}
						}
					}
				}
		  }).then(function (response) {
				reply(response);
	  });
		}

	}
	});
  server.route({
    method: 'GET',
    path: '/api/xsi_event/EventMsgForSubID',
    handler: function (request, reply) {
		var noTimeFrame = request.query.noTimeFrame;
		var idx = request.query.searchIndex;
		var startDt =request.query.startDT;
		var endDt = request.query.endDT;
		var subsid =  request.query.subscriptionID;
		if(noTimeFrame == 'true')
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
				  size : '1500',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query: {
						bool : {
							must:{
							  term:{
								ocicsubscriptionid: subsid
							  }
							}
						}
					}
				}
		  }).then(function (response) {
				reply(response);
			});
		}
		else 
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
				  size : '1500',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query: {
						bool : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									}
									]
								}
							},
							must : {
								term:{
									ocicsubscriptionid: subsid
								}
							}
						}
					}
				}
		  }).then(function (response) {
				reply(response);
	  });
		}
	}
	});
    server.route({
    method: 'GET',
    path: '/api/xsi_event/ChannelMsg',
    handler: function (request, reply) {
		var startDt =request.query.startDT;
		var endDt = request.query.endDT;
		var channelid =  request.query.channelID;
		var noTimeFrame = request.query.noTimeFrame;
		if(noTimeFrame == 'true')
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
				  size : '1',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query: {
						bool : {
							filter : {
								bool : {
									must : [ 
									{
									  match_phrase:
									  {
										channelid :channelid
									  }
									},
									{
									  match_phrase:
									  {
										channeltype :"ChannelAddResponse"
									  }
									}
									]
								}
							}
						}
					}
				}
		  }).then(function (response) {
				reply(response);
	  });
		}
		else 
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			 // type:'log_record',
			  body: {
				  size : '1',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query: {
						bool : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									},
									{
									  match_phrase:
									  {
										channelid :channelid
									  }
									},
									{
									  match_phrase:
									  {
										channeltype :"ChannelAddResponse"
									  }
									}
									]
								}
							}
						}
					}
				}
		  }).then(function (response) {
				reply(response);
	  });
		}
	}
	});
	server.route({
    method: 'GET',
    path: '/api/xsi_event/EventMsgForUID',
    handler: function (request, reply) {
		var startDt =request.query.startDT;
		var endDt = request.query.endDT;
		var userID =  request.query.userID;
		var noTimeFrame = request.query.noTimeFrame;
		if(noTimeFrame == 'true')
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			 // type:'log_record',
			  body: {
				  size : '1500',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query: {
						bool : {
							must:{
							  match:{
								ocicuserid: userID
							  }
							}
						}
					}
				}
		  }).then(function (response) {
				reply(response);
	  });
		}
		else 
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			 // type:'log_record',
			  body: {
				  size : '1500',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query: {
						bool : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									}
									]
								}
							},
							must:{
							  match:{
								ocicuserid: userID
							  }
							}
							
						}
					}
				}
		  }).then(function (response) {
				reply(response);
	  });
		}

	}
	});
	server.route({
    method: 'GET',
    path: '/api/xsi_event/SubRequest',
    handler: function (request, reply) {
		var startDt =request.query.startDT;
		var endDt = request.query.endDT;
		var userID =  request.query.userID;
		var noTimeFrame = request.query.noTimeFrame;
		if(noTimeFrame == 'true')
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			 // type:'log_record',
			  body: {
				  size : '1500',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query: {
						bool : {
							must:{
							  match:{
								userid: userID
							  }
							}
						}
					}
				}
		  }).then(function (response) {
				reply(response);
	  });
		}
		else 
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			 // type:'log_record',
			  body: {
				  size : '1500',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query: {
						bool : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									}
									]
								}
							},
							must : {
								match:{
									userid: userID
								}
							}
						}
					}
				}
		  }).then(function (response) {
				reply(response);
	  });
		}

	}
	});
	server.route({
    method: 'GET',
    path: '/api/xsi_event/SubscriptionResponse',
    handler: function (request, reply) {
		var startDt =request.query.startDT;
		var endDt = request.query.endDT;
		var subID =  request.query.subscriptionID;
		var noTimeFrame = request.query.noTimeFrame;
		if(noTimeFrame == 'true')
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
				  size : '1',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query: {
						bool : {
							must:{
							  term:{
								subscriptionid: subID
							  }
							}
						}
					}
				}
		  }).then(function (response) {
				reply(response);
	  });
		}
		else 
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			 // type:'log_record',
			  body: {
				  size : '1',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query: {
						bool : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									}
									]
								}								
							},
							must:
							{
								term:{
									subscriptionid: subID
								}
							}
						}
					}
				}
		  }).then(function (response) {
				reply(response);
	  });
		}

	}
	});
	server.route({
    method: 'GET',
    path: '/api/xsi_event/EventMsg',
    handler: function (request, reply) {
		var startDt =request.query.startDT;
		var endDt = request.query.endDT;
		var channelid =  request.query.channelID;
		var noTimeFrame = request.query.noTimeFrame;
		if(noTimeFrame == 'true')
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			 // type:'log_record',
			  body: {
				  size : '1500',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query: {
						bool : {
							must:{
							  term:{
								ocicchannelid: channelid
							  }
							}
						}
					}
				}
		  }).then(function (response) {
				reply(response);
	  });
		}
		else 
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			 // type:'log_record',
			  body: {
				  size : '1500',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query: {
						bool : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									}
									]
								}
							},
							must:{
								term:{
								ocicchannelid: channelid
							  }
							}
						}
					}
				}
		  }).then(function (response) {
				reply(response);
	  });
		}

	}
	});
	server.route({
    method: 'GET',
    path: '/api/xsi_event/ChMsgFromauthUserid',
    handler: function (request, reply) {
		var startDt =request.query.startDT;
		var endDt = request.query.endDT;
		var userid =  request.query.userID;
		var noTimeFrame = request.query.noTimeFrame;
		if(noTimeFrame == 'true')
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
				  size : '1500',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query: {
						bool : {
							filter : {
								bool : {			
									must: [
										{
										  match_phrase:
										  {
											channeltype :"ChannelAddRequest"
										  }
										}
									]
								}
							},
							must:{
								term:{
								authuserid: userid
							  }
							}
						}
					}
				}
		  }).then(function (response) {
				reply(response);
	  });
		}
		else 
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			 // type:'log_record',
			  body: {
				  size : '1500',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query: {
						bool : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									}
									],       
									must: [
													{
										  match_phrase:
										  {
										  channeltype :"ChannelAddRequest"
										  }
									  }
										]
								}
							},
							must:{
									term:{
									authuserid: userid
								  }
								}
						}
					}
				}
		  }).then(function (response) {
				reply(response);
	  });
		}

	}
	});
	server.route({
    method: 'GET',
    path: '/api/xsi_event/SubMsg',
    handler: function (request, reply) {
		var startDt =request.query.startDT;
		var endDt = request.query.endDT;
		var channelsetid =  request.query.channelsetID;
		var noTimeFrame = request.query.noTimeFrame;
		if(noTimeFrame == 'true')
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			 // type:'log_record',
			  body: {
				  size : '1500',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query: {
						bool : {
							filter : {
								bool : {			
									must_not: [
													{
										  match_phrase:
										  {
										  channeltype :"ChannelAddRequest"
										  }
									  }
										]
								}
							},
							must:{
								term:{
									channelsetid: channelsetid
								}
							}
					}
				}
			  }
		  }).then(function (response) {
				reply(response);
		});
		}
		else 
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
				  size : '1500',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						
					} }],
					query: {
						bool : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									}
									],									
									must_not: [
													{
										  match_phrase:
										  {
										  channeltype :"ChannelAddRequest"
										  }
									  }
										]
								}
							},
							must:{
								term:{
									channelsetid: channelsetid
								}
							}
						}
					}
				}
		  }).then(function (response) {
				reply(response);
	  });
		}

	}
	});
	server.route({
    method: 'GET',
    path: '/api/xsi_event/recommendedCorrId',
    handler: function (request, reply) {
		var startDt =request.query.startDT;
		var endDt = request.query.endDT;
		var corrid =  request.query.correlationID;
		var noTimeFrame = request.query.noTimeFrame;
		
		if(noTimeFrame == 'true')
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			 // type:'log_record',
			  body: {
				  size : '2',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query: {
						bool : {
							must: {
							  term: {
								correlationid :corrid
							  }
							}
						}
					}
				}
		  }).then(function (response) {
				reply(response);
	  });
		}
		else 
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
				  size : '2',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query: {
						bool : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									}
									]
								}
							},
							must: {
							  term: {
								correlationid :corrid
							  }
							}
						}
					}
				}
		  }).then(function (response) {
				reply(response);
	  });
		}

	}
	});
      server.route({
    method: 'GET',
    path: '/api/xsi_event/channelId',
    handler: function (request, reply) {
		var startDt =request.query.startDT;
		var endDt = request.query.endDT;
		var channelid =  request.query.chId;		
		callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
				  size : '0',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					_source : [ 'logtimestamp', 'body'],
					aggs : {
						corrid_agg : {
							terms : {
								field : 'correlationid',
								size : '1000',
								collect_mode : 'breadth_first'
							}
						}
					},
					query: {
						bool : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									}
									]
								}
							},
							must :{
								term:{
									ocicchannelid: channelid
								  }
							}
						}
					}
				}
		  }).then(function (response) {
			  
				var keyPair = {};
				if(response) {
					if(response.aggregations) {
						keyPair = response.aggregations.corrid_agg.buckets;
						if (keyPair.length >= 1) {
						  reply(searchInSearch(keyPair, startDt, endDt, request).then(function (res) {
							return res;
						  }));
						}
					}
				}
				else return response;

	  });
	}
	});
      server.route({
    method: 'GET',
    path: '/api/xsi_event/correlationid',
    handler: function (request, reply) {
		var startDt =request.query.startDT;
		var endDt = request.query.endDT;
		var corrid = request.query.corrId;
		callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
				  size : '0',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					_source : [ 'logtimestamp', 'body'],
					aggs : {
						corrid_agg : {
							terms : {
								field : 'ocicchannelid',
								size : '1000',
								collect_mode : 'breadth_first'
							}
						}
					},
					query: {
						bool : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									}
									]
								}
							},
							must: {
								term:{
									correlationid: corrid
								}
							}
						}
					}
				}
		  }).then(function (response) {
			//console.log(response.hits.hits.length);
			if (response.hits.hits.length === 0) {
			  try {
				var keypair = {};
				keypair = response.aggregations.corrid_agg.buckets;
				if(keypair) 
				{	
				if (keypair.length > 0)
				{
					//console.log("searchinsearch" + keypair.length);
				  reply(searchInSearchChannel(keypair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				}
				else {
				  //console.log('EMpty else block');
				  reply('Empty');
				}
				}
			  }
			  catch (e) {
				//console.log(e);
			   //console.log('EMpty block');
				reply('Empty');
			  }
			}
			else {
			  var keyPair = {};
			  keyPair = response.aggregations.corrid_agg.buckets;
			  if (keyPair.length > 0) {
				 reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
					return res;
					}));
			  }
			else {
			  //At Times, results are empty while fetching correlationId
				reply(response);
			  }
			}
		  });
	}
	});
    server.route({
    method: 'GET',
    path: '/api/xsi_event/uename',
    handler: function (request, reply) {

	var uid = request.query.userId;
	var evnt = request.query.event;
	var startDt =request.query.startDT;
	var endDt = request.query.endDT;
	var wildcard = request.query.wildcard;
	if(uid == '*') {
			if(wildcard == '') {
		      callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
				  size : '0',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					_source : [ 'logtimestamp', 'body'],
					aggs : {
						corrid_agg : {
							terms : {
								field : 'ocicchannelid',
								size : '1000',
								collect_mode : 'breadth_first'
							}
						}
					},
					query: {
						bool : {
							filter : {
								bool : {
									must : [ {
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									}
									],
									should: [
										{ 	
										match_phrase: 
											{ 
												xsievent: evnt
											} 
										},
										{ 	
										match_phrase: 
											{ 
												xsitype: evnt
											} 
										}
									],
									minimum_number_should_match : '1'
								}
							}	
						}
					}
				}
		  }).then(function (response) {
				  //console.log(response.hits.hits.length);
			if (response.hits.hits.length === 0) {
			  try {
				var keypair = {};
				keypair = response.aggregations.corrid_agg.buckets;
				if(keypair) 
				{	
				if (keypair.length > 0)
				{
					//console.log("searchinsearch" + keypair.length);
				  reply(searchInSearchChannel(keypair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				}
				else {
				  //console.log('EMpty else block');
				  reply('Empty');
				}
				}
			  }
			  catch (e) {
				//console.log(e);
			   //console.log('EMpty block');
				reply('Empty');
			  }
			}
			else {
			  var keyPair = {};
			  keyPair = response.aggregations.corrid_agg.buckets;
			  if (keyPair.length > 0) {
				 reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
					return res;
					}));
			  }
			else {
			  //At Times, results are empty while fetching correlationId
				reply(response);
			  }
			}

		  });
		  } else {
				callWithRequest(request, 'search', {
				  index: request.query.searchIndex,
				  //type:'log_record',
				  body: {
					  size : '0',
						sort : [ {
							logtimestamp : {
								order : 'asc'
							}
						} ],
						_source : [ 'logtimestamp', 'body'],
						aggs : {
							corrid_agg : {
								terms : {
									field : 'ocicchannelid',
									size : '1000',
									collect_mode : 'breadth_first'
								}
							}
						},
						query: {
							bool : {
								filter : {
									bool : {
										must : [ {
											range : {
												logtimestamp : {
													gte : startDt,
													lte : endDt,
													format: 'epoch_millis',
												}
											}
										}
										]
									}
								},
							should: [
								{ 
										wildcard : { xsievent : evnt }
								},
								{
											wildcard : { xsitype : evnt }
								}
							],
							minimum_should_match : '1'							
							}
						}
					}
			  }).then(function (response) {
				  //console.log(response.hits.hits.length);
			if (response.hits.hits.length === 0) {
			  try {
				var keypair = {};
				keypair = response.aggregations.corrid_agg.buckets;
				if(keypair) 
				{	
				if (keypair.length > 0)
				{
					//console.log("searchinsearch" + keypair.length);
				  reply(searchInSearchChannel(keypair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				}
				else {
				  //console.log('EMpty else block');
				  reply('Empty');
				}
				}
			  }
			  catch (e) {
				//console.log(e);
			   //console.log('EMpty block');
				reply('Empty');
			  }
			}
			else {
			  var keyPair = {};
			  keyPair = response.aggregations.corrid_agg.buckets;
			  if (keyPair.length > 0) {
				 reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
					return res;
					}));
			  }
			else {
				reply(response);
			  }
			}

			  });
		  }
	  }	else if(evnt == '*') {
			if(wildcard == '') {
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
					size : '0',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					_source : [ 'logtimestamp', 'body'],
					aggs : {
						corrid_agg : {
							terms : {
								field : 'ocicchannelid',
								size : '1000',
								collect_mode : 'breadth_first'
							}
						}
					},
					query: {
						bool : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis',
											}
										}
									}
									]
								}
							},
							must:{
							  term:{
								ocicuserid: uid
							  }
							}	
						}
					}
				}
		  }).then(function (response) {
				  //console.log(response.hits.hits.length);
			if (response.hits.hits.length === 0) {
			  try {
				var keypair = {};
				keypair = response.aggregations.corrid_agg.buckets;
				if(keypair) 
				{	
				if (keypair.length > 0)
				{
					//console.log("searchinsearch" + keypair.length);
				  reply(searchInSearchChannel(keypair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				}
				else {
				  //console.log('EMpty else block');
				  reply('Empty');
				}
				}
			  }
			  catch (e) {
				//console.log(e);
			   //console.log('EMpty block');
				reply('Empty');
			  }
			}
			else {
			  var keyPair = {};
			  keyPair = response.aggregations.corrid_agg.buckets;
			  if (keyPair.length > 0) {
				 reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
					return res;
					}));
			  }
			else {
			  //At Times, results are empty while fetching correlationId
				reply(response);
			  }
			}

		  });
		  } else {
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
				  size : '0',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					_source : [ 'logtimestamp', 'body'],
					aggs : {
						corrid_agg : {
							terms : {
								field : 'ocicchannelid',
								size : '1000',
								collect_mode : 'breadth_first'
							}
						}
					},
					query: {
						bool : {
							filter : {
								bool : {
									must : [ {
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis',
											}
										}
									}									
									]
								}
							},
							must: [
								{ 
									wildcard : { ocicuserid : uid }
								}
							]							
						}
					}
				}
		  }).then(function (response) {
				  //console.log(response.hits.hits.length);
			if (response.hits.hits.length === 0) {
			  try {
				var keypair = {};
				keypair = response.aggregations.corrid_agg.buckets;
				if(keypair) 
				{	
				if (keypair.length > 0)
				{
					//console.log("searchinsearch" + keypair.length);
				  reply(searchInSearchChannel(keypair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				}
				else {
				  //console.log('EMpty else block');
				  reply('Empty');
				}
				}
			  }
			  catch (e) {
				//console.log(e);
			   //console.log('EMpty block');
				reply('Empty');
			  }
			}
			else {
			  var keyPair = {};
			  keyPair = response.aggregations.corrid_agg.buckets;
			  if (keyPair.length > 0) {
				 reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
					return res;
					}));
			  }
			else {
			  //At Times, results are empty while fetching correlationId
				reply(response);
			  }
			}

		  });
		  }
	  } else {
		if(wildcard == '') {
			  callWithRequest(request, 'search', {
				  index: request.query.searchIndex,
				  //type:'log_record',
				  body: {
					  size : '0',
						sort : [ {
							logtimestamp : {
								order : 'asc'
							}
						} ],
						_source : [ 'logtimestamp', 'body'],
						aggs : {
							corrid_agg : {
								terms : {
									field : 'ocicchannelid',
									size : '1000',
									collect_mode : 'breadth_first'
								}
							}
						},
						query: {
							bool : {
								filter : {
									bool : {
										must : [ {
											range : {
												logtimestamp : {
													gte : startDt,
													lte : endDt,
													format: 'epoch_millis',
												}
											}
										},
										{ 	
											match_phrase: 
												{ 
													ocicuserid: uid
												} 
											}
										]
									}
								},
								should: [
									{ 	
									match_phrase: 
										{ 
											xsievent: evnt
										} 
									},
									{ 	
									match_phrase: 
										{ 
											xsitype: evnt
										} 
									}
								],
								minimum_number_should_match : '1'
							}
						}
					}
			  }).then(function (response) {
				  //console.log(response.hits.hits.length);
			if (response.hits.hits.length === 0) {
			  try {
				var keypair = {};
				keypair = response.aggregations.corrid_agg.buckets;
				if(keypair) 
				{	
				if (keypair.length > 0)
				{
					//console.log("searchinsearch" + keypair.length);
				  reply(searchInSearchChannel(keypair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				}
				else {
				  //console.log('EMpty else block');
				  reply('Empty');
				}
				}
			  }
			  catch (e) {
				//console.log(e);
			   //console.log('EMpty block');
				reply('Empty');
			  }
			}
			else {
			  var keyPair = {};
			  keyPair = response.aggregations.corrid_agg.buckets;
			  if (keyPair.length > 0) {
				 reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
					return res;
					}));
			  }
			else {
			  //At Times, results are empty while fetching correlationId
				reply(response);
			  }
			}

			  });
		} 
		if(uid.includes('*') && !evnt.includes('*')) {
				callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
				  size : '0',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					_source : [ 'logtimestamp', 'body'],
					aggs : {
						corrid_agg : {
							terms : {
								field : 'ocicchannelid',
								size : '1000',
								collect_mode : 'breadth_first'
							}
						}
					},
					query: {
						bool : {
							filter : {
								bool : {
									must : [ {
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis',
											}
										}
									}
									]
								}
							},
							must: [
								{
								wildcard :{
									ocicuserid:uid
									}
								}
							],
						should: [
							{ 	
							match_phrase: 
								{ 
									xsievent: evnt
								} 
							},
							{ 	
							match_phrase: 
								{ 
									xsitype: evnt
								} 
							}
						],
						minimum_number_should_match : '1'

						}
					}
				}
		  }).then(function (response) {
				  //console.log(response.hits.hits.length);
			if (response.hits.hits.length === 0) {
			  try {
				var keypair = {};
				keypair = response.aggregations.corrid_agg.buckets;
				if(keypair) 
				{	
				if (keypair.length > 0)
				{
					//console.log("searchinsearch" + keypair.length);
				  reply(searchInSearchChannel(keypair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				}
				else {
				  //console.log('EMpty else block');
				  reply('Empty');
				}
				}
			  }
			  catch (e) {
				//console.log(e);
			   //console.log('EMpty block');
				reply('Empty');
			  }
			}
			else {
			  var keyPair = {};
			  keyPair = response.aggregations.corrid_agg.buckets;
			  if (keyPair.length > 0) {
				 reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
					return res;
					}));
			  }
			else {
			  //At Times, results are empty while fetching correlationId
				reply(response);
			  }
			}

		  });
		} else if(evnt.includes('*') && !uid.includes('*')) {
				callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
				  size : '0',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					_source : [ 'logtimestamp', 'body'],
					aggs : {
						corrid_agg : {
							terms : {
								field : 'ocicchannelid',
								size : '1000',
								collect_mode : 'breadth_first'
							}
						}
					},
					query: {
						bool : {
							filter : {
								bool : {
									must : [ {
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis',
											}
										}
									}
									]
								}
							},
							must: [
								{ 	
								match_phrase: 
									{ 
										ocicuserid: {
												query:uid
										}  
									} 
								}
							],
							should: [
								{ 
									wildcard : { xsievent : evnt }
								},
								{
									wildcard : { xsitype : evnt }
								}
							],
							minimum_number_should_match : '1'
	
						}
					}
				}
		  }).then(function (response) {
				  //console.log(response.hits.hits.length);
			if (response.hits.hits.length === 0) {
			  try {
				var keypair = {};
				keypair = response.aggregations.corrid_agg.buckets;
				if(keypair) 
				{	
				if (keypair.length > 0)
				{
					//console.log("searchinsearch" + keypair.length);
				  reply(searchInSearchChannel(keypair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				}
				else {
				  //console.log('EMpty else block');
				  reply('Empty');
				}
				}
			  }
			  catch (e) {
				//console.log(e);
			   //console.log('EMpty block');
				reply('Empty');
			  }
			}
			else {
			  var keyPair = {};
			  keyPair = response.aggregations.corrid_agg.buckets;
			  if (keyPair.length > 0) {
				 reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
					return res;
					}));
			  }
			else {
			  //At Times, results are empty while fetching correlationId
				reply(response);
			  }
			}

		  });
		} else {
			if(evnt.includes('*') && uid.includes('*')) {
				callWithRequest(request, 'search', {
				  index: request.query.searchIndex,
				  //type:'log_record',
				  body: {
					  size : '0',
						sort : [ {
							logtimestamp : {
								order : 'asc'
							}
						} ],
						_source : [ 'logtimestamp', 'body'],
						aggs : {
							corrid_agg : {
								terms : {
									field : 'ocicchannelid',
									size : '1000',
									collect_mode : 'breadth_first'
								}
							}
						},
						query: {
							bool : {
								filter : {
									bool : {
										must : [ {
											range : {
												logtimestamp : {
													gte : startDt,
													lte : endDt,
													format: 'epoch_millis',
												}
											}
										}
										]
									}
								},
								must: [
									{
									wildcard :{
										ocicuserid:uid
										}
									}
								],
								should: [
									{ 
										wildcard : { xsievent : evnt }
									},
									{
										wildcard : { xsitype : evnt }
									}
								],
								minimum_should_match : '1'

							}
						}
					}
			  }).then(function (response) {
				  //console.log(response.hits.hits.length);
			if (response.hits.hits.length === 0) {
			  try {
				var keypair = {};
				keypair = response.aggregations.corrid_agg.buckets;
				if(keypair) 
				{	
				if (keypair.length > 0)
				{
					//console.log("searchinsearch" + keypair.length);
				  reply(searchInSearchChannel(keypair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				}
				else {
				  //console.log('EMpty else block');
				  reply('Empty');
				}
				}
			  }
			  catch (e) {
				//console.log(e);
			   //console.log('EMpty block');
				reply('Empty');
			  }
			}
			else {
			  var keyPair = {};
			  keyPair = response.aggregations.corrid_agg.buckets;
			  if (keyPair.length > 0) {
				 reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
					return res;
					}));
			  }
			else {
			  //At Times, results are empty while fetching correlationId
				reply(response);
			  }
			}

			  });
			}
		}
		}	
	
	}
	});
    server.route({
    method: 'GET',
    path: '/api/xsi_event/channelid',
    handler: function (request, reply) {
		var startDt =request.query.startDT;
		var endDt = request.query.endDT;
		var channelid =  request.query.chId;
		callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
					size : '1000',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					query : {
						bool : {
							must : {
								term : {
									ocicchannelid: channelid,
								}
							}
						}
					}
				}
		  }).then(function (response) {
				var myArr = response.hits.hits;
					reply(
						response
					);
	  });
	}
	});
    server.route({
    method: 'GET',
    path: '/api/xsi_event/ueid',
    handler: function (request, reply) {
		var uid = request.query.userId;
		var evntid = request.query.eventid;
		var startDt =request.query.startDT;
		var endDt = request.query.endDT;
		var wildcard = request.query.wildcard;
		if(uid == '*')
		{
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
				  size : '0',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					_source : [ 'logtimestamp', 'body'],
					aggs : {
						corrid_agg : {
							terms : {
								field : 'ocicchannelid',
								size : '1000',
								collect_mode : 'breadth_first'
							}
						}
					},
					query: {
						bool : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									}
									]
								}
							},
							must:{
							  term:{
								ociceventid: evntid
							  }
							}
						}
					}
				}
		  }).then(function (response) {
				  //console.log(response.hits.hits.length);
			if (response.hits.hits.length === 0) {
			  try {
				var keypair = {};
				keypair = response.aggregations.corrid_agg.buckets;
				if(keypair) 
				{	
				if (keypair.length > 0)
				{
					//console.log("searchinsearch" + keypair.length);
				  reply(searchInSearchChannel(keypair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				}
				else {
				  //console.log('EMpty else block');
				  reply('Empty');
				}
				}
			  }
			  catch (e) {
				//console.log(e);
			   //console.log('EMpty block');
				reply('Empty');
			  }
			}
			else {
			  var keyPair = {};
			  keyPair = response.aggregations.corrid_agg.buckets;
			  if (keyPair.length > 0) {
				 reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
					return res;
					}));
			  }
			else {
			  //At Times, results are empty while fetching correlationId
				reply(response);
			  }
			}
		  });
		} else if(evntid == '*'){
			if(wildcard == '') {
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
				  size : '0',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					_source : [ 'logtimestamp', 'body'],
					aggs : {
						corrid_agg : {
							terms : {
								field : 'ocicchannelid',
								size : '1000',
								collect_mode : 'breadth_first'
							}
						}
					},
					query: {
						bool : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									}
									]
								}
							},
							must:{
							  term:{
								ocicuserid: uid
							  }
							}
						}
					}
				}
		  }).then(function (response) {
			  //console.log(response.hits.hits.length);
        if (response.hits.hits.length === 0) {
          try {
            var keypair = {};
            keypair = response.aggregations.corrid_agg.buckets;
			if(keypair) 
			{	
            if (keypair.length > 0)
            {
				//console.log("searchinsearch" + keypair.length);
			  reply(searchInSearchChannel(keypair, startDt, endDt, request).then(function (res) {
				return res;
			  }));
            }
            else {
			  //console.log('EMpty else block');
              reply('Empty');
            }
			}
          }
          catch (e) {
            //console.log(e);
           //console.log('EMpty block');
            reply('Empty');
          }
        }
        else {
          var keyPair = {};
          keyPair = response.aggregations.corrid_agg.buckets;
          if (keyPair.length > 0) {
             reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
				return res;
				}));
          }
        else {
          //At Times, results are empty while fetching correlationId
            reply(response);
          }
        }
		  });
			} else {
				callWithRequest(request, 'search', {
				  index: request.query.searchIndex,
				  //type:'log_record',
				  body: {
					  size : '0',
						sort : [ {
							logtimestamp : {
								order : 'asc'
							}
						} ],
						_source : [ 'logtimestamp', 'body'],
						aggs : {
							corrid_agg : {
								terms : {
									field : 'ocicchannelid',
									size : '1000',
									collect_mode : 'breadth_first'
								}
							}
						},
						query: {
							bool : {
								filter : {
									bool : {
										must : [ {
											range : {
												logtimestamp : {
													gte : startDt,
													lte : endDt,
													format: 'epoch_millis',
												}
											}
										},
										{
											wildcard :{
												ocicuserid:uid
												}
										}										
										]
									}
								}						
							}
						}
					}
			  }).then(function (response) {
			  //console.log(response.hits.hits.length);
        if (response.hits.hits.length === 0) {
          try {
            var keypair = {};
            keypair = response.aggregations.corrid_agg.buckets;
			if(keypair) 
			{	
            if (keypair.length > 0)
            {
				//console.log("searchinsearch" + keypair.length);
			  reply(searchInSearchChannel(keypair, startDt, endDt, request).then(function (res) {
				return res;
			  }));
            }
            else {
			  //console.log('EMpty else block');
              reply('Empty');
            }
			}
          }
          catch (e) {
            //console.log(e);
           //console.log('EMpty block');
            reply('Empty');
          }
        }
        else {
          var keyPair = {};
          keyPair = response.aggregations.corrid_agg.buckets;
          if (keyPair.length > 0) {
             reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
				return res;
				}));
          }
        else {
          //At Times, results are empty while fetching correlationId
            reply(response);
          }
        }
			  });
			}
			
		} else {
			if(wildcard == '') {
				callWithRequest(request, 'search', {
				  index: request.query.searchIndex,
				  //type:'log_record',
				  body: {
					  size : '0',
						sort : [ {
							logtimestamp : {
								order : 'asc'
							}
						} ],
						_source : [ 'logtimestamp', 'body'],
						aggs : {
							corrid_agg : {
								terms : {
									field : 'ocicchannelid',
									size : '1000',
									collect_mode : 'breadth_first'
								}
							}
						},
						query: {
							bool : {
								filter : {
									bool : {
										must : [ 
										{
											range : {
												logtimestamp : {
													gte : startDt,
													lte : endDt,
													format: 'epoch_millis'
												}
											}
										},
										{ 	
											match_phrase: 
												{ 
													ocicuserid: uid 
												} 
										},
										{ 
											match_phrase: 
												{
													ociceventid: evntid 
												} 
										}
										]
									}
								}
							}
						}
					}
			  }).then(function (response) {
			  //console.log(response.hits.hits.length);
        if (response.hits.hits.length === 0) {
          try {
            var keypair = {};
            keypair = response.aggregations.corrid_agg.buckets;
			if(keypair) 
			{	
            if (keypair.length > 0)
            {
				//console.log("searchinsearch" + keypair.length);
			  reply(searchInSearchChannel(keypair, startDt, endDt, request).then(function (res) {
				return res;
			  }));
            }
            else {
			  //console.log('EMpty else block');
              reply('Empty');
            }
			}
          }
          catch (e) {
            //console.log(e);
           //console.log('EMpty block');
            reply('Empty');
          }
        }
        else {
          var keyPair = {};
          keyPair = response.aggregations.corrid_agg.buckets;
          if (keyPair.length > 0) {
             reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
				return res;
				}));
          }
        else {
          //At Times, results are empty while fetching correlationId
            reply(response);
          }
        }
			  });
			} else {
				callWithRequest(request, 'search', {
				  index: request.query.searchIndex,
				  //type:'log_record',
				  body: {
					  size : '0',
						sort : [ {
							logtimestamp : {
								order : 'asc'
							}
						} ],
						_source : [ 'logtimestamp', 'body'],
						aggs : {
							corrid_agg : {
								terms : {
									field : 'ocicchannelid',
									size : '1000',
									collect_mode : 'breadth_first'
								}
							}
						},
						query: {
							bool : {
								filter : {
									bool : {
										must : [ 
										{
											range : {
												logtimestamp : {
													gte : startDt,
													lte : endDt,
													format: 'epoch_millis'
												}
											}
										},
										{ 
											match_phrase: 
												{
													ociceventid: evntid 
												} 
										},
										{
											wildcard :{
												ocicuserid:uid
												}
										}
										]
									}
								}
							}
						}
					}
			  }).then(function (response) {
			  //console.log(response.hits.hits.length);
        if (response.hits.hits.length === 0) {
          try {
            var keypair = {};
            keypair = response.aggregations.corrid_agg.buckets;
			if(keypair) 
			{	
            if (keypair.length > 0)
            {
				//console.log("searchinsearch" + keypair.length);
			  reply(searchInSearchChannel(keypair, startDt, endDt, request).then(function (res) {
				return res;
			  }));
            }
            else {
			  //console.log('EMpty else block');
              reply('Empty');
            }
			}
          }
          catch (e) {
            //console.log(e);
           //console.log('EMpty block');
            reply('Empty');
          }
        }
        else {
          var keyPair = {};
          keyPair = response.aggregations.corrid_agg.buckets;
          if (keyPair.length > 0) {
             reply(searchInSearchChannel(keyPair, startDt, endDt, request).then(function (res) {
				return res;
				}));
          }
        else {
          //At Times, results are empty while fetching correlationId
            reply(response);
          }
        }
			  });
			}
		}
	}
	});
   server.route({
    method: 'GET',
    path: '/api/xsi_event/indices',
    handler: function (request, reply) {
	var chanId = request.query.chid;
	var subid = request.query.subid;
	var startDt =request.query.startDT;
	var endDt = request.query.endDT;
	var correlationID = request.query.corrId;
	var wildcard = request.query.wildcard;

	if( typeof correlationID == 'undefined') {
	
	  if(chanId == '*') {
		      callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			  //type:'log_record',
			  body: {
				  size : '0',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					_source : [ 'logtimestamp', 'body'],
					aggs : {
						corrid_agg : {
							terms : {
								field : 'correlationid',
								size : '1000',
								collect_mode : 'breadth_first'
							}
						}
					},
					query: {
						bool : {
							filter : {
								bool : {
									must : [ 
									{
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis'
											}
										}
									}
									]
								}
							},
							must:{
							  match:{
								ocicsubscriptionid: subid
							  }
							}
						}
					}
				}
		  }).then(function (response) {
			//console.log(response.hits.hits.length);
			if (response.hits.hits.length === 0) {
			  try {
				var keypair = {};
				keypair = response.aggregations.corrid_agg.buckets;
				if(keypair) 
				{	
				if (keypair.length > 0)
				{
					//console.log("searchinsearch" + keypair.length);
				  reply(searchInSearch(keypair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				}
				else {
				  //console.log('EMpty else block');
				  reply('Empty');
				}
				}
			  }
			  catch (e) {
				//console.log(e);
			   //console.log('EMpty block');
				reply('Empty');
			  }
			}
			else {
			  var keyPair = {};
			  keyPair = response.aggregations.corrid_agg.buckets;
			  if (keyPair.length > 0) {
				 reply(searchInSearch(keyPair, startDt, endDt, request).then(function (res) {
					return res;
					}));
			  }
			else {
			  //At Times, results are empty while fetching correlationId
				reply(response);
			  }
			}

			});
	  }	else if(subid == '*') {
			callWithRequest(request, 'search', {
			  index: request.query.searchIndex,
			 // type:'log_record',
			  body: {
				  size : '0',
					sort : [ {
						logtimestamp : {
							order : 'asc'
						}
					} ],
					_source : [ 'logtimestamp', 'body'],
					aggs : {
						corrid_agg : {
							terms : {
								field : 'correlationid',
								size : '1000',
								collect_mode : 'breadth_first'
							}
						}
					},
					query: {
						bool : {
							filter : {
								bool : {
									must : [ {
										range : {
											logtimestamp : {
												gte : startDt,
												lte : endDt,
												format: 'epoch_millis',
											}
										}
									}
									]
								}
							},
							must:{
							  match:{
								ocicchannelid: chanId
							  }
							}							
						}
					}
				}
		  }).then(function (response) {
			//console.log(response.hits.hits.length);
			if (response.hits.hits.length === 0) {
			  try {
				var keypair = {};
				keypair = response.aggregations.corrid_agg.buckets;
				if(keypair) 
				{	
				if (keypair.length > 0)
				{
					//console.log("searchinsearch" + keypair.length);
				  reply(searchInSearch(keypair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				}
				else {
				  //console.log('EMpty else block');
				  reply('Empty');
				}
				}
			  }
			  catch (e) {
				//console.log(e);
			   //console.log('EMpty block');
				reply('Empty');
			  }
			}
			else {
			  var keyPair = {};
			  keyPair = response.aggregations.corrid_agg.buckets;
			  if (keyPair.length > 0) {
				 reply(searchInSearch(keyPair, startDt, endDt, request).then(function (res) {
					return res;
					}));
			  }
			else {
			  //At Times, results are empty while fetching correlationId
				reply(response);
			  }
			}
		  });
	  } else {
      callWithRequest(request, 'search', {
		  index: request.query.searchIndex,
		  //type:'log_record',
		  body: {
			  size : '0',
				sort : [ {
					logtimestamp : {
						order : 'asc'
					}
				} ],
				_source : [ 'logtimestamp', 'body'],
				aggs : {
					corrid_agg : {
						terms : {
							field : 'correlationid',
							size : '1000',
							collect_mode : 'breadth_first'
						}
					}
				},
				query: {
					bool : {
						filter : {
							bool : {
								must : [ {
									range : {
										logtimestamp : {
											gte : startDt,
											lte : endDt,
											format: 'epoch_millis'
										}
									}
								},
									{ 	
										match_phrase: 
											{ 
												ocicsubscriptionid: subid 
											} 
									},
									{ 
										match_phrase: 
											{
												ocicchannelid: chanId 
											} 
									}
								]
							}
						}		
					}
				}
			}
      }).then(function (response) {
			//console.log(response.hits.hits.length);
			if (response.hits.hits.length === 0) {
			  try {
				var keypair = {};
				keypair = response.aggregations.corrid_agg.buckets;
				if(keypair) 
				{	
				if (keypair.length > 0)
				{
					//console.log("searchinsearch" + keypair.length);
				  reply(searchInSearch(keypair, startDt, endDt, request).then(function (res) {
					return res;
				  }));
				}
				else {
				  //console.log('EMpty else block');
				  reply('Empty');
				}
				}
			  }
			  catch (e) {
				//console.log(e);
			   //console.log('EMpty block');
				reply('Empty');
			  }
			}
			else {
			  var keyPair = {};
			  keyPair = response.aggregations.corrid_agg.buckets;
			  if (keyPair.length > 0) {
				 reply(searchInSearch(keyPair, startDt, endDt, request).then(function (res) {
					return res;
					}));
			  }
			else {
			  //At Times, results are empty while fetching correlationId
				reply(response);
			  }
			}
      });
	  }
	} else {
			  callWithRequest(request, 'search', {
				  index: request.query.searchIndex,
				  //type:'log_record',
				  body: {
						size : '1000',
						sort : [ {
							logtimestamp : {
								order : 'asc'
							}
						} ],
						query : {
							bool : {
								must : {
									term : {
										correlationid: correlationID,
									}
								}
							}
						}
					}
			  }).then(function (response) {
					var myArr = response.hits.hits;
						reply(
							response
						);
		  });

	}
	}
});

  var searchInSearchChannel = function (chIdArray, startTime, endTime, req) {
    var chidLength = chIdArray.length;
    var finalResult = [];
    var queryBody = [];
    var sample = {};
    if (chidLength < 1) {
      return;
    }
    else {
      for (var x = 0; x < chidLength; x++) {
        queryBody.push('{"index": "bwlog*"}');
        var query = { size:1 ,query: {
          bool:{
            must:{
              term:{
                ocicchannelid: chIdArray[x].key
              }
            },
			filter:{
            bool:{
              must:[
                {
                  range:{
                    logtimestamp:{
                      gte:startTime,
                      lte:endTime,
                      format:'epoch_millis'
                    }
                  }
                }
              ]
            }
          }
          }},
    sort:[
      {
        logtimestamp:{
          order:'asc'
        }
      }
    ]
};
        queryBody.push(query);
      }
      return callWithRequest(req,'msearch', {
        'requestTimeout' : 60000,
        body : queryBody
      }).then(function (response) {
		  var myArr;
		  if(response)
		  {
        myArr = response.responses;
		        return myArr;
		  }
		return response;
      });
    }
  };

  var searchInSearch = function (corrIdArray, startTime, endTime, req) {
    var corridLength = corrIdArray.length;
    var finalResult = [];
    var queryBody = [];
    var sample = {};
    if (corridLength < 1) {
      return;
    }
    else {
      for (var x = 0; x < corridLength; x++) {
        queryBody.push('{"index": "bwlog*, bwlog*xsievent*"}');
        var query = { size:1 ,query: {
          bool:{
            must:{
              term:{
                correlationid: corrIdArray[x].key
              }
            },
			filter:{
            bool:{
              must:[
                {
                  range:{
                    logtimestamp:{
                      gte:startTime,
                      lte:endTime,
                      format:'epoch_millis'
                    }
                  }
                }
              ]
            }
          }
          }},
    sort:[
      {
        logtimestamp:{
          order:'asc'
        }
      }
    ]
};
        queryBody.push(query);
      }
      return callWithRequest(req,'msearch', {
        'requestTimeout' : 60000,
        body : queryBody
      }).then(function (response) {
        var myArr = response.responses;
        return myArr;
      });
    }
  };
 
  };



