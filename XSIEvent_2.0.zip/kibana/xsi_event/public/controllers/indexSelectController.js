import uiModules from 'ui/modules';
uiModules
.get('app/xsi_event', ['720kb.tooltips','ngDialog','angularUtils.directives.dirPagination','ngCookies',
 'ui.bootstrap.contextMenu'])
.controller('indexSelectController', function ($scope, $route, $interval, $http, $sce,  $filter, $cookies, ngDialog) {

  $scope.fetchIndexPattern = function () {
    $scope.displayInfo = '';
    $scope.progress = 'true';
    $http.get('../api/xsi_event/selectTribeIndexPattern').then((response) => {
      $scope.index = response.data.hits.hits;
      //console.log($scope.index);
    }, function errorCallback(response) {
      console.log('ERROR2');
      $scope.progress = 'false';
      $scope.openErrorAlert('ERROR :( - Could not Access Server');
    });
  };
  $scope.fetchIndexPattern();

  /**
   * [globalSetting Apply the setting globalCookie]
   * @return {[void]} [creates new cookie when setting is applied]
   */
  $scope.setIndexName = function (Data) {
    console.log(Data);
    $cookies.put('globalConfiguration', JSON.stringify(Data));
  };

  // Could not able to index data
});
