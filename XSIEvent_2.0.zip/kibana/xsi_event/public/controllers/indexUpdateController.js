import uiModules from 'ui/modules';
uiModules
.get('app/xsi_event', ['720kb.tooltips','ngDialog','angularUtils.directives.dirPagination','ngCookies',
 'ui.bootstrap.contextMenu'])
.controller('indexUpdateController', function ($scope, $route, $interval, $http, $sce,  $filter, $cookies, ngDialog) {

  $scope.fetchIndexPattern = function () {
    $scope.displayInfo = '';
    $scope.progress = 'true';
    $http.get('../api/xsi_event/selectTribeIndexPattern').then((response) => {
      $scope.updateIndexPattern = response.data.hits.hits;
    }, function errorCallback(response) {
      console.log('ERROR3');
      $scope.progress = 'false';
      $scope.openErrorAlert('ERROR :( - Could not Access Server');
    });
  };
  $scope.fetchIndexPattern();

  $scope.peformUpdate = function (ID, newPattern) {
    console.log(document);
    console.log(newPattern);
    $http.get('../api/xsi_event/updateTribeIndexPattern' , {
      params: {
        documentID: ID,
        updatedPattern: newPattern
      }
    }).then((response) => {
    }, function errorCallback(response) {
      console.log('ERROR');
      $scope.progress = 'false';
      $scope.openErrorAlert('ERROR :( - Could not Access Server');
    });
  };


});
