import uiModules from 'ui/modules';
uiModules
.get('app/xsi_event', ['720kb.tooltips','ngDialog','angularUtils.directives.dirPagination','ngCookies',
 'ui.bootstrap.contextMenu'])
.controller('indexRemoveController', function ($scope, $route, $interval, $http, $sce,  $filter, $cookies, ngDialog) {

  $scope.fetchIndexPattern = function () {
    $scope.displayInfo = '';
    $scope.progress = 'true';
    $http.get('../api/xsi_event/selectTribeIndexPattern').then((response) => {
      $scope.indexRemove = response.data.hits.hits;}
      //console.log($scope.indexRemove)ck(response)
       , function errorCallback(response) {
      console.log('ERROR1');
      $scope.progress = 'false';
      $scope.openErrorAlert('ERROR :( - Could not Access Server');
    });
  };
  $scope.fetchIndexPattern();

  $scope.removeIndexPattern = function (ID) {
    $scope.displayInfo = '';
    $scope.progress = 'true';
    $http.get('../api/xsi_event/removeIndexPattern',{
      params:{
        documentID: ID._id,
      }
    }).then((response) => {
      $scope.openModalBox('Index is Updating');
      setTimeout(function () {  $scope.fetchIndexPattern(); }, 2000);
      //$scope.fetchIndexPattern();
    }, function errorCallback(response) {
      console.log('ERROR');
      $scope.progress = 'false';
      $scope.openErrorAlert('ERROR :( - Could not Access Server');
    });
  };

  // Could not able to index data
});
