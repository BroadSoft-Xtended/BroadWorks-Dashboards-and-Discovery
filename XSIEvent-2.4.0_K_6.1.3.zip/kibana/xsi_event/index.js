import exampleRoute from './server/routes/example';

export default function (kibana) {

  var mainFile = 'plugins/xsi_event';

  /* Below Lines are included to avoid the autoload Issue while loading kibana */
  var ownDescriptor = Object.getOwnPropertyDescriptor(kibana, 'autoload');
  var protoDescriptor = Object.getOwnPropertyDescriptor(kibana.constructor.prototype, 'autoload');
  var descriptor = ownDescriptor || protoDescriptor || {};



  // the autoload list has been replaced with a getter that complains about
  // improper access, bypass that getter by seeing if it is defined
  if (descriptor.get) {
    mainFile = 'plugins/xsi_event/app_with_autoload';
  }
  return new kibana.Plugin({
	  id: 'xsi_event',
    require: ['elasticsearch'],

    uiExports: {
      app: {
        title: 'XSI Events',
        description: 'XSI Event Log Utility',
        main: mainFile,
		icon: 'plugins/xsi_event/logo-scaled.png',
		injectVars: function (server, options) {
         var config = server.config();
         return {
             kbnIndex: config.get('kibana.index'),
             esShardTimeout: config.get('elasticsearch.shardTimeout'),
             esApiVersion: config.get('elasticsearch.apiVersion')
         };
       }
      }
    },

    config(Joi) {
      return Joi.object({
        enabled: Joi.boolean().default(true),
      }).default();
    },

    init(server, options) {
      // Add server routes and initalize the plugin here
      exampleRoute(server);
    }

  });
};
