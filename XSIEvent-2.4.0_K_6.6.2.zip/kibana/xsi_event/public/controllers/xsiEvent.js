import { uiModules } from "ui/modules";
var angular = require('angular');
var $ = require('jquery');

uiModules
.get('app/xsi_event', ['720kb.tooltips','ngDialog','ngCookies'])
.controller('xsiEvent', function ($scope, $http, $routeParams, $filter, $sce, $route, $interval, $window, ngDialog, $cookies) {

    $scope.version = "Version 2.4.0";
	$scope.appname = "XSI Event Log Utility";
	$scope.relativeCombo = "5 min";
	var isAbsolute = false;
	var startDt = "";
	var endDt = "";
	$scope.showAb = true;
	$scope.showRe = false;
	$scope.showCS = true;
	$scope.showUE = false;
	$scope.showUEID = false;
	$scope.showCID = false;
	$scope.showCor = false;
	$scope.showChannelList = false;
	$scope.showLog = false;
	$scope.myHTML = "";
	$scope.output = "";
	$scope.userID = "elongmiller@broadsoft.com";
	$scope.event = "CallSubscriptionEvent";
	$scope.eventid = "*";
	$scope.chID = "879bf7b0-9375-4220-b582-6f33fb45dea0";
	$scope.subID = "c2cd1b54-43d0-4663-b187-e28ad6719434";
	$scope.InitTime = '08/29/2016 06:00 AM';
	$scope.CurrentTime =  $filter('date')(new Date(), 'MM/dd/yyyy hh:mm a');
	$scope.correlationID = "LIST OF CORRELATION IDS";
	$scope.jsonresponse = "LOGS";

	$scope.showTwoPane = false;
	$scope.showThreePane = false;
	$scope.showForAbsolute = false;
	var userID = "";
	var evntName = "";
	var exp1 = /(&lt;xsi:channelId&gt;.*&lt;\/xsi:channelId&gt;)/g;
	var exp2 = /(&lt;xsi:subscriptionId&gt;.*&lt;\/xsi:subscriptionId&gt;)/g;
	var exp3 = /(&lt;xsi1:type="&gt;.*&lt;\/"&gt;)/g;
	$scope.fullScreenMode = false;

	var xsiLogName = "";
	var logContent = "";
	$scope.isClickAllowed = false;
	var chsubcall = false;
	var isie11 = false;
	var msie = document.documentMode;

	$( function() {
		$( '#datetimepicker3' ).datetimepicker({allowInputToggle: true});
		$( '#datetimepicker4' ).datetimepicker({allowInputToggle: true});
	} );
	  /**
   * [fetchGlobalInfo Read the value from the cookie stored]
   * @return {[void]} [description]
   */
  $scope.fetchGlobalInfo = function () {
    var globalCookie = $cookies.get('globalConfiguration');
    if (globalCookie) {
      $scope.test = globalCookie;
      var json = JSON.parse(globalCookie);
      console.log('Custom Settings Applied');
      console.log(json);
      if (json.sort === 'Ascending') {
        $scope.sortPreference = 'asc';
      }
      else if (json.sort === 'Descending') {
        $scope.sortPreference = 'desc';
      }
      if (json.index)
      {
        $scope.searchIndex = json.index;
      }
      $scope.sampleSize  = json.size;
    }
    else {
      console.log('Default Settings is Applied');
      $scope.searchIndex = 'bwlog*';
      $scope.sortPreference = 'asc';
      $scope.sampleSize  = '1000';
    }
  };
  $scope.fetchGlobalInfo();
	// if is IE (documentMode contains IE version)
	if (msie) {
	  // IE logic here

	  if (msie === 11) {
		// IE 11 logic here
		isie11 = true;
	  }
	}

	function onItemSelect(property) {
		console.log('select > ' + property.label);

	}

	function onItemDeselect(property) {
		console.log('deselect : ' + property.label);
	}

	function onSelectAll() {
		console.log('select all');
	}

	function onDeselectAll() {
		console.log('deselect all');
	}
	// set other one as *
	if($routeParams.userID) {
		$scope.userID = $routeParams.userID;
		$scope.event = '*';
		$scope.showCS = false;
		$scope.showUE = true;
		$scope.showUEID = false;
		isAbsolute = true;
	}
	if($routeParams.eventID)
	{
		$scope.eventid = $routeParams.eventID;
		$scope.userID = '*';
		$scope.showCS = false;
		$scope.showUE = false;
		$scope.showUEID = true;
		isAbsolute = true;
	}
	if($routeParams.channelID)
	{
		$scope.chID = $routeParams.channelID;
		$scope.subID = '*';
		$scope.showCS = true;
		$scope.showUE = false;
		$scope.showUEID = false;
		isAbsolute = true;
	}
	if($routeParams.subscriptionID)
	{
		$scope.subID = $routeParams.subscriptionID;
		$scope.chID = '*';
		$scope.showCS = true;
		$scope.showUE = false;
		$scope.showUEID = false;
		isAbsolute = true;
	}
	if($routeParams.startDt)
	{
		//$scope.InitTime = new Date( $routeParams.startDt *1000).toLocaleString();
		$scope.InitTime = new Date( Math.floor($routeParams.startDt )).toLocaleString();
	}
	if($routeParams.endDt) {
		//$scope.CurrentTime = new Date( $routeParams.endDt *1000).toLocaleString();
		$scope.CurrentTime = new Date( Math.floor($routeParams.endDt) ).toLocaleString();
	}

	$scope.openModalBox = function (message) {
		ngDialog.open({ template: '<p>' + message + '</p>', plain: true });
	};

	//Converts the current time into epoch_millis format
	  var getCurrentTime = function () {
		var CurrentTime = $filter('date')(new Date(), 'MM/dd/yyyy hh:mm a');
		return (new Date(CurrentTime)).getTime();
	  };
	  var FromDate = function () {
			var UserFromDate = angular.element(startDate).val();
			return (new Date(UserFromDate)).getTime();
	 };

	  var ToDate = function () {
		var UserToDate = angular.element(endDate).val();
		return (new Date(UserToDate)).getTime();
	  };

	  var FromIEDate = function () {
			var UserFromDate = angular.element($('#startDate')).val();
			return (new Date(UserFromDate)).getTime();
	 };

	  var ToIEDate = function () {
		var UserToDate = angular.element($('#endDate')).val();
		return (new Date(UserToDate)).getTime();
	  };

	$scope.dispAb = function() {
		$scope.showAb = true;
		$scope.showRe = false;
	}
    $scope.dispRe = function() {
		$scope.showAb = false;
		$scope.showRe = true;
	  }
	$scope.dispUE = function() {
		$scope.showUE = true;
		$scope.showUEID = false;
		$scope.showCS = false;
		$scope.showCID = false;
	}
    $scope.dispCS = function() {
		$scope.showUE = false;
		$scope.showUEID = false;
		$scope.showCID = false;
		$scope.showCS = true;
	  }
	$scope.dispUEID = function() {
		$scope.showCID = false;
		$scope.showUE = false;
		$scope.showCS = false;
		$scope.showUEID = true;
	}
	$scope.dispCID = function() {
		$scope.showCID = true;
		$scope.showUE = false;
		$scope.showCS = false;
		$scope.showUEID = false;
	}
	$scope.reset = function() {
		$scope.InitTime = '08/29/2016 06:00 AM';
		$scope.CurrentTime =  $filter('date')(new Date(), 'MM/dd/yyyy hh:mm a');
		$scope.userID = "";
		$scope.event = "";
		$scope.eventid = "";
		$scope.chID = "";
		$scope.subID = "";
		$scope.showCor = false;
		$scope.showChannelList = false;
		$scope.showLog = false;
		$scope.showLogs = false;
		$scope.myHTML = "";
		$scope.output = "";
		
		$scope.correID = "";
		$scope.progress = 'false';
		$scope.progressId = 'false';
	}
	if(isAbsolute) {
		$scope.jsonresponse = "LOGS";
		$scope.showLogs = false;
		$scope.showCorForAbsolute = false;
		$scope.showChForAbsolute = false;
		$scope.showChannelList = false;
		$scope.showCor = false;
		$scope.showLog = false;
		$scope.myHTML = "";
		$scope.output = "";
		startDt = "";
		endDt = "";

	  	if ($scope.showRe && $scope.relativeCombo != "")
		{
			var relativeTime;
			var currentTime = getCurrentTime();
			if ($scope.relativeCombo == "5 min")
			{
			  relativeTime = (currentTime - (300 * 1000));
			}
			else if ($scope.relativeCombo == "10 min") {
			  relativeTime = (currentTime - (600 * 1000));
			}
			else if ($scope.relativeCombo == "15 min") {
			  relativeTime = (currentTime - (900 * 1000));
			}
			else if ($scope.relativeCombo == "1 hour") {
			  relativeTime = (currentTime - (3600 * 1000));
			}
			else if ($scope.relativeCombo == "2 hours") {
			  relativeTime = (currentTime - (7200 * 1000));
			}
			else if ($scope.relativeCombo == "5 hours") {
			  relativeTime = (currentTime - (18000 * 1000));
			}
			else if ($scope.relativeCombo == "8 hours") {
			  relativeTime = (currentTime - (28800 * 1000));
			}
			else if ($scope.relativeCombo == "1 day") {
			  relativeTime = (currentTime - (86400 * 1000));
			}
			else if ($scope.relativeCombo == "2 days") {
			  relativeTime = (currentTime - (172800 * 1000));
			}
			else if ($scope.relativeCombo == "1 week") {
			  relativeTime = (currentTime - (604800 * 1000));
			}
			startDt =  relativeTime;
			endDt = getCurrentTime();
		} else {
			if($routeParams.startDt)
			{
				startDt = $routeParams.startDt;
			}
			else
			startDt = new Date($scope.InitTime).getTime();
			if($routeParams.endDt) {
				endDt = $routeParams.endDt;
			}
			else
			endDt = new Date($scope.CurrentTime).getTime();
		}

		if(isNaN(startDt)) {
			$scope.openModalBox('Start Date is missing!!!');
			return;
		}
		if(isNaN(endDt)) {
			$scope.openModalBox('End Date is missing!!!');
			return;
		}
		if($scope.showUE) {
			$scope.isClickAllowed = false;
			if($scope.uiderr) $scope.uiderr = false;
			if($scope.evnameerr) $scope.evnameerr  = false;
			if($scope.userID == null || $scope.userID == 'undefined' || $scope.userID == "") {
				$scope.uiderr = true;
				return;
			}
			if($scope.event == null || $scope.event == 'undefined' || $scope.event == "") {
				if($scope.uiderr) $scope.uiderr = false;
				$scope.evnameerr = true;
				return;
			}
			if($scope.evnameerr) $scope.evnameerr  = false;
			if($scope.userID == "*" && $scope.event == "*")
			{
				$scope.openModalBox('Both UserID and Event cannot be * !!!');
				return;
			}
		}
		if($scope.showUEID) {
			$scope.isClickAllowed = false;
			if($scope.uiderr) $scope.uiderr = false;
			if($scope.eviderr) $scope.eviderr  = false;
			if($scope.userID == null || $scope.userID == 'undefined' || $scope.userID == "") {
				$scope.uiderr = true;
				return;
			}
			if($scope.eventid == null || $scope.eventid == 'undefined' || $scope.eventid == "") {
				if($scope.uiderr) $scope.uiderr = false;
				$scope.eviderr = true;
				return;
			}
			if($scope.eviderr) $scope.eviderr  = false;
			if($scope.userID == "*" && $scope.eventid == "*")
			{
				$scope.openModalBox('Both UserID and Event cannot be * !!!');
				return;
			}
		}
		if($scope.showCS) {
			$scope.isClickAllowed = false;
			if($scope.chiderr) $scope.chiderr = false;
			if($scope.subiderr) $scope.subiderr  = false;
			if($scope.chID == null || $scope.chID == 'undefined' || $scope.chID == "") {
				$scope.chiderr = true;
				return;
			}
			if($scope.subID == null || $scope.subID == 'undefined' || $scope.subID == "") {
				if($scope.chiderr) $scope.chiderr = false;
				$scope.subiderr = true;
				return;
			}
			if($scope.subiderr) $scope.subiderr  = false;
			if($scope.chID == "*" && $scope.subID == "*")
			{
				$scope.openModalBox('Both Channel ID and Subscription ID cannot be * !!!');
				return;
			}
		}
		if($scope.showCID) {
			$scope.isClickAllowed = false;
			if($scope.coiderr) $scope.coiderr  = false;
			if($scope.correID == null || $scope.correID == 'undefined' || $scope.correID == '') {
				$scope.coiderr = true;
				return;
			}
		}

		if($scope.showUE) {
			chsubcall = false;
			$scope.showCor = false;
			$scope.showChannelList = false;
			$scope.showCorForAbsolute = false;
			$scope.correlationID = "List of Channel IDs";
			
			$scope.showTwoPane = true;
			$scope.showThreePane = true;
			$scope.progress = 'true';
			$scope.showLogs = false;
			var UserID = userID = $scope.userID;
			var eventName = evntName = $scope.event;
			var wildcard = '';
			logContent = '';

			if((eventName != '*' && eventName.includes('*')) || (UserID != '*' && UserID.includes('*')))
			{
				wildcard = '*'
			}
			$http.get(`../api/xsi_event/uename`, {params:{searchIndex:$scope.searchIndex,userId:$scope.userID, event:$scope.event, startDT:startDt, endDT:endDt, wildcard:wildcard}}).then((response) => {
				var myArr = response.data;
			      if (myArr)
				  {
					try {
					  if (myArr.hits.hits.length == 0)
					  {
					  	$scope.progress = 'false';
						$scope.openModalBox('No Channel ID found !!!');
						$scope.isClickAllowed = false;
						$scope.showChForAbsolute = false;
						$scope.showLog = false;
						this.hits = null;
						return;
					  }
					} catch (e) {
						$scope.progress = 'false';
					  this.hits = response.data;

					}
				  }
				 $scope.progress = 'false';
				this.hits = response.data;
				$scope.showChForAbsolute = true;
			});
		}else if($scope.showUEID) {
			chsubcall = false;
			$scope.showCor = false;
			$scope.showChannelList = false;
			$scope.showCorForAbsolute = false;
			$scope.correlationID = "List of Channel IDs";
			
			$scope.showTwoPane = true;
			$scope.showThreePane = true;
			$scope.progress = 'true';
			$scope.showLogs = false;
			var UserID = userID = $scope.userID;
			logContent = '';

			var wildcard = '';

			if(UserID != '*' && UserID.includes('*'))
			{
				wildcard = '*';
			}
			$http.get(`../api/xsi_event/ueid`, {params:{searchIndex:$scope.searchIndex,userId:$scope.userID, eventid:$scope.eventid, startDT:startDt, endDT:endDt, wildcard:wildcard}}).then((response) => {
				var myArr = response.data;
			      if (myArr)
				  {
					try {
					  if (myArr.hits.hits.length == 0)
					  {
					  	$scope.progress = 'false';
						$scope.openModalBox('No Channel ID found');
						$scope.isClickAllowed = false;
						$scope.showChForAbsolute = false;
						$scope.showLog = false;
						this.hits = null;
						return;
					  }
					} catch (e) {
						$scope.progress = 'false';
					  this.hits = response.data;

					}
				  }
				$scope.progress = 'false';
				this.hits = response.data;
				$scope.showChForAbsolute = true;
			});
		} else if($scope.showCS) {
			chsubcall = true;
			$scope.correlationID = "LIST OF CORRELATION IDS";
			
			$scope.showTwoPane = true;
			$scope.showThreePane = true;
			$scope.progress = 'true';
			$scope.showLogs = false;
			$scope.showCor = false;
			$scope.showChannelList = false;
			$scope.showChForAbsolute = false;
			logContent = '';

			$http.get(`../api/xsi_event/indices`, {params:{searchIndex:$scope.searchIndex,chid:$scope.chID, subid:$scope.subID, startDT:startDt, endDT:endDt}}).then((response) => {
				var myArr = response.data;
				if (response.data === 'Empty')
				  {
					$scope.openModalBox('No Results Found');
					$scope.progress = 'false';
					$scope.showLog = false;
					return;
				  }
			      if (myArr)
				  {
					try {
					  if (myArr.hits.hits.length == 0)
					  {
					  	$scope.progress = 'false';
						$scope.openModalBox('No Correlation ID found !!!');
						$scope.isClickAllowed = false;
						$scope.showCorForAbsolute = false;
						$scope.showLog = false;
						this.hits = null;
						return;
					  }
					} catch (e) {
						$scope.progress = 'false';
					  this.hits = response.data;

					}
				  }
				 $scope.progress = 'false';
				this.hits = response.data;
				$scope.showCorForAbsolute = true;
			});
		} else {
			if($scope.showCID) {
				chsubcall = false;
				$scope.correlationID = "List of Channel IDs";
				
				$scope.showTwoPane = true;
				$scope.showThreePane = true;
				$scope.progress = 'true';
				$scope.showLogs = false;
				$scope.showCor = false;
				$scope.showChannelList = false;
				$scope.showCorForAbsolute = false;
				$scope.showLog = false;
				
				var myArr = '';
				$http.get(`../api/xsi_event/correlationid`, {params:{searchIndex:$scope.searchIndex,startDT:startDt, endDT:endDt, corrId:$scope.correID}}).then((response) => {
				if (response.data === 'Empty')
				  {
					$scope.openModalBox('No Results Found');
					$scope.progress = 'false';
					$scope.showLog = false;
					return;
				  }
					var myArr = response.data;
					  if (myArr)
					  {
						try {
						  if (myArr.hits.hits.length == 0)
						  {
							$scope.progress = 'false';
							$scope.openModalBox('No Channel ID found');
							$scope.isClickAllowed = false;
							$scope.showChForAbsolute = false;
							$scope.showLog = false;
							this.hits = null;
							return;
						  }
						} catch (e) {
							$scope.progress = 'false';
						  this.hits = response.data;

						}
					  }
					$scope.progress = 'false';
					this.hits = response.data;
					$scope.showChForAbsolute = true;
				});
			}
		}
		$scope.onclickof= function(index, currenttimestamp){

			logContent = '';
			$scope.showLog = true;
			$scope.progress = 'false';
			$scope.progressId = 'true';
			$http.get(`../api/xsi_event/indices`, {params:{searchIndex:$scope.searchIndex,startDT:startDt, endDT:endDt, corrId:index}}).then((response) => {

			  var myArr = response.data.hits.hits;
			  console.log(myArr);
			  if (myArr.length == 0)
			  {
			  $scope.showLog = false;
			  $scope.progressId = 'false';
			  $scope.openModalBox('No Logs found!!!');
				//alert('No Logs Found');
				$scope.isClickAllowed = false;
				$scope.showLog = false;
				return;
			  }
			  $scope.showLog = false;
			  var logMessage = '';
			  for (var i = 0; i < myArr.length; i++)
			  {
				var xx = htmlEntities(myArr[i]._source.source);
				var exp = /^(\d{4}\.\d{2}\.\d{2}\s+.*)\n/g;
				var y = xx.match(exp);
				xx = xx.replace(exp, '<div id="decorate">' + y[0] + '</div>');
				// to highlight channel id
				var y1 = xx.match(exp1);
				xx = xx.replace(exp1, '<strong>' + y1 + '</strong>');
				// to highlight subscription id
				var y2 = xx.match(exp2);
				xx = xx.replace(exp2, '<strong>' + y2 + '</strong>');
				// to highlight event name
				var y3 = xx.match(exp3);
				xx = xx.replace(exp3, '<strong>' + y3 + '</strong>');
				logMessage = logMessage.concat(xx);
			  }
			  for (var i = 0; i < myArr.length; i++)
			  {
				var xx = myArr[i]._source.source;
				logContent = logContent.concat(xx);
			  }
				$scope.showLog = true;
				$scope.progressId = 'false';
				$scope.jsonresponse = "Complete Log for Correlation ID: " + index + " ";
				$scope.myHTML = $sce.trustAsHtml(logMessage);
				$scope.isClickAllowed = true;
			});
			currenttimestamp = currenttimestamp.replace(/\s+/, "_");
			currenttimestamp = currenttimestamp.replace(/\s+/, "_");
			xsiLogName = 'xsilog_' + currenttimestamp +  '.log';
		}
		$scope.fetchLogForChannelID= function(index, currenttimestamp){

			logContent = '';
			$scope.showLog = true;
			$scope.progressId = 'true';
			$http.get(`../api/xsi_event/channelid`, {params:{searchIndex:$scope.searchIndex,startDT:startDt, endDT:endDt, chId:index}}).then((response) => {

			  var myArr = response.data.hits.hits;
			  console.log(myArr);
			  if (myArr.length == 0)
			  {
			    $scope.showLog = false;
			    $scope.progressId = 'false';
				//alert('No Logs Found');
				$scope.openModalBox('No Logs found !!!');
				$scope.isClickAllowed = false;
				$scope.showLog = false;
				return;
			  }
			  $scope.showLog = false;
			  var logMessage = '';
			  for (var i = 0; i < myArr.length; i++)
			  {
				var corrid = myArr[i]._source.correlationid;
				console.log("corrid" +corrid);
				$http.get(`../api/xsi_event/recommendedCorrId`, {params:{noTimeFrame:true,searchIndex:$scope.searchIndex,startDT:startDt, endDT:endDt, correlationID:corrid}}).then((response) => {
						var myArr = response.data.hits.hits;
						  console.log(myArr);
						  if (myArr.length == 0)
						  {
							$scope.showLog = false;
							$scope.progressId = 'false';
							$scope.openModalBox('No Logs found !!!');
							$scope.isClickAllowed = false;
							$scope.showLog = false;
							return;
						  }
						for (var i = 0; i < myArr.length; i++)
						{
							var xx = htmlEntities(myArr[i]._source.source);
							var exp = /^(\d{4}\.\d{2}\.\d{2}\s+.*)\n/g;
							var y = xx.match(exp);
							xx = xx.replace(exp, '<div id="decorate">' + y[0] + '</div>');
							// to highlight channel id
							var y1 = xx.match(exp1);
							xx = xx.replace(exp1, '<strong>' + y1 + '</strong>');
							// to highlight subscription id
							var y2 = xx.match(exp2);
							xx = xx.replace(exp2, '<strong>' + y2 + '</strong>');
							// to highlight event name
							var y3 = xx.match(exp3);
							xx = xx.replace(exp3, '<strong>' + y3 + '</strong>');
							logMessage = logMessage.concat(xx);
							$scope.showLog = true;
							$scope.progressId = 'false';
							$scope.jsonresponse = "Complete Log for Channel ID: " + index + " ";
							$scope.myHTML = $sce.trustAsHtml(logMessage);
							$scope.isClickAllowed = true;
						}
						for (var i = 0; i < myArr.length; i++)
						  {
							var xx = myArr[i]._source.source;
							logContent = logContent.concat(xx);
						  }
					});
			  }

			});
			currenttimestamp = currenttimestamp.replace(/\s+/, "_");
			currenttimestamp = currenttimestamp.replace(/\s+/, "_");
			xsiLogName = 'xsilog_' + currenttimestamp +  '.log';
		}
		$scope.download = function(){

			var element = document.createElement('a');

			if (navigator.msSaveBlob) {
			  navigator.msSaveBlob(new Blob([logContent], { type : 'text/plain;charset=utf-8;'
				}), xsiLogName);
			}
			else { // Chrome && FireFox
				element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(logContent));
				element.setAttribute('download', xsiLogName);
				if (document.createEvent) {
					var event = document.createEvent('MouseEvents');
					event.initEvent('click', true, true);
					element.dispatchEvent(event);
				}
				else {
					element.click();
				}
			}
		}
		function htmlEntities(str)
		{
			return String(str).replace(/</g, '&lt;').replace(/>/g, '&gt;');
		}
	  }

	  $scope.go = function() {
		$scope.isClickAllowed = false;
		isAbsolute = false;
		$scope.jsonresponse = "LOGS";
		$scope.showLogs = false;
		$scope.showCorForAbsolute = false;
		$scope.showChForAbsolute = false;
		$scope.showChannelList = false;
		$scope.showCor = false;
		$scope.showLog = false;
		$scope.myHTML = "";
		$scope.output = "";
		startDt = "";
		endDt = "";

		if ($scope.showRe && $scope.relativeCombo != "")
		{
			var relativeTime;
			var currentTime = getCurrentTime();
			if ($scope.relativeCombo == "5 min")
			{
			  relativeTime = (currentTime - (300 * 1000));
			}
			else if ($scope.relativeCombo == "10 min") {
			  relativeTime = (currentTime - (600 * 1000));
			}
			else if ($scope.relativeCombo == "15 min") {
			  relativeTime = (currentTime - (900 * 1000));
			}
			else if ($scope.relativeCombo == "1 hour") {
			  relativeTime = (currentTime - (3600 * 1000));
			}
			else if ($scope.relativeCombo == "2 hours") {
			  relativeTime = (currentTime - (7200 * 1000));
			}
			else if ($scope.relativeCombo == "5 hours") {
			  relativeTime = (currentTime - (18000 * 1000));
			}
			else if ($scope.relativeCombo == "8 hours") {
			  relativeTime = (currentTime - (28800 * 1000));
			}
			else if ($scope.relativeCombo == "1 day") {
			  relativeTime = (currentTime - (86400 * 1000));
			}
			else if ($scope.relativeCombo == "2 days") {
			  relativeTime = (currentTime - (172800 * 1000));
			}
			else if ($scope.relativeCombo == "1 week") {
			  relativeTime = (currentTime - (604800 * 1000));
			}
			startDt =  relativeTime;
			endDt = getCurrentTime();
		} else {
			if(isie11) {
				startDt = FromIEDate();
				endDt = ToIEDate();
			}
			else
			{
				startDt = FromDate();
				endDt = ToDate();
			}
		}
		if(isNaN(startDt)) {
			$scope.openModalBox('Start Date is missing !!!');
			return;
		}
		if(isNaN(endDt)) {
			$scope.openModalBox('End Date is missing!!!');
			return;
		}
		if($scope.showUE) {
		$scope.isClickAllowed = false;
			if($scope.uiderr) $scope.uiderr = false;
			if($scope.eviderr) $scope.eviderr  = false;
			if($scope.userID == null || $scope.userID == 'undefined' || $scope.userID == "") {
				$scope.uiderr = true;
				return;
			}
			if($scope.event == null || $scope.event == 'undefined' || $scope.event == "") {
				//alert("Subscription ID missing");
				if($scope.uiderr) $scope.uiderr = false;
				$scope.eviderr = true;
				return;
			}
			if($scope.eviderr) $scope.eviderr  = false;
			if($scope.userID == "*" && $scope.event == "*")
			{
				$scope.openModalBox('Both UserID and Event cannot be * !!!');
				return;
			}
		}
		if($scope.showUEID) {
			$scope.isClickAllowed = false;
			if($scope.uiderr) $scope.uiderr = false;
			if($scope.eviderr) $scope.eviderr  = false;
			if($scope.userID == null || $scope.userID == 'undefined' || $scope.userID == "") {
				$scope.uiderr = true;
				return;
			}
			if($scope.eventid == null || $scope.eventid == 'undefined' || $scope.eventid == "") {
				if($scope.uiderr) $scope.uiderr = false;
				$scope.eviderr = true;
				return;
			}
			if($scope.eviderr) $scope.eviderr  = false;
			if($scope.userID == "*" && $scope.eventid == "*")
			{
				$scope.openModalBox('Both UserID and Event cannot be * !!!');
				return;
			}
		}
		if($scope.showCS) {
		$scope.isClickAllowed = false;
			if($scope.chiderr) $scope.chiderr = false;
			if($scope.subiderr) $scope.subiderr  = false;
			if($scope.chID == null || $scope.chID == 'undefined' || $scope.chID == "") {
				$scope.chiderr = true;
				return;
			}
			if($scope.subID == null || $scope.subID == 'undefined' || $scope.subID == "") {
				//alert("Subscription ID missing");
				if($scope.chiderr) $scope.chiderr = false;
				$scope.subiderr = true;
				return;
			}
			if($scope.subiderr) $scope.subiderr  = false;
			if($scope.chID == "*" && $scope.subID == "*")
			{
				$scope.openModalBox('Both Channel ID and Subscription ID cannot be * !!!');
				return;
			}
		}
		if($scope.showCID) {
		$scope.isClickAllowed = false;
			if($scope.coiderr) $scope.coiderr  = false;
			if($scope.correID == null || $scope.correID == 'undefined' || $scope.correID == '') {
				$scope.coiderr = true;
				return;
			}
		}
		if($scope.showUE) {
			chsubcall = false;
			$scope.showCor = false;
			$scope.correlationID = "List of Channel IDs";
			
			$scope.showTwoPane = true;
			$scope.showThreePane = true;
			$scope.progress = 'true';
			$scope.showLogs = false;
			var UserID = userID = $scope.userID;
			var eventName = evntName = $scope.event;
			var wildcard = '';
			logContent = '';

			if((eventName != '*' && eventName.includes('*')) || (UserID != '*' && UserID.includes('*')))
			{
				wildcard = '*'
			}
			$http.get(`../api/xsi_event/uename`, {params:{searchIndex:$scope.searchIndex,userId:$scope.userID, event:$scope.event, startDT:startDt, endDT:endDt, wildcard:wildcard}}).then((response) => {
				var myArr = response.data;
				//console.log(myArr.hits);
				if (response.data === 'Empty')
				  {
					$scope.openModalBox('No Results Found');
					$scope.progress = 'false';
					$scope.showLog = false;
					return;
				  }
			      if (myArr)
				  {
					try {
					  if (myArr.hits.hits.length == 0)
					  {
					  	$scope.progress = 'false';
						$scope.openModalBox('No Results Found');
						$scope.isClickAllowed = false;
						$scope.showChannelList = false;
						$scope.showLog = false;
						this.hits = null;
						return;
					  }
					} catch (e) {
						$scope.progress = 'false';
					  this.hits = response.data;

					}
				  }
				  $scope.progress = 'false';
				this.hits = response.data;
				$scope.showChannelList = true;
			});
		}else if($scope.showUEID) {
			chsubcall = false;
			$scope.showCor = false;
			$scope.correlationID = "List of Channel IDs";
			
			$scope.showTwoPane = true;
			$scope.showThreePane = true;
			$scope.progress = 'true';
			$scope.showLogs = false;
			var UserID = userID = $scope.userID;
			logContent = '';

			var wildcard = '';

			if(UserID != '*' && UserID.includes('*'))
			{
				wildcard = '*';
			}

			$http.get(`../api/xsi_event/ueid`, {params:{searchIndex:$scope.searchIndex,userId:$scope.userID, eventid:$scope.eventid, startDT:startDt, endDT:endDt, wildcard:wildcard}}).then((response) => {
				var myArr = response.data;
				  if (response.data === 'Empty')
				  {
					$scope.openModalBox('No Results Found');
					$scope.progress = 'false';
					$scope.showLog = false;
					return;
				  }
			      if (myArr)
				  {
					try {
					  if (myArr.hits.hits.length == 0)
					  {
					  	$scope.progress = 'false';
						$scope.openModalBox('No Results Found');
						$scope.isClickAllowed = false;
						$scope.showChannelList = false;
						$scope.showLog = false;
						this.hits = null;
						return;
					  }
					} catch (e) {
						$scope.progress = 'false';
					  this.hits = response.data;

					}
				  }
				  $scope.progress = 'false';
				this.hits = response.data;
				$scope.showChannelList = true;
			});
		} else if($scope.showCS) {
			chsubcall = true;
			$scope.correlationID = "LIST OF CORRELATION IDS";
			
			$scope.showTwoPane = true;
			$scope.showThreePane = true;
			$scope.progress = 'true';
			$scope.showLogs = false;
			$scope.showChannelList = false;
			logContent = '';

			$http.get(`../api/xsi_event/indices`, {params:{searchIndex:$scope.searchIndex,chid:$scope.chID, subid:$scope.subID, startDT:startDt, endDT:endDt}}).then((response) => {
				var myArr = response.data;
				if (response.data === 'Empty')
				  {
					$scope.openModalBox('No Results Found');
					$scope.progress = 'false';
					$scope.showLog = false;
					return;
				  }
			      if (myArr)
				  {
					try {
					  if (myArr.hits.hits.length == 0)
					  {
					  	$scope.progress = 'false';
						$scope.openModalBox('No Correlation ID found !!!');
						$scope.isClickAllowed = false;
						$scope.showCor = false;
						$scope.showLog = false;
						this.hits = null;
						return;
					  }
					} catch (e) {
						$scope.progress = 'false';
					  this.hits = response.data;

					}
				  }
				  $scope.progress = 'false';
				this.hits = response.data;
				$scope.showCor = true;
			});
		} else {
			if($scope.showCID) {
				chsubcall = false;
				$scope.correlationID = "List of Channel IDs";
				
				$scope.showTwoPane = true;
				$scope.showThreePane = true;
				$scope.progress = 'true';
				$scope.showLogs = false;
				$scope.showCor = false;
				$scope.showLog = false;
				
				var myArr = '';
				$http.get(`../api/xsi_event/correlationid`, {params:{searchIndex:$scope.searchIndex,startDT:startDt, endDT:endDt, corrId:$scope.correID}}).then((response) => {
					var myArr = response.data;
					if (response.data === 'Empty')
					  {
						$scope.openModalBox('No Results Found');
						$scope.progress = 'false';
						$scope.showLog = false;
						return;
					  }
					  if (myArr)
					  {
						try {
						  if (myArr.hits.hits.length == 0)
						  {
							$scope.progress = 'false';
							$scope.openModalBox('No Channel ID found');
							$scope.isClickAllowed = false;
							$scope.showChannelList = false;
							$scope.showLog = false;
							this.hits = null;
							return;
						  }
						} catch (e) {
							$scope.progress = 'false';
						  this.hits = response.data;

						}
					  }
					  $scope.progress = 'false';
					this.hits = response.data;
					$scope.showChannelList = true;
				});
			}
		}
		$scope.onclickof= function(index, currenttimestamp){
			$scope.myHTML = "";
			$scope.correlationid = index;
			logContent = '';
			$scope.showLog = true;
			$scope.progressId = 'true';
			$http.get(`../api/xsi_event/indices`, {params:{searchIndex:$scope.searchIndex,startDT:startDt, endDT:endDt, corrId:index}}).then((response) => {

			if (response.data === 'Empty')
			  {
				$scope.openModalBox('No Results Found');
				$scope.progress = 'false';
				$scope.showLog = false;
				return;
			  }
			  var myArr = response.data.hits.hits;
			  
			  console.log(myArr);
			  if (myArr.length == 0)
			  {
			  $scope.showLog = false;
			  $scope.progressId = 'false';
				$scope.openModalBox('No Logs found !!!');
				$scope.isClickAllowed = false;
				$scope.showLog = false;
				return;
			  }
			  $scope.showLog = false;
			  $scope.progressId = 'false';
			  var logMessage = '';
			  for (var i = 0; i < myArr.length; i++)
			  {
				var xx = htmlEntities(myArr[i]._source.source);
				var exp = /^(\d{4}\.\d{2}\.\d{2}\s+.*)\n/g;
				var y = xx.match(exp);
				xx = xx.replace(exp, '<div id="decorate">' + y[0] + '</div>');
				// to highlight channel id
				var y1 = xx.match(exp1);
				//alert(y1);
				xx = xx.replace(exp1, '<strong>' + y1 + '</strong>');
				// to highlight subscription id
				var y2 = xx.match(exp2);
				xx = xx.replace(exp2, '<strong>' + y2 + '</strong>');
				// to highlight event name
				var y3 = xx.match(exp3);
				xx = xx.replace(exp3, '<strong>' + y3 + '</strong>');
				logMessage = logMessage.concat(xx);
			  }
			  for (var i = 0; i < myArr.length; i++)
			  {
				var xx = myArr[i]._source.source;
				logContent = logContent.concat(xx);
			  }
				$scope.showLog = true;
				$scope.progressId = 'false';
				$scope.jsonresponse = "Complete Log for Correlation ID: " + index + " ";

				$scope.myHTML = $sce.trustAsHtml(logMessage);
				$scope.isClickAllowed = true;
			});
			currenttimestamp = currenttimestamp.replace(/\s+/, "_");
			currenttimestamp = currenttimestamp.replace(/\s+/, "_");
			xsiLogName = 'xsilog_' + currenttimestamp +  '.log';

		}
		$scope.fetchLogForChannelID= function(index, currenttimestamp){
			$scope.myHTML = "";
			$scope.isClickAllowed = false;
			logContent = '';
			$scope.showLog = true;
			$scope.progressId = 'true';
			$http.get(`../api/xsi_event/channelid`, {params:{searchIndex:$scope.searchIndex,startDT:startDt, endDT:endDt, chId:index}}).then((response) => {
				if (response.data === 'Empty')
				  {
					$scope.openModalBox('No Results Found');
					$scope.progress = 'false';
					$scope.showLog = false;
					return;
				  }
			  var myArr = response.data.hits.hits;
			  console.log(myArr);
			  if (myArr.length == 0)
			  {
			  $scope.showLog = false;
			  $scope.progressId = 'false';
				//alert('No Logs Found');
				$scope.openModalBox('No Logs found !!!');
				$scope.isClickAllowed = false;
				$scope.showLog = false;
				return;
			  }
			  $scope.showLog = false;
			 $scope.progressId = 'false';
			  var logMessage = '';
			  for (var i = 0; i < myArr.length; i++)
			  {
				var corrid = myArr[i]._source.correlationid;
				console.log("corrid" +corrid);
				$http.get(`../api/xsi_event/recommendedCorrId`, {params:{noTimeFrame:true,searchIndex:$scope.searchIndex,startDT:startDt, endDT:endDt, correlationID:corrid}}).then((response) => {
						var myArr = response.data.hits.hits;
						  console.log(myArr);
						  if (myArr.length == 0)
						  {
							$scope.showLog = false;
							$scope.progressId = 'false';
							$scope.openModalBox('No Logs found !!!');
							$scope.isClickAllowed = false;
							$scope.showLog = false;
							return;
						  }
						for (var i = 0; i < myArr.length; i++)
						{
							var xx = htmlEntities(myArr[i]._source.source);
							var exp = /^(\d{4}\.\d{2}\.\d{2}\s+.*)\n/g;
							var y = xx.match(exp);
							xx = xx.replace(exp, '<div id="decorate">' + y[0] + '</div>');
							// to highlight channel id
							var y1 = xx.match(exp1);
							xx = xx.replace(exp1, '<strong>' + y1 + '</strong>');
							// to highlight subscription id
							var y2 = xx.match(exp2);
							xx = xx.replace(exp2, '<strong>' + y2 + '</strong>');
							// to highlight event name
							var y3 = xx.match(exp3);
							xx = xx.replace(exp3, '<strong>' + y3 + '</strong>');
							logMessage = logMessage.concat(xx);
							$scope.showLog = true;
							$scope.progressId = 'false';
							$scope.jsonresponse = "Complete Log for Channel ID: " + index + " ";
							$scope.myHTML = $sce.trustAsHtml(logMessage);
							$scope.isClickAllowed = true;
						}
						for (var i = 0; i < myArr.length; i++)
						  {
							var xx = myArr[i]._source.source;
							logContent = logContent.concat(xx);
						  }
					});
			  }
				$scope.showLog = true;
				$scope.progressId = 'false';
				$scope.jsonresponse = "Complete Log for Channel ID: " + index + " ";
				$scope.isClickAllowed = true;
			});
			currenttimestamp = currenttimestamp.replace(/\s+/, "_");
			currenttimestamp = currenttimestamp.replace(/\s+/, "_");
			xsiLogName = 'xsilog_' + currenttimestamp +  '.log';
		}
		$scope.download = function(){
			var element = document.createElement('a');

			if (navigator.msSaveBlob) {
			  navigator.msSaveBlob(new Blob([logContent], { type : 'text/plain;charset=utf-8;'
				}), xsiLogName);
			}
			else { // Chrome && FireFox
				element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(logContent));
				element.setAttribute('download', xsiLogName);
				if (document.createEvent) {
					var event = document.createEvent('MouseEvents');
					event.initEvent('click', true, true);
					element.dispatchEvent(event);
				}
				else {
					element.click();
				}
			}
		}
		function htmlEntities(str)
		{
			return String(str).replace(/</g, '&lt;').replace(/>/g, '&gt;');
		}
	  }
	  $scope.fullScreen = function ()
	  {
	  if(isAbsolute)
	  {
		if ($scope.fullScreenMode) {
		   $scope.showTwoPane = true;
		   if(chsubcall) {
			$scope.showCorForAbsolute = true;
			$scope.showChForAbsolute = false;
		  } else {
		  	$scope.showCorForAbsolute = false;
			$scope.showChForAbsolute = true;
		  }
		}
		else {
		  $scope.showTwoPane = false;
		  $scope.showChForAbsolute = false;
		  $scope.showCorForAbsolute = false;
		}
	  } else {
	  	if ($scope.fullScreenMode) {
		  // $scope.fullScreenMode = false;
		   $scope.showTwoPane = true;
		   if(!chsubcall) {
			$scope.showChannelList = true;
		  } else {
			$scope.showChannelList = false;
			$scope.showCor = true;
		  }
		}
		else {
		  //$scope.fullScreenMode = true;
		  $scope.showTwoPane = false;
		  $scope.showChannelList = false;
		  $scope.showCor = false;
		}
		if($scope.fullScreenMode)
			$scope.fullScreenMode = false;
		else
			$scope.fullScreenMode = true;
	  }
	}
});

