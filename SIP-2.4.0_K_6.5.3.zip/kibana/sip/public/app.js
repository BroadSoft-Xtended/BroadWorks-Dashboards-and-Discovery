import moment from 'moment';
import chrome from 'ui/chrome';
import uiModules from 'ui/modules';
import uiRoutes from 'ui/routes';
import uiChrome from 'ui/chrome';
// Third Part dependency
import './dependency.js';
// HTML Template
import indexPage from './templates/index.html';
import idSearchPage from './templates/corridsearch.html';
import callFlowPage from './templates/sipCallFlow.html';
import ociLogCollectorPage from './templates/ociLogCollector.html';
import configurationPage from './templates/configuration.html';
import logCollectorPage from './templates/logCollector.html';
import advanceSearchPage from './templates/advanceSearch.html';
import dashboard from './templates/visualize.html';



uiRoutes.enable();
uiRoutes
  .when("/index", {
    template: indexPage,
    controller: "sipController"
  })
  .when("/id-Search", {
    template: idSearchPage,
    controller: "correlationidController"
  })
  .when("/id-Search/id/:callId", {
    template: idSearchPage,
    controller: "correlationIdRedirectController"
  })
  .when("/sip-Call-Flow", {
    template: callFlowPage,
    controller: "sipCallFlowController"
  })
  .when("/sip-Call-Flow/id/:callId", {
    template: callFlowPage,
    controller: "sipCallFlowRedirectController"
  })
  .when("/oci-Transcations", {
    template: ociLogCollectorPage,
    controller: "ociController"
  })
  .when("/settings", {
    template: configurationPage,
    controller: "configurationController"
  })
  .when("/log-Collector", {
    template: logCollectorPage,
    controller: "logCollectorController"
  })
  .when("/advance-Search", {
    template: advanceSearchPage,
    controller: "advanceSearchController"
  })
  .otherwise({
    redirectTo: "/index"
  });;
