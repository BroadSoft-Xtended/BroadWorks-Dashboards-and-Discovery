import {
  uiModules
} from 'ui/modules';
uiModules
  .get('app/sip', ['ngDialog', 'ngCookies'])
  .controller('indexAddController', function($scope, $route, $http, $cookies, ngDialog) {


    $scope.choices = [{}];

    $scope.submitIndexRecord = function() {
      console.log($scope.choices[0].index_alias);
      $scope.progress = 'true';
      $http.get('../api/sip/addTribeIndexPattern', {
        params: {
          pattern: $scope.choices[0].index_alias,
          document: $scope.choices
        }
      }).then((response) => {
        // Checks the response if index pattern already exists
        // Added to avoid duplicate Index Pattern
        if (response.data === 'Pattern Already Exists') {
          $scope.openErrorAlert('Error :) - Pattern Already Exists');
        } else {
          console.log('SUCCESS');
          $scope.openErrorAlert('SUCCESS :) - Added Index');
        }

        $scope.progress = 'false';
      }, function errorCallback(response) {
        console.log('ERROR');
        $scope.progress = 'false';
        $scope.openErrorAlert('ERROR :( - Could not Access Server');
      });
    };

    /**
     * [formReset Reset the input form box]
     */
    $scope.formReset = function() {
      $scope.choices = [{}];
    };

  });
