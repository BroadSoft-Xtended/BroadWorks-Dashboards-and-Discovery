import {
  uiModules
} from 'ui/modules';
var angular = require('../js/angular');
uiModules
  .get('app/sip', ['ngDialog', 'ngCookies', 'pascalprecht.translate'])

  .controller('advanceSearchController', function($scope, $route, $interval, $http, $sce, $filter, $cookies, ngDialog, $translate) {

    /**
     * [setActiveClass Add class to the idMenu ID Dom]
     */
    $scope.setActiveClass = function() {
      var navList = angular.element(document.querySelector('#advanceSearch'));
      navList.addClass('active');
    };

    /**
     * @desc Comman Non Modal Box for alert.
     * @param message- contains message to be displayed to user
     * @return void
     */
    $scope.openModalBox = function(message) {
      ngDialog.open({
        template: '<p>' + message + '</p>',
        plain: true
      });
    };



    /**
     * [fetchGlobalInfo Read the value from the cookie stored]
     * @return {[void]} [description]
     */
    $scope.fetchGlobalInfo = function() {
      var globalCookie = $cookies.get('globalConfiguration');
      if (globalCookie) {
        $scope.test = globalCookie;
        var json = JSON.parse(globalCookie);
        console.log('Custom Settings Applied');
        console.log(json);
        if (json.sort === 'Ascending') {
          $scope.sortPreference = 'asc';
        } else if (json.sort === 'Descending') {
          $scope.sortPreference = 'desc';
        }
        if (json.index) {
          console.log(json.index);
          $scope.searchIndex = json.index;
        }
        $scope.sampleSize = json.size;
      } else {
        console.log('Default Settings is Applied');
        $scope.searchIndex = 'bwlog*';
        $scope.sortPreference = 'asc';
        $scope.sampleSize = '1000';
      }
    };
    $scope.fetchGlobalInfo();

    /**
     * [reset Intialize and Reset to the original Value]
     */
    $scope.reset = function() {
      $scope.advTerm = '';
      $scope.qsearch = null;
      $scope.logM = null;
      $scope.time = {
        option: "Absolute"
      };
      $scope.DefaultTime = "07/30/2016 12:00 AM";
      $scope.PresentTime = $filter("date")(new Date(), "MM/dd/yyyy hh:mm a");
      $scope.TimeDuration = [
        "5 Min",
        "10 Min",
        "15 Min",
        "1 Hour",
        "2 Hours",
        "5 Hours",
        "1 Day",
        "1 Week"
      ];

    };

    //reset() is invovked by below statement
    $scope.reset();

    $(function() {
      $("#datetimepicker1").datetimepicker({
        allowInputToggle: true
      });
      $("#datetimepicker2").datetimepicker({
        allowInputToggle: true
      });
    });

    /**
     * [htmlEntities Replace the HTML begining and closing Tags]
     * @param  {[string]} str [logmessage ]
     * @return {[type]}     [All the HTML tags are converted into &lt and &gt]
     */
    function htmlEntities(str) {
      return String(str).replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    /**
     * [renderLogMessage renders the logmessage for given correlationId]
     * @param  {[object]} myArr      [json object from server]
     * @param  {[string]} uniquetime [log file timestamp]
     * @return {[object]}            [holds logmessage, logfile]
     */
    function renderLogMessage(myArr, uniquetime) {
      var logMessage = '';
      var logFile = '';
      //logFile model variable is used hold log message for  file being downloaded
      $scope.logFile = myArr;
      $scope.logFileName = uniquetime;
      var xsiEventApp = '/app/xsi_event#/';
      var CorrelationIDCon = '/app/sip#/id-Search/id/';
      /**
       * [timeFrame - It hold the fromTime and endTime]
       * [desc - As we need to launch XSI event APP we need to pass epooch begining
       * and current epoch milli time]
       * @type {Array}
       */
      $scope.timeFrame = ['0000000000000', new Date().getTime()];
      // Below code snippet is used to decorate the Log Message First Line
      for (var i = 0; i < myArr.length; i++) {
        var xx = htmlEntities(myArr[i]._source.source);
        logFile = logFile.concat(myArr[i]._source.source);
        /**
         * [firstLinePatternRE used to hold the regex for the first line]
         * Used to capture the first Line in log message, refer CallCorrelationIdentifierFD-R200
         * @type {[string]}
         */
        var firstLinePatternRE = /^(\d{4}\.\d{2}\.\d{2}\s+.*)\n/g;
        var y = xx.match(firstLinePatternRE);
        xx = xx.replace(firstLinePatternRE, '<div id="decorate">' + y[0] + '</div>');

        var correlationIdPatternRe = /\s\w{8}-\w{4}-\w{4}-\w{4}-\w{12}\s/g;
        var correlationId = xx.match(correlationIdPatternRe);
        if (correlationId != null) {
          xx = xx.replace(correlationIdPatternRe,
            '<a href="' +
            CorrelationIDCon + correlationId[0].trim() + '" data-context-menu="custom.html"' +
            '" target="_blank" >' + correlationId + '</a>');
        }
        logMessage = logMessage.concat(xx);
      }
      return [logMessage, logFile];
    };

    var getCurrentTime = function() {
      var CurrentTime = $filter("date")(new Date(), "MM/dd/yyyy hh:mm a");
      return new Date(CurrentTime).getTime();
    };

    /**
     * @desc Get the relative time based on the option selected 'Relative time'
     * @desc Calculation for relative time = Mins * 60 * 1000
     * @param no params
     * @return void
     */
    var getRelativeTime = function() {
      var relativeTime;
      var currentTime = getCurrentTime();
      switch ($scope.selectedRelative) {
        case "5 Min":
          relativeTime = currentTime - 300 * 1000;
          break;
        case "10 Min":
          relativeTime = currentTime - 600 * 1000;
          break;
        case "15 Min":
          relativeTime = currentTime - 900 * 1000;
          break;
        case "1 Hour":
          relativeTime = currentTime - 3600 * 1000;
          break;
        case "2 Hours":
          relativeTime = currentTime - 7200 * 1000;
          break;
        case "5 Hours":
          relativeTime = currentTime - 18000 * 1000;
          break;
        case "1 Day":
          relativeTime = currentTime - 86400 * 1000;
          break;
        case "1 Week":
          relativeTime = currentTime - 604800 * 1000;
          break;
        default:
          //By default it points to 5 Min
          relativeTime = currentTime - 300 * 1000;
      }
      return relativeTime;
    };

    /**
     * @desc getting Absolute Time - From Time
     * @param no params
     * @return void
     */
    var getAbsoluteFromTime = function() {
      var UserFromDate = angular.element($("#userfromdate")).val();
      return new Date(UserFromDate).getTime();
    };

    /**
     * @desc getting Absolute Time - End Time
     * @param no params
     * @return void
     */
    var getAbsoluteToTime = function() {
      var UserToDate = angular.element($("#usertodate")).val();
      return new Date(UserToDate).getTime();
    };

    /**
     * @desc Assign 'time from' and 'time to' based upon time context
     * @param no params
     * @return fromTime, toTime
     */
    var assignTime = function() {
      var fromTime;
      var endTime;
      // Relative Time Functionality
      if ($scope.time.option === "Relative") {
        fromTime = getRelativeTime();
        endTime = getCurrentTime();
      } else {
        // Absolute Time Functionality
        fromTime = getAbsoluteFromTime();
        endTime = getAbsoluteToTime();
      }
      $scope.timeFrame = [fromTime, endTime];
      return [fromTime, endTime];
    };



    /**
     * [fetchLogMessage It returns the revelant log based on the correlationid]
     * @param  {[number]} correlationid [Correlation ID(Unique ID) for SIP calls]
     * @param  {[uniquetime]} uniquetime    [provide timestamp as name for log file being donwloaded]
     * @return {[type]}               [description]
     */
    $scope.fetchAdvTermLogMessage = function(advTerms, uniquetime) {

      $scope.progress = 'true';
      $scope.logM = null;
      var time = assignTime();
      //console.log(time);
      $scope.fromTime = time[0];
      $scope.endTime = time[1];
      $scope.advTerms = $scope.advTerm;
      $scope.paramQuery = queryBuilder(
        $scope.fromTime,
        $scope.endTime,
        $scope.advTerms,
        "asc"
      );
      $http.get('../api/sip/advanceSearch', {
        params: {
          searchIndex: $scope.searchIndex,
          advanceQuery: $scope.paramQuery
        }
      }).then((response) => {
        if (response.data === 'Error') {
          $scope.openModalBox('No Logs Found');
          $scope.progress = 'false';
          return;
        }
        var myArr = response.data.hits.hits;
        if (myArr.length < 1) {
          $scope.openModalBox('No Logs Found');
        }

        /**
         * [result description holds logMessage, logFile]
         * [result [0]logMessage formatted output displayed to user]
         * [resut [1]logFile original text file]
         * @type {[object]}
         */
        var result = renderLogMessage(myArr, uniquetime);
        //AngularJs does not support rendering the HTML components
        //so We need to trustAsHtml before sending to ng-model
        //$scope.logM = $sce.trustAsHtml(logMessage);
        $scope.logM = $sce.trustAsHtml(result[0]);
        $scope.logFileMessage = result[1];
        $scope.progress = 'false';
      });
    };



    /**
     * @desc queryBuilder
     * @param fromTime, toTime, searchCondition, sipmethod
     * @return void
     */
    var queryBuilder = function(
      fromTime,
      toTime,
      advTerms,
      sortOrder
    ) {
      var query = {
        version: true,
        size: 1000,
        sort: [{
          logtimestamp: {
            order: "asc",
            unmapped_type: "boolean"
          }
        }],
        _source: {
          excludes: [

          ]
        },
        query: {
          bool: {
            must: [{
                query_string: {
                  query: advTerms,
                  analyze_wildcard: true,
                  default_field: "*"
                }
              },
              {
                range: {
                  logtimestamp: {
                    gte: fromTime,
                    lte: toTime,
                    format: "epoch_millis"
                  }
                }
              }
            ]
          }
        }
      };
      return query;
    };


    /**
     * [rangeSelector Allows to select only complete log message panel]
     * @param  {[string]} containerid [name of the container]
     * @return {[void]}             [void]
     */
    $scope.rangeSelector = function(containerid) {
      var range = '';
      var node = document.getElementById(containerid);

      if (document.selection) {
        range = document.body.createTextRange();
        range.moveToElementText(node);
        range.select();
      } else if (window.getSelection) {
        range = document.createRange();
        range.selectNodeContents(node);
        window.getSelection().removeAllRanges();
        window.getSelection().addRange(range);
      }
    };

    /**
     * [keyCode Self Invoking function]
     * @type {[keyword event]}
     */
    $scope.keyDown = function(e) {
      if (e.keyCode === 65 && e.ctrlKey) {
        $scope.rangeSelector('CorridCompleteLog');
        e.preventDefault();
      }
    };


    /**
     * [downloadFile Writes the log information to filename]
     * @return {[text]} [logfile]
     */
    $scope.downloadFile = function() {
      var element = document.createElement('a');
      element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent($scope.logFileMessage));
      element.setAttribute('download', 'siplog_' + $scope.advTerm + '.txt');
      element.style.display = 'none';
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    };

    /**
     * [fullScreen Make fullScreen of Complete Log Panel]
     * @return {[void]}
     */
    $scope.fullScreen = function() {

      if ($scope.fullScreenMode === true) {
        $scope.fullScreenMode = false;
        document.getElementById('full-screen-container').style.marginTop = null;
      } else {
        $scope.fullScreenMode = true;
        document.getElementById('full-screen-container').style.marginTop = '100px';
      }
    };

  });
