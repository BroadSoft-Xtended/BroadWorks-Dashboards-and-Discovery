import uiModules from 'ui/modules';
var angular = require('../js/angular');
uiModules
.get('app/sip', ['ngDialog','ngCookies'])
.controller('configurationController', function ($scope, $route, $cookies, $http, ngDialog) {

  $scope.viewIndexDiv = false;
  $scope.addIndexDiv = true;
  $scope.updateIndexDiv = false;
  $scope.removeIndexDiv = false;

  /**
   * [setActiveClass Add class to the settingsMenu ID Dom]
   */
  $scope.setActiveClass = function () {
    var navList = angular.element(document.querySelector('#settingsMenu'));
    navList.addClass('active');
  };
  /**
  * @desc Comman Non Modal Box for alert.
  * @param message- contains message to be displayed to user
  * @return void
  */
  $scope.openModalBox = function (message) {
    ngDialog.open({ template: '<p>' + message + '</p>', plain: true });
  };

  /**
  * @desc Comman Non Modal Box for alert.
  * @param message- contains message to be displayed to user
  * @return void
  */
  $scope.openErrorAlert = function (message) {
    var response = message.split('-');
    ngDialog.open({ template: '<p class="alertBox">' + response[0] + '</p>' +
      response[1] ,
    plain: true });
  };

  /**
   * [globalSetting Apply the setting globalCookie]
   * @return {[void]} [creates new cookie when setting is applied]
   */
  $scope.globalSetting = function () {
    console.log($scope.Data);
    $cookies.put('globalConfiguration', JSON.stringify($scope.Data));
  };

  /**
   * [openNav Opens the side navigation bar]
   * @return {[void]} []
   */
  $scope.openNav = function () {
    document.getElementById('mySidenav').style.width = '250px';
    document.getElementById('mainpage').style.marginLeft = '250px';
  };

  /**
   * [closeNav Close the side navigation bar]
   * @return {[void]} []
   */
  $scope.closeNav = function () {
    document.getElementById('mySidenav').style.width = '0';
    document.getElementById('mainpage').style.marginLeft = '0';
  };

  /**
   * [selectIndex Displays the SelectIndex View]
   * @return {[type]} [description]
   */
  $scope.selectIndex = function () {
    $scope.viewIndexDiv = true;
    $scope.addIndexDiv = false;
    $scope.updateIndexDiv = false;
    $scope.removeIndexDiv = false;
  };

  /**
   * [addingIndex Displays the AddIndex View]
   * @return {[type]} [description]
   */
  $scope.addingIndex = function () {
    $scope.viewIndexDiv = false;
    $scope.addIndexDiv = true;
    $scope.updateIndexDiv = false;
    $scope.removeIndexDiv = false;
  };

  /**
   * [updatingIndex Displays the UpdateIndex View]
   * @return {[type]} [description]
   */
  $scope.updatingIndex = function () {
    $scope.viewIndexDiv = false;
    $scope.addIndexDiv = false;
    $scope.updateIndexDiv = true;
    $scope.removeIndexDiv = false;
  };

  /**
   * [removingIndex Displays the RemoveIndex View]
   * @return {[type]} [description]
   */
  $scope.removingIndex = function () {
    $scope.viewIndexDiv = false;
    $scope.addIndexDiv = false;
    $scope.updateIndexDiv = false;
    $scope.removeIndexDiv = true;
  };

});
