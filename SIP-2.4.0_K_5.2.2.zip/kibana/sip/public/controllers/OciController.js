import uiModules from 'ui/modules';
var angular = require('../js/angular');
uiModules
  .get('app/sip', ['720kb.tooltips', 'ngDialog', 'ngCookies'])
  .controller('ociController', function($scope, $route, $http, ngDialog) {

    /**
     * [init Contains the intial value for the form]
     * @return {[void]} [function loaded when page is loaded]
     */
    $scope.init = function() {
      //Query User
      $scope.oci = {
        option: 'queryUser'
      };
      $scope.connectionMode = {
        value: true
      };
      // $scope.queryUserL = 'admin';
      // $scope.UserUserPassL = 'ladmin';
      // $scope.queryUserName = 'gokul1@gokul.com';
      // $scope.queryUserServer = '10.99.15.65';
      // //Query Group
      // $scope.queryGroupUserNameL = 'admin';
      // $scope.queryGroupUserPasswordL = 'ladmin';
      // $scope.queryGroupProviderName = 'SP1';
      // $scope.queryGroupName = 'GRP1';
      // $scope.queryGroupServer = '10.99.15.65';
      // $scope.displayInfo = '';
    };
    $scope.init();

    var encrypt = function(str) {
      var encoded = '';
      for (var i = 0; i < str.length; i++) {
        var a = str.charCodeAt(i);
        var b = a ^ 123; // bitwise XOR with any number, e.g. 123
        encoded = encoded + String.fromCharCode(b);
      }
      return encoded;
    };

    /**
     * [setActiveClass Add class to the ociMenu ID Dom]
     */
    $scope.setActiveClass = function() {
      var navList = angular.element(document.querySelector('#ociMenu'));
      navList.addClass('active');
    };

    /**
     * [reset :Clears the content in output panel]
     */
    $scope.reset = function() {
      $scope.displayInfo = '';
    };

    /**
     * @desc Comman Non Modal Box for alert.
     * @param message- contains message to be displayed to user
     * @return void
     */
    $scope.openErrorAlert = function(message) {
      var response = message.split('-');
      ngDialog.open({
        template: '<p class="alertBox">' + response[0] + '</p>' +
          '<ul class="alertBoxBody"><li>' + response[1] + '</li></ul>',
        plain: true
      });
    };

    /**
     * [setProgressFalse :Sets the progressbar status to false]
     */
    var setProgressFalse = function() {
      $scope.progress = 'false';
    };
    /**
     * [readPropFile Contains the Server Url]
     * @type {String}
     */
    $scope.readConfigFile = function() {
      $http.get('../api/sip/readConfigFile', {

      }).then((response) => {
        //console.log(response.data);
        if (response.data === 'Error in Configuration File') {
          $scope.openErrorAlert('Invalid Configuration File');
        } else {
          console.log(response.data);
          $scope.collectorLocation = response.data;
        }
      });
    };
    $scope.readConfigFile();


    /**
     * [displayResult description]
     * @param  {[string]} message [Message comes from the server]
     * @return {[errorMessage]}  [Display the error message or format the XML output]
     */
    var displayResult = function(message) {
      switch (message) {
        case 'Error Code : 12001 - Invalid Request':
          $scope.openErrorAlert('Error Code : 12001 - Invalid Request');
          setProgressFalse();
          break;
        case 'Error Code : 12002 - Failed to connect Server':
          $scope.openErrorAlert('Error Code : 12002 - Failed to connect Server');
          setProgressFalse();
          break;
        case 'Error Code : 12003 - Invalid Credentials':
          $scope.openErrorAlert('Error Code : 12003 - Invalid Credentials');
          setProgressFalse();
          break;
        case 'Error Code : 12004 - User not Found':
          $scope.openErrorAlert('Error Code : 12004 - User not Found');
          setProgressFalse();
          break;
        case 'Error Code : 12005 - ServiceProvider or Enterprise not found':
          $scope.openErrorAlert('Error Code : 12005 - ServiceProvider or Enterprise not found');
          setProgressFalse();
          break;
        case 'Error Code : 12006 - Group not found':
          $scope.openErrorAlert('Error Code : 12006 - Group not found');
          setProgressFalse();
          break;
        default:
          $scope.Info = message;
          /*global
          vkbeautify
          */
          $scope.displayInfo = vkbeautify.xml(message);
          setProgressFalse();
      }
    };

    var validateQueryUser = function() {
      // Introduced this block for secondary check and advanced check
      // yet to inspire for more validation check
      if (!$scope.queryUserL) {
        $scope.openModalBox('Enter a Valid User Name Credentials');
        return false;
      }
      if (!$scope.UserUserPassL) {
        $scope.openModalBox('Enter a Valid User Password Credentials');
        return false;
      }
      if (!$scope.queryUserName) {
        $scope.openModalBox('Enter a Valid Query User Name');
        return false;
      }
      if (!$scope.queryUserServer && validateIPaddress($scope.queryUserServer)) {
        return false;
      } else {

        return true;

      }
    };

    /**
     * [connectionChannel Decided connection request through BTBC or OCI Client]
     * @return {[int]} [return 1 for BTBC, return 2 for OCI Client]
     */
    var connectionChannel = function() {
      var connectionMode;
      if ($scope.connectionMode.value === true) {
        connectionMode = 2;
        return connectionMode;
      } else {
        connectionMode = 1;
        return connectionMode;
      }
    };

    /**
     * [queryUserframeUrl :Frames the request url for the queryuser]
     * @return {[string]} [return url]
     */
    var queryUserframeUrl = function() {
      var connectionMode = connectionChannel();
      var requestUrl = '/queryUser?an=' +
        $scope.queryUserL + '&pwd=' +
        encodeURIComponent(encrypt($scope.queryGroupUserPasswordL)) + '&un=' +
        $scope.queryUserName + '&h=' + $scope.queryUserServer + '&cm=' + connectionMode;
      return requestUrl;
    };

    /**
     * [queryUserGroupframeUrl :Frames the request url for the queryGroup]
     * @return {[string]} [return url]
     */
    var queryUserGroupframeUrl = function() {
      var connectionMode = connectionChannel();
      var requestUrl = '/queryGroup?an=' +
        $scope.queryGroupUserNameL + '&pwd=' +
        encodeURIComponent(encrypt($scope.queryGroupUserPasswordL)) + '&sp=' +
        $scope.queryGroupProviderName + '&grp=' +
        $scope.queryGroupName + '&h=' +
        $scope.queryGroupServer + '&cm=' + connectionMode;
      return requestUrl;
    };



    /**
     * [callServer description]
     * @return {[type]} [description]
     */
    var callServer = function(context) {
      $scope.displayInfo = '';
      $scope.progress = 'true';
      $http.get('../api/sip/ociTranscationLogCollector', {
        params: {
          queryString: context
        }
      }).then((response) => {
        //console.log(response);
        var result = response.data;
        displayResult(result);
      }, function(response) {
        //Second function handles error
        console.log('ERROR');
        $scope.progress = 'false';
        $scope.openErrorAlert('ERROR :( - Could not Access Server');
      });
    };

    /**
     * [submitQueryUserForm Onsubmit function decided whether query-user or query-group]
     * @return {[void]} [calls either queryUserframeUrl or queryGroupName]
     */
    $scope.submitQueryUserForm = function() {
      if ($scope.oci.option === 'queryUser') {
        //console.log(validateQueryUser());
        // Call Query User Validation
        if (validateQueryUser()) {
          $scope.fileNameSuffix = '_' + $scope.queryUserName;
          var querUrl = queryUserframeUrl();
          callServer(querUrl);
        }
      } else if ($scope.oci.option === 'queryGroup') {
        // Call Query Group Validation
        $scope.fileNameSuffix = '_' + $scope.queryGroupProviderName + '_' + $scope.queryGroupName;
        var queryUrl = queryUserGroupframeUrl();
        callServer(queryUrl);
      }
    };

    /**
     * [validateIPaddress description]
     * @param  {[int]} inputText [IP Address Expected]
     * @return {[boolean]} [returns boolean upon validation]
     */
    function validateIPaddress(inputText) {
      var RegE = /^\d{1,3}.\d{1,3}.\d{1,3}.\d{1,3}$/;
      if (!inputText.match(RegE)) {
        //$scope.openModalBox('Em');
        $scope.openModalBox('You have entered an invalid IP address!');
        return false;
      }
      return true;
    };

    /**
     * @desc It helps to download the log file with timestamp as filename
     * @param no params
     * @return void
     */
    $scope.downloadFile = function() {
      var fileName = $scope.Info;
      var logFileName = $scope.oci.option + $scope.fileNameSuffix;
      //console.log(logFileName);
      var element = document.createElement('a');
      /**
       * Added to fix the download file feature in IE browser
       * There is limitation of character that can be passed in url
       */
      if (navigator.msSaveBlob) { // IE 10+
        navigator.msSaveBlob(new Blob([$scope.Info], {
          type: 'text/plan;charset=utf-8;'
        }), 'siplog_' + logFileName + '.xml');
      } else { // Chrome && FireFox
        element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent($scope.Info));
        element.setAttribute('download', 'siplog_' + logFileName + '.xml');
        element.style.display = 'none';
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);
      }
    };

    /**
     * @desc Make fullScreen of Complete Log Panel
     * @param no params
     * @return void
     */
    $scope.fullScreen = function() {
      if ($scope.fullScreenMode === true) {
        $scope.fullScreenMode = false;
        document.getElementById('full-screen-container').style.marginTop = null;
      } else {
        $scope.fullScreenMode = true;
        document.getElementById('full-screen-container').style.marginTop = '30px';
      }
    };

  });
