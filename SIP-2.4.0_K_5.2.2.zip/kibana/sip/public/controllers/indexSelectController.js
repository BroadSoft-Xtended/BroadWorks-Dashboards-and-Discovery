import uiModules from 'ui/modules';
var angular = require('../js/angular');
uiModules
.get('app/sip', ['ngDialog','ngCookies'])
.controller('indexSelectController', function ($scope, $route, $http, $cookies, ngDialog) {

  $scope.fetchIndexPattern = function () {
    $scope.progress = 'true';
    $http.get('../api/sip/selectTribeIndexPattern').then((response) => {
      console.log(response);
      if (response.data !== 'Error') {
        $scope.index = response.data.hits.hits;
      }
      else {
        $scope.openErrorAlert('ERROR :( - No Entries Present');
      }
    }, function errorCallback(response) {
      console.log('ERROR2');
      $scope.progress = 'false';
      $scope.openErrorAlert('ERROR :( - Could not Access Server');
    });
  };
  $scope.fetchIndexPattern();

  /**
   * [globalSetting Apply the setting globalCookie]
   * @return {[void]} [creates new cookie when setting is applied]
   */
  $scope.setIndexName = function (Data) {
    $scope.openErrorAlert('Index Pattern -' + Data.index + '  Applied');
    console.log(Data);
    $cookies.put('globalConfiguration', JSON.stringify(Data));
  };

});
