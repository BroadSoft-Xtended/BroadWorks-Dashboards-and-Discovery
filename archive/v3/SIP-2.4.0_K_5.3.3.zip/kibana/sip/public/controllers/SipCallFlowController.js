import uiModules from 'ui/modules';
var angular = require('../js/angular');
var $ = require('jquery');
var mscgenjs = require('../js/mscgenjs');
uiModules
  .get('app/sip', ['720kb.tooltips', 'ngDialog', 'ngCookies'])
  .controller('sipCallFlowController', function($scope, $route, $http, ngDialog, $cookies) {

    // Application Name
    $scope.AppName = 'SIP Call Flow';
    $scope.collectorLocation;

    $scope.readConfigFile = function() {
      $http.get('../api/sip/readConfigFile', {

      }).then((response) => {
        //console.log(response.data);
        if (response.data === 'Error in Configuration File') {
          $scope.openErrorAlert('Invalid Configuration File');
        } else {
          console.log(response.data);
          $scope.collectorLocation = response.data;
        }
      });
    };

    function replaceElement(source, newType) {
      // Create the document fragment
      const frag = document.createDocumentFragment();
      // Fill it with what's in the source element
      while (source.firstChild) {
        frag.appendChild(source.firstChild);
      }
      // Create the new element
      const newElem = document.createElement(newType);
      // Empty the document fragment into it
      newElem.appendChild(frag);
      // Replace the source element with the new element on the page
      source.parentNode.replaceChild(newElem, source);
    }
    //Display request on click for SIP Ladder Diagram
    var displayRequest = function() {
      var dis = document.getElementById('mscgen_js-svg-__chart');
      var titleTags = dis.getElementsByTagName('title');
      while (titleTags[0] != null) {
        replaceElement(titleTags[0], 'payload');
        titleTags = dis.getElementsByTagName('title');

      }
      dis.addEventListener('click', function(event) {
        var disp = (event.target.innerHTML).replace('<payload>', '');
        if (disp != "") {
          disp = disp.replace('</payload>', '');
          while (disp.match('&lt;')) {
            disp = disp.replace('&lt;', '<');
            disp = disp.replace('&gt;', '>');
          }
          disp = disp.replace(/\\/g, '');
          if (disp.match('xml version')) {
            $scope.displayInfo = vkbeautify.xml(disp);
          } else {
            $scope.displayInfo = disp;
          }
        } else {
          $scope.displayInfo = null;
        }
        $scope.$apply();
      });
    };

    //$scope.readConfigFile();
    /**
     * [setActiveClass Add class to the sipCallSequenceMenu ID Dom]
     */
    $scope.setActiveClass = function() {
      var navList = angular.element(document.querySelector('#sipCallSequenceMenu'));
      navList.addClass('active');
    };

    /**
     * [corridId : Assign default correlationID]
     * @type {String}
     */
    // $scope.corridId = '33f8853b-8758-4a34-8856-4a4a422149f4';
    $scope.chartDisplayed = false;

    /**
     * @desc Comman Non Modal Box for alert.
     * @param message- contains message to be displayed to user
     * @return void
     */
    $scope.openErrorAlert = function(message) {
      var response = message.split('-');
      //console.log(response);
      ngDialog.open({
        template: '<p class="errorBox">' + response[0] + '</p>' +
          '<ul class="alertBoxBody"><li>' + response[1] + '</li></ul>',
        plain: true
      });
    };

    /**
     * [startSpin : Enable the progress bar]
     * @return {[type]} [description]
     */
    $scope.startSpin = function() {
      $scope.progress = 'true';
    };
    /**
     * [stopSpin : Disable the progress bar]
     * @return {[type]} [description]
     */
    $scope.stopSpin = function() {
      $scope.progress = 'false';
    };

    /**
     * [removeSVG : Remove the existing SVG image before rendering]
     * @return {[type]} [description]
     */
    var removeSVG = function() {
      var chartId = document.getElementById('mscgen_js-svg-__chart');
      //console.log(chartId);
      if (chartId) {
        document.getElementById('mscgen_js-svg-__chart').remove();
      }
    };

    var renderCall = function() {

      //$scope.dataBody = '"10.0.37.109"[linecolor="#00A1DE", textbgcolor="black", textbgcolor="#00A1DE", arclinecolor="black", arclinecolor="#00A1DE", arctextcolor="black"],"Execution Server"[linecolor="#00A1DE", textbgcolor="black", textbgcolor="#00A1DE", arclinecolor="black", arclinecolor="#00A1DE", arctextcolor="black"];"10.0.37.109"=>"Execution Server" [label="INVITE", url="javascript:(function(){document.getElementById(\'explanationbox\').innerHTML=\'My long description on what this a => b thing is actually doing. \'})()"];'
      $scope.queryLang = 'msc {' + $scope.dataBody + '}';
      mscgenjs.renderMsc($scope.queryLang, {
          inputType: 'xu',
          additionalTemplate: 'lazy',
          includeSource: false,
          elementId: '__chart',
        },
        handleRenderMscResult
      );

      function handleRenderMscResult(pError, pSuccess) {
        if (Boolean(pError)) {
          console.log(pError);
          return;
        } else if (Boolean(pSuccess)) {
          $scope.stopSpin();
          $scope.chartDisplayed = 'true';
          console.log('Chart Rendered');
          return;
          // the svg is in the pSuccess argument
        }
        console.log('Wat! Error nor success?');
      };
    };

    /**
     * [fetch : Generate the SIP Sequence Diagram for the given correaltion ID]
     * @return {[void]} [description]
     */
    $scope.fetch1 = function() {
      $scope.startSpin();
      removeSVG();
      $scope.chartDisplayed = 'false';
      var url = 'http://' + $scope.collectorLocation + '/sipCallFlow?id=' + $scope.corridId + '&index=' + $scope.searchIndex;
      $http.get(url).then((response) => {
        if (response.data === 'Error Code: 13001 - Invalid Context Path orError Code: 13002 - Invalid Correlation ID' ||
          response.data === 'Error Code: 13003 - No Result Found in Elasticsearch' ||
          response.data === 'Error Code: 13004 - Index Pattern Not Present') {
          $scope.openErrorAlert(response.data);
          $scope.stopSpin();
        } else {
          $scope.dataBody = response.data;
          renderCall();
          displayRequest();
        }
      }, function(error) {
        //Second function handles error
        console.log('ERROR');
        $scope.stopSpin();
        $scope.openErrorAlert('ERROR :( - Could not Access Server');
      });
    };

    /**
     * [fetch : Generate the SIP Sequence Diagram for the given correaltion ID]
     * @return {[void]} [description]
     */
    $scope.fetch = function() {
      $scope.displayInfo = null;
      $scope.startSpin();
      removeSVG();
      $scope.chartDisplayed = 'false';
      var context = '/sipCallFlow?id=' + $scope.corridId + '&index=' + $scope.searchIndex;
      $http.get('../api/sip/sipCallFlowLogCollector', {
        params: {
          queryString: context
        }
      }).then((response) => {
        if (response.data === 'Error Code: 13001 - Invalid Context Path orError Code: 13002 - Invalid Correlation ID' ||
          response.data === 'Error Code: 13003 - No Result Found in Elasticsearch' ||
          response.data === 'Error Code: 13004 - Index Pattern Not Present') {
          $scope.openErrorAlert(response.data);
          $scope.stopSpin();
        } else {
          $scope.dataBody = response.data;
          //console.log(response.data);
          renderCall();
          displayRequest();
        }
      }, function(error) {
        //Second function handles error
        console.log('ERROR');
        $scope.stopSpin();
        $scope.openErrorAlert('ERROR :( - Could not Access Server');
      });
    };

    /**
     * [fetchGlobalInfo Read the value from the cookie stored]
     * @return {[void]} [description]
     */
    $scope.fetchGlobalInfo = function() {
      var globalCookie = $cookies.get('globalConfiguration');
      if (globalCookie) {
        $scope.test = globalCookie;
        var json = JSON.parse(globalCookie);
        console.log('Custom Settings Applied');
        console.log(json);
        if (json.sort === 'Ascending') {
          $scope.sortPreference = 'asc';
        } else if (json.sort === 'Descending') {
          $scope.sortPreference = 'desc';
        }
        if (json.index) {
          console.log(json.index);
          $scope.searchIndex = json.index;
        }
        $scope.sampleSize = json.size;
      } else {
        console.log('Default Settings is Applied');
        $scope.searchIndex = 'bwlog*';
        $scope.sortPreference = 'asc';
        $scope.sampleSize = '1000';
      }
    };
    $scope.fetchGlobalInfo();



    /**
     * [downloadSvg : Download the SVG file with correlationId ]
     * @return {[type]} [description]
     */
    $scope.downloadSvg = function() {
      var a = document.createElement('a');
      a.href = 'data:image/svg+xml;utf8,' + unescape($('#__chart')[0].outerHTML);
      a.download = 'callFlow_' + $scope.corridId + '.svg';
      a.target = '_blank';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    };


    $scope.downloadJpg = function() {
      var svg = document.querySelector('svg');
      var svgData = new XMLSerializer().serializeToString(svg);

      var canvas = document.createElement('canvas');
      var ctx = canvas.getContext('2d');

      var dataUri = '';
      try {
        dataUri = 'data:image/svg+xml;base64,' + btoa(svgData);
      } catch (ex) {
        console.log('Error Not Supported');
      }
      var img = document.createElement('img');

      img.onload = function() {
        canvas.width = this.width;
        canvas.height = this.height;
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

        try {
          // Try to initiate a download of the image
          var a = document.createElement('a');
          a.download = 'callFlow_' + $scope.corridId + '.jpeg';
          a.href = canvas.toDataURL('image/jpeg');
          document.querySelector('body').appendChild(a);
          a.click();
          document.querySelector('body').removeChild(a);
        } catch (ex) {
          // If downloading not possible (as in IE due to canvas.toDataURL() security issue)
          // then display image for saving via right-click
          var imgPreview = document.createElement('div');
          imgPreview.appendChild(img);
          document.querySelector('body').appendChild(imgPreview);
          $scope.openErrorAlert('IE Browser - Right Click and Save File in Desired Format');
        }
      };
      img.src = dataUri;
    };

  });
