// Angular material
//import './lib/js/angular.min.js';
import './lib/js/angular-animate.min.js';
import './lib/js/angular-aria.min.js';
import './lib/js/angular-messages.min.js';
import './lib/js/angular-translate.min.js';
import './lib/js/loader-static-files.js';

// Time Picker
import './lib/css/bootstrap-datetimepicker.min.css';
import './lib/js/bootstrap-datetimepicker.min.js';
// Sticky Header
import './lib/js/float-panel.js';

import './lib/css/master.css';
// Angular Tooltip
import './lib/css/angular-tooltips.css';
import './lib/js/angular-tooltips.js';

// Ng model
import './lib/css/ngDialog.css';
import './lib/css/ngDialog-theme-plain.css';
import './lib/css/ngDialog-theme-default.css';
import './lib/js/ngDialog.js';

// Pagination
import './lib/js/dirPagination.js';

//Cookies
import './lib/js/angular-cookies.js';

import './lib/js/jquery.rest.js';
import './lib/js/jquery.rest.min.js';

//multiselect
import './lib/js/angularjs-dropdown-multiselect.min.js';

//save as dialog
import './lib/js/nw-fileDialog.js';

// Spinner
import './lib/js/angular-spinner/node_modules/spin.js/spin.min.js';
import './lib/js/angular-spinner/angular-spinner.min.js';

// Custom Menu
import './lib/js/contextMenu.js';

// tribe node settings
import './controllers/SettingsController.js';

// other controllers
import './controllers/xsiEvent.js';
import './controllers/xsiREvent.js';
import './controllers/indexAddController.js';
import './controllers/indexSelectController.js';
import './controllers/indexUpdateController.js';
import './controllers/indexRemoveController.js';
//progress bar
import './lib/css/loading.css';
import './lib/css/loadingOld.css';
import './lib/css/loadingRes.css';