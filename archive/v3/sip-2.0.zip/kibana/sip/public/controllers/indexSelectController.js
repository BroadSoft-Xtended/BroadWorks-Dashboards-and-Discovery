import uiModules from 'ui/modules';
uiModules
.get('app/sip', ['720kb.tooltips','ngDialog','angularUtils.directives.dirPagination','ngCookies',
 'ui.bootstrap.contextMenu'])
.controller('indexSelectController', function ($scope, $route, $interval, $http, $sce,  $filter, $cookies, ngDialog) {

  $scope.fetchIndexPattern = function () {
    $scope.displayInfo = '';
    $scope.progress = 'true';
    $http.get('../api/sip/selectTribeIndexPattern').then((response) => {
      console.log(response);
      if (response.data.hits.hits) {
        $scope.index = response.data.hits.hits;
      }
      else {
        $scope.openErrorAlert('ERROR :( - Could not Access Server');
      }
    }, function errorCallback(response) {
      console.log('ERROR2');
      $scope.progress = 'false';
      $scope.openErrorAlert('ERROR :( - Could not Access Server');
    });
  };

  /**
   * [globalSetting Apply the setting globalCookie]
   * @return {[void]} [creates new cookie when setting is applied]
   */
  $scope.setIndexName = function (Data) {
    $scope.openErrorAlert('Index Pattern -' + Data.index + '  Applied');
    console.log(Data);
    $cookies.put('globalConfiguration', JSON.stringify(Data));
  };

});
