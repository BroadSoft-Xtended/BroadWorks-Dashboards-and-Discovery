import uiModules from 'ui/modules';
var angular = require('angular');
var $ = require('jquery');
var mscgenjs = require('../js/mscgenjs');
uiModules
.get('app/sip', ['720kb.tooltips','ngDialog','angularUtils.directives.dirPagination','ngCookies'])
.controller('sipCallFlowController', function ($scope, $route, $http, $window, ngDialog, $cookies) {

  // Application Name
  $scope.AppName = 'SIP Call Flow';
  $scope.collectorLocation;

  $scope.readConfigFile = function () {
    $http.get('../api/sip/readConfigFile',{

    }).then((response) => {
     //console.log(response.data);
      if (response.data === 'Error in Configuration File') {
        $scope.openErrorAlert('Invalid Configuration File');
      } else {
        console.log(response.data);
        $scope.collectorLocation = response.data;
      }
    });
  };

  $scope.readConfigFile();

  /**
   * [setActiveClass Add class to the sipCallSequenceMenu ID Dom]
   */
  $scope.setActiveClass = function () {
    var navList = angular.element(document.querySelector('#sipCallSequenceMenu'));
    navList.addClass('active');
  };

  /**
   * [corridId : Assign default correlationID]
   * @type {String}
   */
  $scope.corridId = '33f8853b-8758-4a34-8856-4a4a422149f4';
  $scope.chartDisplayed = false;

  /**
  * @desc Comman Non Modal Box for alert.
  * @param message- contains message to be displayed to user
  * @return void
  */
  $scope.openErrorAlert = function (message) {
    var response = message.split('-');
    //console.log(response);
    ngDialog.open({ template: '<p class="errorBox">' + response[0] + '</p>' +
    '<ul class="alertBoxBody"><li>' + response[1] + '</li></ul>',
    plain: true });
  };

  /**
   * [startSpin : Enable the progress bar]
   * @return {[type]} [description]
   */
  $scope.startSpin = function () {
    $scope.progress = 'true';
  };
  /**
   * [stopSpin : Disable the progress bar]
   * @return {[type]} [description]
   */
  $scope.stopSpin = function () {
    $scope.progress = 'false';
  };

  /**
   * [removeSVG : Remove the existing SVG image before rendering]
   * @return {[type]} [description]
   */
  var removeSVG = function () {
    var chartId = document.getElementById('mscgen_js-svg-__chart');
    //console.log(chartId);
    if (chartId) {
      document.getElementById('mscgen_js-svg-__chart').remove();
    }
  };

  var renderCall = function () {
    $scope.queryLang = 'msc {' + $scope.dataBody + '}';
    mscgenjs.renderMsc (
      $scope.queryLang,
      {
        inputType: 'xu',
        additionalTemplate: 'lazy',
        includeSource: false,
        elementId: '__chart',
      },
      handleRenderMscResult
    );

    function handleRenderMscResult(pError, pSuccess) {
      if (Boolean(pError)) {
        console.log (pError);
        return;
      } else if (Boolean(pSuccess)) {
        $scope.stopSpin();
        $scope.chartDisplayed = 'true';
        console.log('enter block');
        console.log($scope.chartDisplayed);
        console.log ('That worked - cool!');
        return;
        // the svg is in the pSuccess argument
      }
      console.log('Wat! Error nor success?');
    };
  };

  /**
   * [fetch : Generate the SIP Sequence Diagram for the given correaltion ID]
   * @return {[void]} [description]
   */
  $scope.fetch = function () {
    $scope.startSpin();
    removeSVG ();
    $scope.chartDisplayed = 'false';
    var url = 'http://' + $scope.collectorLocation + '/sipCallFlow?id=' + $scope.corridId + '&index=' + $scope.searchIndex;
    $http.get(url).then((response) => {
      if (response.data === 'Error Code: 13001 - Invalid Context Path orError Code: 13002 - Invalid Correlation ID' ||
        response.data === 'Error Code: 13003 - No Result Found in Elasticsearch' ||
        response.data === 'Error Code: 13004 - Index Pattern Not Present') {
        $scope.openErrorAlert(response.data);
        $scope.stopSpin();
      }
      else {
        $scope.dataBody = response.data;
        renderCall();
      }
    }, function (response) {
        //Second function handles error
      console.log('ERROR');
      $scope.stopSpin();
      $scope.openErrorAlert('ERROR :( - Could not Access Server');
    });
  };

  /**
   * [fetchGlobalInfo Read the value from the cookie stored]
   * @return {[void]} [description]
   */
  $scope.fetchGlobalInfo = function () {
    var globalCookie = $cookies.get('globalConfiguration');
    if (globalCookie) {
      $scope.test = globalCookie;
      var json = JSON.parse(globalCookie);
      console.log('Custom Settings Applied');
      console.log(json);
      if (json.sort === 'Ascending') {
        $scope.sortPreference = 'asc';
      }
      else if (json.sort === 'Descending') {
        $scope.sortPreference = 'desc';
      }
      if (json.index)
      {
        console.log(json.index);
        $scope.searchIndex = json.index;
      }
      $scope.sampleSize  = json.size;
    }
    else {
      console.log('Default Settings is Applied');
      $scope.searchIndex = 'bwlog*';
      $scope.sortPreference = 'asc';
      $scope.sampleSize  = '1000';
    }
  };
  $scope.fetchGlobalInfo();



 /**
  * [downloadSvg : Download the SVG file with correlationId ]
  * @return {[type]} [description]
  */
  $scope.downloadSvg = function () {
    var a      = document.createElement('a');
    a.href     = 'data:image/svg+xml;utf8,' + unescape($('#__chart')[0].outerHTML);
    a.download = 'callFlow_' + $scope.corridId + '.svg';
    a.target   = '_blank';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
  };

});
