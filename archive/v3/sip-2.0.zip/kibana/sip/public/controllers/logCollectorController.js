import uiModules from 'ui/modules';
var angular = require('angular');
var $ = require('jquery');
var JSZip = require('../js/jszip/');
var fileSave = require('../js/FileSaver');

var mscgenjs = require('../js/mscgenjs');
uiModules
.get('app/sip', ['ngDialog','mgo-angular-wizard'])
.controller('logCollectorController', function ($scope, $route, $http, $window, ngDialog, $cookies, $q) {

  $scope.wizard = {};

  /**
   * [setActiveClass Add class to the logCollectorMenu ID Dom]
   */
  $scope.setActiveClass = function () {
    var navList = angular.element(document.querySelector('#logCollectorMenu'));
    navList.addClass('active');
  };

  /**
  * @desc Comman Non Modal Box for alert.
  * @param message- contains message to be displayed to user
  * @return void
  */
  $scope.openErrorAlert = function (message) {
    var response = message.split('-');
    //console.log(response);
    ngDialog.open({ template: '<p class="alertBox">' + response[0] + '</p>' +
    '<ul class="alertBoxBody"><li>' + response[1] + '</li></ul>',
    plain: true });
  };

  var encrypt = function (str) {
    var encoded = '';
    for (var i = 0; i < str.length; i++) {
      var a = str.charCodeAt(i);
      var b = a ^ 123;    // bitwise XOR with any number, e.g. 123
      encoded = encoded + String.fromCharCode(b);
    }
    return encoded;
  };

  $scope.init = function () {
    //Common Global Flag to async Operation
    $scope.asyncFlag1 = 'false';
    $scope.asyncFlag2 = 'false';
    //Query User;
    $scope.wizard.connectionMode = {value: true};
    $scope.wizard.queryUserL = 'admin';
    $scope.wizard.UserUserPassL = 'ladmin';
    $scope.wizard.queryUserName = 'gokul1@gokul.com';
    $scope.wizard.queryUserServer = '10.99.15.65';
    //Query Group
    $scope.wizard.queryGroupUserNameL = 'admin';
    $scope.wizard.queryGroupUserPasswordL = 'ladmin';
    $scope.wizard.queryGroupProviderName = 'SP1';
    $scope.wizard.queryGroupName = 'GRP1';
    $scope.wizard.queryGroupServer = '10.99.15.65';
    //Tech support
    $scope.wizard.techSupportUserNameL = 'bwadmin';
    $scope.wizard.techSupportUserPasswordL = 'bwadmin';
    $scope.wizard.techSupportServer = '10.99.15.64';
  };
  $scope.init();
  /**
   * [fetchGlobalInfo Read the value from the cookie stored]
   * @return {[void]} [description]
   */
  $scope.fetchGlobalInfo = function () {
    var globalCookie = $cookies.get('globalConfiguration');
    if (globalCookie) {
      $scope.test = globalCookie;
      var json = JSON.parse(globalCookie);
      console.log('Custom Settings Applied');
      console.log(json);
      if (json.sort === 'Ascending') {
        $scope.sortPreference = 'asc';
      }
      else if (json.sort === 'Descending') {
        $scope.sortPreference = 'desc';
      }
      if (json.index)
      {
        console.log(json.index);
        $scope.searchIndex = json.index;
      }
      $scope.sampleSize  = json.size;
    }
    else {
      console.log('Default Settings is Applied');
      $scope.searchIndex = 'bwlog*';
      $scope.sortPreference = 'asc';
      $scope.sampleSize  = '1000';
    }
  };
  $scope.fetchGlobalInfo();

  /**
  * @desc Comman Non Modal Box for alert.
  * @param message- contains message to be displayed to user
  * @return void
  */
  $scope.openModalBox = function (message) {
    ngDialog.open({ template: '<p>' + message + '</p>', plain: true });
  };

  /**
 * [connectionChannel Decided connection request through BTBC or OCI Client]
 * @return {[int]} [return 1 for BTBC, return 2 for OCI Client]
 */
  var connectionChannel = function () {
    var connectionMode;
    if ($scope.wizard.connectionMode.value === true)
    {
      connectionMode = 2;
      return connectionMode;
    }
    else {
      connectionMode = 1;
      return connectionMode;
    }
  };

  /**
   * [readPropFile Contains the Server Url]
   * @type {String}
   */
  $scope.readConfigFile = function () {
    $http.get('../api/sip/readConfigFile',{

    }).then((response) => {
    //console.log(response.data);
      if (response.data === 'Error in Configuration File') {
        $scope.openErrorAlert('Invalid Configuration File');
      } else {
        console.log(response.data);
        $scope.collectorLocation = response.data;
      }
    });
  };

  $scope.readConfigFile();


  /**
 * [queryUserframeUrl :Frames the request url for the queryuser]
 * @return {[string]} [return url]
 */
  var queryUserframeUrl = function () {
    var connectionMode = connectionChannel();
    var requestUrl = 'http://' + $scope.collectorLocation  + '/queryUser?an=' +
     $scope.wizard.queryUserL + '&pwd=' +
     encrypt($scope.wizard.UserUserPassL) + '&un=' +
    $scope.wizard.queryUserName + '&h=' + $scope.wizard.queryUserServer + '&cm=' + connectionMode;
    return requestUrl;
  };

/**
 * [queryUserGroupframeUrl :Frames the request url for the queryGroup]
 * @return {[string]} [return url]
 */
  var queryUserGroupframeUrl = function () {
    var connectionMode = connectionChannel();
    var requestUrl = 'http://' + $scope.collectorLocation  + '/queryGroup?an=' +
     $scope.wizard.queryGroupUserNameL + '&pwd=' +
     encrypt($scope.wizard.queryGroupUserPasswordL) + '&sp=' +
     $scope.wizard.queryGroupProviderName + '&grp=' +
     $scope.wizard.queryGroupName + '&h=' +
     $scope.wizard.queryGroupServer + '&cm=' + connectionMode;
    return requestUrl;
  };

  /**
 * [queryTechSupportframeUrl :Frames the request url for the techSupport]
 * @return {[string]} [return url]
 */
  var queryTechSupportframeUrl = function () {
    var requestUrl = 'http://' + $scope.collectorLocation  + '/tech-support?un=' +
     $scope.wizard.techSupportUserNameL + '&pwd=' +
     encrypt($scope.wizard.techSupportUserPasswordL) + '&h=' +
     $scope.wizard.techSupportServer + '&p=22';
    return requestUrl;
  };

  /**
   * [setProgressFalse :Sets the progressbar status to false]
   */
  var setProgressFalse = function () {
    $scope.progress = 'false';
  };

  /**
   * [processHttpServerLogs description]
   * @param  {[string]} message [Message comes from the server]
   * @return {[errorMessage]}  [Display the error message or format the XML output]
   */
  var processHttpServerLogs = function (message) {
    // Only for tech support it is added because of Jslint Error as line exceeds 189 char
    var techSupportErrorCode = 'Error Code : 12008 - No Tech Support is available in the specified host.' +
    ' Please execute the command tech-support -dailyDump and then proceed';
    switch (message) {
      case 'Error Code : 12001 - Invalid Request':
        $scope.openErrorAlert('Error Code : 12001 - Invalid Request');
        message = 'Error Code : 12001 - Invalid Request';
        break;
      case 'Error Code : 12002 - Failed to connect Server':
        $scope.openErrorAlert('Error Code : 12002 - Failed to connect Server');
        message = 'Error Code : 12002 - Failed to connect Server';
        break;
      case 'Error Code : 12003 - Invalid Credentials':
        $scope.openErrorAlert('Error Code : 12003 - Invalid Credentials');
        message = 'Error Code : 12003 - Invalid Credentials';
        break;
      case 'Error Code : 12004 - User not Found':
        $scope.openErrorAlert('Error Code : 12004 - User not Found');
        message = 'Error Code : 12004 - User not Found';
        break;
      case 'Error Code : 12005 - ServiceProvider or Enterprise not found':
        $scope.openErrorAlert('Error Code : 12005 - ServiceProvider or Enterprise not found');
        message = 'Error Code : 12005 - ServiceProvider or Enterprise not found';
        break;
      case 'Error Code : 12006 - Group not found':
        $scope.openErrorAlert('Error Code : 12006 - Group not found');
        message = 'Error Code : 12006 - Group not found';
        break;
      case 'Error Code : 12007 - Connection Refused':
        $scope.openErrorAlert('Error Code : 12007 - Connection Refused');
        message = 'Error Code : 12007 - Connection Refused';
        break;
      case techSupportErrorCode:
        $scope.openErrorAlert(techSupportErrorCode);
        message = techSupportErrorCode;
        break;
      default:
        console.log('No Error');
    }
    return message;
  };

  $scope.getDescription = function () {
    var correlationID = $scope.wizard.corridId;
    var Header = 'Broadwork Dashboard and Discovery Log Collector \n';
    var CorrelationIDBody = 'Incident CorrelationID = ';
    return Header + CorrelationIDBody + correlationID;
  };

  $scope.getCorrelationIdLogs = function (response) {
    var resultObj = response.hits.hits;
    var result = autoLink(resultObj);
    return result;
  };

  /**
   * [fetchLogMessage It returns the revelant log based on the correlationid]
   * @param  {[number]} correlationid [Correlation ID(Unique ID) for SIP calls]
   * @param  {[uniquetime]} uniquetime    [provide timestamp as name for log file being donwloaded]
   * @return {[type]}               [description]
   */
  $scope.fetchLogMessage = function () {
    $scope.progress = 'true';
    var zip = new JSZip();
    var array = [];
    //Fetch the Given CorrelationID log - Stage 1
    array.push($http.get('../api/sip/logmessage',
      {
        params:{
          searchIndex: $scope.searchIndex,
          correlationId: $scope.wizard.corridId
        }
      }));

    //Fetch the Query User Log - Stage 2
    var queryuserUrl = queryUserframeUrl();
    array.push($http.get(queryuserUrl));

    //Fetch the Query Group Log Stage 3
    var queryGroupUrl = queryUserGroupframeUrl();
    array.push($http.get(queryGroupUrl));

    //Fetch the Tech Support Log Stage 4
    var techSupportUrl = queryTechSupportframeUrl();
    array.push($http.get(techSupportUrl));

    $q.all(array).then(function (resultArray) {
      zip.file('Incident_Log/'  + $scope.wizard.corridId + '.txt', $scope.getCorrelationIdLogs(resultArray[0].data));
      zip.file('OCI_Transcation/'  + 'queryUser' + '.txt', processHttpServerLogs(resultArray[1].data));
      zip.file('OCI_Transcation/'  + 'queryGroup' + '.txt', processHttpServerLogs(resultArray[2].data));
      zip.file('Tech_Support/'  + 'techSupport' + '.txt', processHttpServerLogs(resultArray[3].data));
      zip.file('description'  + '.txt', $scope.getDescription());
      $scope.asyncFlag1 = 'true';
      if ($scope.asyncFlag1 === 'true' && $scope.asyncFlag2 === 'true') {
        zip.generateAsync({type:'blob'})
        .then(function (blob) {
          console.log('zipping Started');
          fileSave.saveAs(blob, 'Log_Collector.zip');
        });
        $scope.asyncFlag1 = 'false';
        $scope.asyncFlag2 = 'false';
        setProgressFalse();
      }
    });
    $scope.getTimeStamp($scope.wizard.corridId, zip);
  };


  var frameLogTimeStampQuery = function (correlationID, order) {
    var searchBody = {
      'size' : 1,
      '_source' : {
        'includes' : ['logtimestamp']
      },
      'sort' : [
        {
          'logtimestamp' : {
            'order': order
          }
        }
      ],
      'query' : {
        'bool': {
          'must': {
            'term' : {
              'correlationid': correlationID
            }
          }
        }
      }
    };
    return searchBody;
  };

  var getAggreatedIdQuery = function (logTimeStamp) {
    var searchBody = {
      'sort': [
        {
          'logtimestamp': {
            'order': 'asc'
          }
        }
      ],
      'stored_fields': [
        'logtimestamp',
        'body'
      ],
      'aggs': {
        corrid_agg : {
          'terms': {
            field: 'correlationid',
            size: '1000',
            collect_mode: 'breadth_first'
          }
        }
      },
      'query': {
        bool : {
          must: {
            query_string: {
              query: '*'
            }
          },
          filter: {
            bool: {
              must: [
                {
                  range: {
                    'logtimestamp': {
                      'gte': logTimeStamp[0],
                      'lte': logTimeStamp[1]
                    }
                  }
                }
              ]
            }
          }
        }
      }
    };
    return searchBody;
  };

  $scope.getTimeStamp = function (correaltionID, zip) {
    var ascBody = frameLogTimeStampQuery(correaltionID, 'asc');
    var ascResult = $http.get('../api/sip/logtimestamp',{
      params:{
        searchIndex: $scope.searchIndex,
        searchBody: ascBody
      }
    }).then((response) => {
      var result = response.data.hits.hits;
      return result[0]._source.logtimestamp;
    });
    var descBody = frameLogTimeStampQuery(correaltionID, 'desc');
    var descResult = $http.get('../api/sip/logtimestamp',{
      params:{
        searchIndex: $scope.searchIndex,
        searchBody: descBody
      }
    }).then((response) => {
      var result = response.data.hits.hits;
      return result[0]._source.logtimestamp;
    });
    $q.all([ascResult, descResult]).then(function (result) {
      //console.log(result);
      var correlationSearchBody = getAggreatedIdQuery(result);
      $http.get('../api/sip/corrid1', {
        params:{
          searchIndex: $scope.searchIndex,
          advanceQuery: correlationSearchBody
        }
      }).then((response) => {
        console.log('result');
        console.log(response.data.length);
        var arr = [];
        $scope.correlationIDList = response.data;
        var t0 = performance.now();
        for (var i = 0; i < $scope.correlationIDList.length; i++)
        {
          //console.log($scope.correlationIDList[i].key);
          var correlationKey = $scope.correlationIDList[i].key;
          arr.push($http.get('../api/sip/logmessage',{
            params:{
              searchIndex: $scope.searchIndex,
              correlationId: correlationKey
            }
          }).then((response) => {
            var myArr = response.data.hits.hits;
            return autoLink(myArr); }));
        }
        $q.all(arr).then(function (result) {
          var t1 = performance.now();
          console.log('Call to ES ' + (t1 - t0) + ' milliseconds.');
          $scope.downloadEntireLog(result, zip);
        });
      });
      return result;
    });
  };

  $scope.downloadEntireLog = function (resultArray, zip)
  {
    var t0 = performance.now();
    for (var i = 0; i < resultArray.length; i++) {
      zip.file('Events/sip_'  + i + '.txt', resultArray[i]);
    }
    $scope.asyncFlag2 = 'true';
    if ($scope.asyncFlag1 === 'true' && $scope.asyncFlag2 === 'true') {
      //console.log('Stage2');
      zip.generateAsync({type:'blob'})
      .then(function (blob) {
        console.log('zipping Started');
        fileSave.saveAs(blob, 'Log_Collector.zip');
      });
      $scope.asyncFlag1 = 'false';
      $scope.asyncFlag2 = 'false';
      setProgressFalse();
    }
    //var t1 = performance.now();
    //console.log('Call to Zipping ' + (t1 - t0) + ' milliseconds.');
  };

  /**
   * [htmlEntities Replace the HTML begining and closing Tags]
   * @param  {[string]} str [logmessage ]
   * @return {[type]}     [All the HTML tags are converted into &lt and &gt]
   */
  function htmlEntities(str) {
    return String(str).replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  /**
   * [autoLink renders the logmessage for given correlationId]
   * @param  {[object]} myArr      [json object from server]
   * @param  {[string]} uniquetime [log file timestamp]
   * @return {[object]}            [holds logmessage, logfile]
   */
  function autoLink(myArr, uniquetime) {
    var logFile = '';
    //logFile model variable is used hold log message for  file being downloaded
    $scope.logFile = myArr;
    // Below code snippet is used to decorate the Log Message First Line
    for (var i = 0; i < myArr.length; i++)
    {
      var xx = htmlEntities(myArr[i]._source.source);
      logFile = logFile.concat(myArr[i]._source.source);
    }
    return  logFile;
  };

});
