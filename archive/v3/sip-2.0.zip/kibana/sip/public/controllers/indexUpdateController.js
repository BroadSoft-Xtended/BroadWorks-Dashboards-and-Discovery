import uiModules from 'ui/modules';
uiModules
.get('app/sip', ['720kb.tooltips','ngDialog','angularUtils.directives.dirPagination','ngCookies',
 'ui.bootstrap.contextMenu'])
.controller('indexUpdateController', function ($scope, $route, $interval, $http, $sce,  $filter, $cookies, ngDialog) {

  $scope.fetchIndexPattern = function () {
    $scope.displayInfo = '';
    $scope.progress = 'true';
    $http.get('../api/sip/selectTribeIndexPattern').then((response) => {
      console.log(response);
      $scope.updateIndexPattern = response.data.hits.hits;
      //console.log($scope.updateIndexPattern);
    }, function errorCallback(response) {
      console.log('ERROR3');
      $scope.progress = 'false';
      $scope.openErrorAlert('ERROR :( - Could not Access Server');
    });
  };

  $scope.peformUpdate = function (ID, newPattern) {
    console.log(document);
    console.log(newPattern);
    $http.get('../api/sip/updateTribeIndexPattern' , {
      params: {
        documentID: ID,
        updatedPattern: newPattern
      }
    }).then((response) => {
      $scope.openModalBox('Index Updated in List');
      setTimeout(function () {  $scope.fetchIndexPattern(); }, 2000);
    }, function errorCallback(response) {
      console.log('ERROR');
      $scope.progress = 'false';
      $scope.openErrorAlert('ERROR :( - Could not Access Server');
    });
  };


});
