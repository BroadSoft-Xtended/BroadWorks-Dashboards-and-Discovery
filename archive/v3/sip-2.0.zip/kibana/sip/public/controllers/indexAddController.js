import uiModules from 'ui/modules';
uiModules
.get('app/sip', ['720kb.tooltips','ngDialog','angularUtils.directives.dirPagination','ngCookies',
 'ui.bootstrap.contextMenu'])
.controller('indexAddController', function ($scope, $route, $interval, $http, $sce,  $filter, $cookies, ngDialog) {


  $scope.choices = [{}];
  $scope.addInputField = function () {
    var newItemNo = $scope.choices.length + 1;
    $scope.choices.push({});
  };


  $scope.removeInputField = function () {
    // Must have atleast one search option
    // Prevent '-' button to remove all the fields
    if ($scope.choices.length === 1)
    {
      $scope.openModalBox('Atleast One Search Filter Needed');
      return;
    }
    var lastItem = $scope.choices.length - 1;
    $scope.choices.splice(lastItem);
  };

  $scope.submitIndexRecord = function () {
    console.log($scope.choices[0].index_alias);
    $scope.progress = 'true';
    $http.get('../api/sip/addTribeIndexPattern' , {
      params: {
        pattern: $scope.choices[0].index_alias,
        document: $scope.choices
      }
    }).then((response) => {
      if (response.data === 'Pattern Already Exists') {
        $scope.openErrorAlert('Error :) - Pattern Already Exists');
      }
      else {
        console.log(response);
        $scope.openErrorAlert('SUCCESS :) - Added Index');
      }
      $scope.progress = 'false';
    }, function errorCallback(response) {
      console.log('ERROR');
      $scope.progress = 'false';
      $scope.openErrorAlert('ERROR :( - Could not Access Server');
    });
  };

  $scope.formReset = function () {
    $scope.choices = [{}];
  };

  // Error Message, already exists
  // Could not able to index data
});
