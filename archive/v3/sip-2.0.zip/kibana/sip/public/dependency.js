// bootstrap
import './js/bootstrap/dist/css/bootstrap.css';
import './js/bootstrap/dist/js/bootstrap.min.js';
// Time Picker
import './css/bootstrap-datetimepicker.min.css';
import './js/bootstrap-datetimepicker.min.js';

// Sticky Header
import './js/float-panel.js';
import './css/master.css';

// Angular Tooltip
import './css/angular-tooltips.css';
import './js/angular-tooltips.js';

// Ng modal
import './css/ngDialog.css';
import './css/ngDialog-theme-plain.css';
import './css/ngDialog-theme-default.css';
import './js/ngDialog.js';

// Pagination
import './js/dirPagination.js';

// Cookies
import './js/angular-cookies.js';

// XML Formatter
import './js/vkbeautify.js';

// Spinner
import './css/loading.css';

// Custom Menu
import './js/contextMenu.js';

// controllers
import './controllers/SipCallController.js';
import './controllers/CorrelationIdController.js';
import './controllers/SipCallFlowController.js';
import './controllers/sipCallFlowRedirect';
import './controllers/OciController.js';
import './controllers/Configurationcontroller.js';
import './controllers/logCollectorController.js';
import './controllers/indexSelectController.js';
import './controllers/indexAddController.js';
import './controllers/indexUpdateController.js';
import './controllers/indexRemoveController.js';

// Angular Wizard
import './js/angular-wizard.min.js';
import './css/angular-wizard.min.css';

// File Zipping
import './js/FileSaver.js';

// Side Navigation
import './css/sidenav.css';
