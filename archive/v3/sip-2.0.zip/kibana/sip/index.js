import exampleRoute from './server/routes/example';

var path = require('path');
module.exports = function (kibana) {

  var mainFile = 'plugins/sip/app/';


  return new kibana.Plugin({
    require: ['kibana','elasticsearch'],

    uiExports: {
      app: {
        title: 'SIP Analyzer',
        description: 'An awesome Kibana plugin',
        main: mainFile,
        icon: 'plugins/sip/resource/logo-scaled.png',
        injectVars: function (server, options) {
          var config = server.config();
          return {
            kbnIndex: config.get('kibana.index'),
            esShardTimeout: config.get('elasticsearch.shardTimeout'),
            esApiVersion: config.get('elasticsearch.apiVersion')
          };
        }
      }
    },



    init(server, options) {
      // Add server routes and initalize the plugin here
      exampleRoute(server);
    }

  });
};
