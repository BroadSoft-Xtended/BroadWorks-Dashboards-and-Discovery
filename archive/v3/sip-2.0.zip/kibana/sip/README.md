BroadSoft Technologies Pvt Ltd


SIP Call Correlation ID Utility
Version - 2.0

Installation
$ bin/kibana-plugin install file:///path/path/sip-2.0.zip

Functionality
1. Migration of Kibana 4 App to Kibana 5
2. SIP Sequence Diagram 
3. OCI Transcation Export
4. Log Collector - Fetch Log during Incident 
5. Multi Data Center Support
6. Improvment in UI and UX
